import type {
  FieldValidationError,
  GroceryRecordInput,
  ValidationResult,
} from '../types/grocery.ts';

const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const SAFE_TEXT_REGEX = /^[\w\s\-.,&'()/%#]+$/;

export function sanitizeText(value: string): string {
  return value.replace(/[\r\n\t\x00-\x1f\x7f]/g, ' ').replace(/\s+/g, ' ').trim();
}

export function isValidCalendarDate(dateStr: string): boolean {
  if (!DATE_REGEX.test(dateStr)) return false;
  const [y, m, d] = dateStr.split('-').map(Number);
  if (y < 2000 || y > 2100) return false;
  const parsed = new Date(Date.UTC(y, m - 1, d));
  return (
    parsed.getUTCFullYear() === y &&
    parsed.getUTCMonth() === m - 1 &&
    parsed.getUTCDate() === d
  );
}

export function validateGroceryInput(
  input: GroceryRecordInput,
  allowedCategories?: string[]
): ValidationResult {
  const errors: FieldValidationError[] = [];

  const itemName = sanitizeText(String(input.itemName ?? ''));
  if (!itemName) {
    errors.push({ field: 'itemName', message: 'Please enter what grocery item you bought.' });
  } else if (itemName.length < 2 || itemName.length > 80) {
    errors.push({ field: 'itemName', message: 'Item name should be between 2 and 80 characters.' });
  } else if (!SAFE_TEXT_REGEX.test(itemName)) {
    errors.push({ field: 'itemName', message: 'Please use standard letters, numbers, or punctuation.' });
  }

  const rawCategory = sanitizeText(String(input.category ?? ''));
  let resolvedCategory = rawCategory;
  if (!rawCategory || rawCategory.length < 2 || rawCategory.length > 50) {
    errors.push({ field: 'category', message: 'Please choose or enter a category.' });
  } else if (allowedCategories && allowedCategories.length > 0) {
    const match = allowedCategories.find(
      (c) => c.toLowerCase() === rawCategory.toLowerCase()
    );
    if (match) {
      resolvedCategory = match;
    }
  }

  const quantityNum = Number(input.quantity);
  if (
    input.quantity === '' ||
    input.quantity === null ||
    input.quantity === undefined ||
    Number.isNaN(quantityNum) ||
    !Number.isFinite(quantityNum)
  ) {
    errors.push({ field: 'quantity', message: 'Please enter a valid quantity.' });
  } else if (quantityNum <= 0 || quantityNum > 10000) {
    errors.push({ field: 'quantity', message: 'Quantity must be greater than 0.' });
  }

  const unitPriceNum = Number(input.unitPrice);
  if (
    input.unitPrice === '' ||
    input.unitPrice === null ||
    input.unitPrice === undefined ||
    Number.isNaN(unitPriceNum) ||
    !Number.isFinite(unitPriceNum)
  ) {
    errors.push({ field: 'unitPrice', message: 'Please enter a valid price.' });
  } else if (unitPriceNum < 0.01 || unitPriceNum > 100000) {
    errors.push({ field: 'unitPrice', message: 'Price must be at least $0.01.' });
  }

  const itemBudgetNum = Number(input.itemBudget);
  if (
    input.itemBudget === '' ||
    input.itemBudget === null ||
    input.itemBudget === undefined ||
    Number.isNaN(itemBudgetNum) ||
    !Number.isFinite(itemBudgetNum)
  ) {
    errors.push({ field: 'itemBudget', message: 'Please enter your target price limit for this item.' });
  } else if (itemBudgetNum < 0.01 || itemBudgetNum > 100000) {
    errors.push({ field: 'itemBudget', message: 'Target limit must be at least $0.01.' });
  }

  const purchaseDate = sanitizeText(String(input.purchaseDate ?? ''));
  if (!isValidCalendarDate(purchaseDate)) {
    errors.push({ field: 'purchaseDate', message: 'Please pick a valid date.' });
  }

  const store = sanitizeText(String(input.store ?? ''));
  if (!store) {
    errors.push({ field: 'store', message: 'Please enter the store name.' });
  } else if (store.length < 2 || store.length > 50) {
    errors.push({ field: 'store', message: 'Store name should be between 2 and 50 characters.' });
  }

  const notes = sanitizeText(String(input.notes ?? '')).slice(0, 160);

  if (errors.length > 0) {
    return { valid: false, errors };
  }

  const roundedQty = Math.round(quantityNum * 100) / 100;
  const roundedUnit = Math.round(unitPriceNum * 100) / 100;
  const totalCost = Math.round(roundedQty * roundedUnit * 100) / 100;
  const roundedBudget = Math.round(itemBudgetNum * 100) / 100;

  return {
    valid: true,
    errors: [],
    sanitized: {
      itemName,
      category: resolvedCategory,
      quantity: roundedQty,
      unitPrice: roundedUnit,
      totalCost,
      itemBudget: roundedBudget,
      purchaseDate,
      store,
      notes,
    },
  };
}
