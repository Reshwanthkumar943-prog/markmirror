import {
  BUILT_IN_CATEGORIES,
  type BudgetConfig,
  type BudgetStatus,
  type CategorySummary,
  type DailySpendPoint,
  type EvaluatedRecord,
  type ExecutiveSummary,
  type GroceryRecord,
  type ThresholdWarning,
} from '../types/grocery.ts';
import { getCategoryVisual } from './categoryColors.ts';

export function getAllCategoryNames(
  config: BudgetConfig,
  records: GroceryRecord[] = []
): string[] {
  const seen = new Set<string>(BUILT_IN_CATEGORIES);
  for (const custom of config.customCategories ?? []) {
    if (custom.name.trim()) seen.add(custom.name.trim());
  }
  for (const rec of records) {
    if (rec.category.trim()) seen.add(rec.category.trim());
  }
  return Array.from(seen);
}

export function computeBudgetStatus(
  spent: number,
  budget: number,
  warningThresholdPct: number
): BudgetStatus {
  if (budget <= 0) return spent > 0 ? 'Over Budget' : 'Within Budget';
  const ratioPct = (spent / budget) * 100;
  if (spent > budget + 0.001) return 'Over Budget';
  if (ratioPct >= warningThresholdPct) return 'Near Limit';
  return 'Within Budget';
}

export function evaluateRecords(
  records: GroceryRecord[],
  config: BudgetConfig
): EvaluatedRecord[] {
  const categoryPrices = new Map<string, number[]>();
  for (const r of records) {
    const list = categoryPrices.get(r.category) ?? [];
    list.push(r.unitPrice);
    categoryPrices.set(r.category, list);
  }

  const categoryAverageUnitPrice = new Map<string, number>();
  for (const [cat, prices] of categoryPrices.entries()) {
    const avg = prices.reduce((a, b) => a + b, 0) / prices.length;
    categoryAverageUnitPrice.set(cat, avg);
  }

  return records.map((record) => {
    const variance = Math.round((record.itemBudget - record.totalCost) * 100) / 100;
    const utilizationPct =
      record.itemBudget > 0
        ? Math.round((record.totalCost / record.itemBudget) * 1000) / 10
        : 100;
    const status = computeBudgetStatus(
      record.totalCost,
      record.itemBudget,
      config.warningThresholdPct
    );

    const catAvg = categoryAverageUnitPrice.get(record.category) ?? record.unitPrice;
    let isAnomalous = false;
    let anomalyReason: string | null = null;

    if (record.totalCost > record.itemBudget * 1.25) {
      isAnomalous = true;
      anomalyReason = `Spent $${Math.abs(variance).toFixed(2)} more than your $${record.itemBudget.toFixed(2)} target`;
    } else if (catAvg > 0 && record.unitPrice > catAvg * 2.4 && record.unitPrice > 12) {
      isAnomalous = true;
      anomalyReason = `Higher price ($${record.unitPrice.toFixed(2)}) compared to usual ${record.category} items`;
    }

    return {
      ...record,
      variance,
      utilizationPct,
      status,
      isAnomalous,
      anomalyReason,
    };
  });
}

export function buildExecutiveSummary(
  records: GroceryRecord[],
  config: BudgetConfig
): ExecutiveSummary {
  const evaluated = evaluateRecords(records, config);

  const totalSpend =
    Math.round(evaluated.reduce((sum, r) => sum + r.totalCost, 0) * 100) / 100;
  const overallBudget = Math.round(config.overallMonthlyBudget * 100) / 100;
  const remainingBudget = Math.round((overallBudget - totalSpend) * 100) / 100;
  const overallUtilizationPct =
    overallBudget > 0 ? Math.round((totalSpend / overallBudget) * 1000) / 10 : 0;
  const overallStatus = computeBudgetStatus(
    totalSpend,
    overallBudget,
    config.warningThresholdPct
  );

  const totalEntries = evaluated.length;
  const averageEntryCost =
    totalEntries > 0 ? Math.round((totalSpend / totalEntries) * 100) / 100 : 0;

  const overspentEntriesCount = evaluated.filter((r) => r.status === 'Over Budget').length;
  const nearLimitEntriesCount = evaluated.filter((r) => r.status === 'Near Limit').length;
  const withinBudgetEntriesCount = evaluated.filter(
    (r) => r.status === 'Within Budget'
  ).length;
  const complianceRatePct =
    totalEntries > 0
      ? Math.round(((totalEntries - overspentEntriesCount) / totalEntries) * 1000) / 10
      : 100;

  const allCategoryNames = getAllCategoryNames(config, records);
  const customSet = new Set(
    (config.customCategories ?? []).map((c) => c.name.toLowerCase())
  );

  const categories: CategorySummary[] = allCategoryNames.map((category) => {
    const items = evaluated.filter((r) => r.category === category);
    const catSpend =
      Math.round(items.reduce((sum, r) => sum + r.totalCost, 0) * 100) / 100;
    const customDef = (config.customCategories ?? []).find(
      (c) => c.name.toLowerCase() === category.toLowerCase()
    );
    const fixedBudget =
      Math.round(
        (config.categoryBudgets[category] ?? customDef?.budget ?? 40) * 100
      ) / 100;
    const variance = Math.round((fixedBudget - catSpend) * 100) / 100;
    const utilizationPct =
      fixedBudget > 0 ? Math.round((catSpend / fixedBudget) * 1000) / 10 : 0;
    const status = computeBudgetStatus(
      catSpend,
      fixedBudget,
      config.warningThresholdPct
    );
    const overspentItemCount = items.filter((r) => r.status === 'Over Budget').length;
    const averageItemCost =
      items.length > 0 ? Math.round((catSpend / items.length) * 100) / 100 : 0;

    return {
      category,
      color: getCategoryVisual(category, config).hex,
      isCustom: customSet.has(category.toLowerCase()),
      itemCount: items.length,
      totalSpend: catSpend,
      fixedBudget,
      variance,
      utilizationPct,
      status,
      overspentItemCount,
      averageItemCost,
    };
  });

  const sortedCategories = [...categories].sort((a, b) => b.totalSpend - a.totalSpend);
  const highestCategory =
    sortedCategories.length > 0 && sortedCategories[0].totalSpend > 0
      ? sortedCategories[0]
      : null;

  const dateTotals = new Map<string, number>();
  for (const r of evaluated) {
    dateTotals.set(
      r.purchaseDate,
      Math.round(((dateTotals.get(r.purchaseDate) ?? 0) + r.totalCost) * 100) / 100
    );
  }
  const sortedDates = Array.from(dateTotals.keys()).sort();
  let running = 0;
  const dailyTrend: DailySpendPoint[] = sortedDates.map((date) => {
    const dailySpend = dateTotals.get(date) ?? 0;
    running = Math.round((running + dailySpend) * 100) / 100;
    return {
      date,
      dailySpend,
      cumulativeSpend: running,
      budgetCeiling: overallBudget,
    };
  });

  const warnings: ThresholdWarning[] = [];
  if (overallStatus === 'Over Budget') {
    warnings.push({
      id: 'warn-overall',
      severity: 'critical',
      scope: 'Monthly Budget',
      title: 'Monthly Grocery Budget Exceeded',
      detail: `You've spent $${totalSpend.toFixed(2)} so far, which is $${Math.abs(remainingBudget).toFixed(2)} above your $${overallBudget.toFixed(2)} monthly limit.`,
      amountDelta: remainingBudget,
    });
  } else if (overallStatus === 'Near Limit') {
    warnings.push({
      id: 'warn-overall-near',
      severity: 'warning',
      scope: 'Monthly Budget',
      title: 'Getting Close to Monthly Budget',
      detail: `You've used ${overallUtilizationPct.toFixed(1)}% of your $${overallBudget.toFixed(2)} budget ($${remainingBudget.toFixed(2)} left).`,
      amountDelta: remainingBudget,
    });
  }

  for (const cat of categories) {
    if (cat.status === 'Over Budget') {
      warnings.push({
        id: `warn-cat-${cat.category}`,
        severity: 'critical',
        scope: 'Category Limit',
        title: `${cat.category} is over its limit`,
        detail: `Spent $${cat.totalSpend.toFixed(2)} out of your $${cat.fixedBudget.toFixed(2)} limit.`,
        amountDelta: cat.variance,
      });
    } else if (cat.status === 'Near Limit') {
      warnings.push({
        id: `warn-cat-near-${cat.category}`,
        severity: 'warning',
        scope: 'Category Limit',
        title: `${cat.category} is almost at its limit`,
        detail: `Spent $${cat.totalSpend.toFixed(2)} of $${cat.fixedBudget.toFixed(2)} (${cat.utilizationPct.toFixed(0)}%).`,
        amountDelta: cat.variance,
      });
    }
  }

  for (const rec of evaluated) {
    if (rec.isAnomalous && rec.anomalyReason) {
      warnings.push({
        id: `warn-anom-${rec.id}`,
        severity: rec.status === 'Over Budget' ? 'critical' : 'warning',
        scope: 'Price Spike',
        title: `${rec.itemName} cost more than expected`,
        detail: rec.anomalyReason,
        amountDelta: rec.variance,
      });
    }
  }

  return {
    totalSpend,
    overallBudget,
    remainingBudget,
    overallUtilizationPct,
    overallStatus,
    totalEntries,
    averageEntryCost,
    overspentEntriesCount,
    nearLimitEntriesCount,
    withinBudgetEntriesCount,
    complianceRatePct,
    highestCategory,
    categories,
    dailyTrend,
    warnings,
  };
}

export function generateSpreadsheetExport(records: EvaluatedRecord[]): string {
  const header =
    'Item,Category,Quantity,Unit Price,Total Cost,Target Limit,Savings/Over,Status,Date,Store,Notes';
  const rows = records.map((r) => {
    const esc = (v: string) => `"${v.replace(/"/g, '""')}"`;
    return [
      esc(r.itemName),
      esc(r.category),
      r.quantity.toFixed(2),
      r.unitPrice.toFixed(2),
      r.totalCost.toFixed(2),
      r.itemBudget.toFixed(2),
      r.variance.toFixed(2),
      esc(r.status),
      esc(r.purchaseDate),
      esc(r.store),
      esc(r.notes),
    ].join(',');
  });
  return [header, ...rows].join('\n');
}
