import { useMemo, useState } from 'react';
import { motion } from 'motion/react';
import { Download, Edit2, Plus, Search, Trash2 } from 'lucide-react';
import type {
  BudgetConfig,
  BudgetStatus,
  EvaluatedRecord,
  GroceryRecord,
} from '../types/grocery.ts';
import { getAllCategoryNames, generateSpreadsheetExport } from '../utils/analytics.ts';
import { getCategoryVisual } from '../utils/categoryColors.ts';
import { StatusLabel } from './StatusBadge.tsx';

interface GroceriesViewProps {
  records: EvaluatedRecord[];
  config: BudgetConfig;
  initialCategory?: string;
  onEdit: (record: GroceryRecord) => void;
  onDelete: (id: string) => void;
  onOpenAddModal: () => void;
}

export function GroceriesView({
  records,
  config,
  initialCategory = 'All',
  onEdit,
  onDelete,
  onOpenAddModal,
}: GroceriesViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<string>(initialCategory);
  const [statusFilter, setStatusFilter] = useState<'All' | BudgetStatus>('All');
  const [sortBy, setSortBy] = useState<'date-desc' | 'cost-desc' | 'variance-asc'>(
    'date-desc'
  );

  const categoryNames = useMemo(
    () => getAllCategoryNames(config, records),
    [config, records]
  );

  const filtered = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    const list = records.filter((r) => {
      if (categoryFilter !== 'All' && r.category !== categoryFilter) return false;
      if (statusFilter !== 'All' && r.status !== statusFilter) return false;
      if (q) {
        const hay = `${r.itemName} ${r.store} ${r.notes} ${r.category}`.toLowerCase();
        if (!hay.includes(q)) return false;
      }
      return true;
    });

    return [...list].sort((a, b) => {
      if (sortBy === 'cost-desc') return b.totalCost - a.totalCost;
      if (sortBy === 'variance-asc') return a.variance - b.variance;
      return b.purchaseDate.localeCompare(a.purchaseDate) || b.id.localeCompare(a.id);
    });
  }, [records, searchQuery, categoryFilter, statusFilter, sortBy]);

  const handleDownloadSpreadsheet = () => {
    const csv = generateSpreadsheetExport(filtered);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'my_groceries.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-5">
      {/* Search, Sort & Export Bar */}
      <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-4 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="relative flex-1 min-w-0">
            <Search
              className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
              aria-hidden="true"
            />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search apples, milk, FreshMarket, or notes..."
              className="w-full pl-10 pr-3 py-2.5 text-sm rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-emerald-600 focus:ring-2 focus:ring-emerald-600/20"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              aria-label="Sort groceries"
              value={sortBy}
              onChange={(e) =>
                setSortBy(e.target.value as 'date-desc' | 'cost-desc' | 'variance-asc')
              }
              className="px-3 py-2.5 text-sm rounded-xl border border-slate-300 bg-white text-slate-700 focus:outline-none focus:border-emerald-600"
            >
              <option value="date-desc">Newest First</option>
              <option value="cost-desc">Highest Amount</option>
              <option value="variance-asc">Most Over Target</option>
            </select>

            <button
              type="button"
              onClick={handleDownloadSpreadsheet}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" aria-hidden="true" />
              <span>Export List</span>
            </button>
          </div>
        </div>

        {/* Interactive Colorful Category Filter Strip */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          <button
            type="button"
            onClick={() => setCategoryFilter('All')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              categoryFilter === 'All'
                ? 'bg-slate-900 text-white'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            All Categories
          </button>
          {categoryNames.map((cat) => {
            const visual = getCategoryVisual(cat, config);
            const Icon = visual.icon;
            const active = categoryFilter === cat;
            return (
              <button
                key={cat}
                type="button"
                onClick={() => setCategoryFilter(cat)}
                style={
                  active
                    ? { backgroundColor: visual.hex, color: '#ffffff' }
                    : undefined
                }
                className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  active
                    ? 'shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <Icon className="w-3.5 h-3.5 shrink-0" aria-hidden="true" />
                <span>{cat}</span>
              </button>
            );
          })}
        </div>

        {/* Status Segmented Filter */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="inline-flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
            {(['All', 'Within Budget', 'Near Limit', 'Over Budget'] as const).map(
              (status) => {
                const active = statusFilter === status;
                const label =
                  status === 'Within Budget'
                    ? 'On Track'
                    : status === 'Over Budget'
                      ? 'Over Target'
                      : status;
                return (
                  <button
                    key={status}
                    type="button"
                    onClick={() => setStatusFilter(status)}
                    className={`relative px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                      active ? 'text-slate-900' : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    {active && (
                      <motion.span
                        layoutId="groceries-status-tab"
                        transition={{ type: 'spring', stiffness: 420, damping: 32 }}
                        className="absolute inset-0 bg-white rounded-md shadow-xs"
                        aria-hidden="true"
                      />
                    )}
                    <span className="relative z-10">{label}</span>
                  </button>
                );
              }
            )}
          </div>

          <div className="flex items-center gap-3">
            {(searchQuery || categoryFilter !== 'All' || statusFilter !== 'All') && (
              <button
                type="button"
                onClick={() => {
                  setSearchQuery('');
                  setCategoryFilter('All');
                  setStatusFilter('All');
                }}
                className="text-xs font-medium text-emerald-700 hover:text-emerald-800 underline underline-offset-2 cursor-pointer"
              >
                Reset filters
              </button>
            )}
            <span className="text-xs text-slate-500 font-mono tabular-nums">
              Showing {filtered.length} {filtered.length === 1 ? 'item' : 'items'}
            </span>
          </div>
        </div>
      </div>

      {/* Purchase Cards List */}
      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-12 text-center space-y-3">
          <div className="text-base font-semibold text-slate-900">
            No matching groceries found
          </div>
          <p className="text-xs text-slate-500">
            Try clearing your search or picking another category, or add a new purchase.
          </p>
          <button
            type="button"
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 text-white text-xs font-medium cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Log Purchase</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
          {filtered.map((rec, idx) => {
            const visual = getCategoryVisual(rec.category, config);
            const Icon = visual.icon;
            const pct = Math.min(100, rec.utilizationPct);

            return (
              <motion.div
                key={rec.id}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.18, delay: Math.min(idx * 0.02, 0.22) }}
                whileHover={{ y: -2 }}
                className="bg-white border border-slate-200 rounded-xl p-4 shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between gap-3"
              >
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 min-w-0">
                    <span
                      className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0"
                      style={{ backgroundColor: `${visual.hex}18`, color: visual.hex }}
                    >
                      <Icon className="w-5 h-5" aria-hidden="true" />
                    </span>
                    <div className="min-w-0">
                      <h3 className="font-medium text-sm text-slate-900 truncate">
                        {rec.itemName}
                      </h3>
                      <div className="text-xs text-slate-500 flex flex-wrap items-center gap-1.5 mt-0.5">
                        <span style={{ color: visual.hex }} className="font-medium">
                          {rec.category}
                        </span>
                        <span aria-hidden="true">·</span>
                        <span>{rec.store}</span>
                        <span aria-hidden="true">·</span>
                        <span className="font-mono tabular-nums">{rec.purchaseDate}</span>
                      </div>
                      {rec.notes && (
                        <p className="text-xs text-slate-500 mt-1 line-clamp-1">
                          {rec.notes}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="text-right font-mono tabular-nums shrink-0">
                    <div className="text-base font-bold text-slate-900">
                      ${rec.totalCost.toFixed(2)}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      {rec.quantity % 1 === 0 ? rec.quantity : rec.quantity.toFixed(2)} × $
                      {rec.unitPrice.toFixed(2)}
                    </div>
                  </div>
                </div>

                {/* Progress Bar vs Item Target */}
                <div className="space-y-1.5">
                  <div className="h-1.5 w-full rounded-full bg-slate-100 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${pct}%`,
                        backgroundColor:
                          rec.status === 'Over Budget' ? '#e11d48' : visual.hex,
                      }}
                    />
                  </div>

                  <div className="flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-3">
                      <StatusLabel status={rec.status} />
                      <span
                        className={`font-mono tabular-nums font-medium ${
                          rec.variance < 0 ? 'text-rose-700' : 'text-emerald-700'
                        }`}
                      >
                        {rec.variance >= 0
                          ? `Saved $${rec.variance.toFixed(2)} (Target $${rec.itemBudget.toFixed(2)})`
                          : `Over by $${Math.abs(rec.variance).toFixed(2)} (Target $${rec.itemBudget.toFixed(2)})`}
                      </span>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={() => onEdit(rec)}
                        className="p-1.5 rounded-md text-slate-500 hover:text-slate-900 hover:bg-slate-100 cursor-pointer"
                        aria-label={`Edit ${rec.itemName}`}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        type="button"
                        onClick={() => onDelete(rec.id)}
                        className="p-1.5 rounded-md text-slate-500 hover:text-rose-700 hover:bg-rose-50 cursor-pointer"
                        aria-label={`Delete ${rec.itemName}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}
