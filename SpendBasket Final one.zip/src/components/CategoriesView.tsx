import { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { Check, Plus, RotateCcw, Trash2 } from 'lucide-react';
import type { BudgetConfig, ExecutiveSummary } from '../types/grocery.ts';
import {
  CUSTOM_COLOR_SWATCHES,
  getCategoryVisual,
} from '../utils/categoryColors.ts';
import { StatusLabel } from './StatusBadge.tsx';

interface CategoriesViewProps {
  config: BudgetConfig;
  summary: ExecutiveSummary;
  onSaveConfig: (next: BudgetConfig) => Promise<{ ok: boolean; error?: string }>;
  onCreateCustomCategory: (payload: {
    name: string;
    color: string;
    budget: number;
  }) => Promise<{ ok: boolean; error?: string }>;
  onDeleteCustomCategory: (name: string) => Promise<void>;
  onOpenCategoryItems: (category: string) => void;
  onResetSampleData: (mode: 'seed' | 'empty') => Promise<void>;
}

export function CategoriesView({
  config,
  summary,
  onSaveConfig,
  onCreateCustomCategory,
  onDeleteCustomCategory,
  onOpenCategoryItems,
  onResetSampleData,
}: CategoriesViewProps) {
  const [overall, setOverall] = useState(String(config.overallMonthlyBudget));
  const [warningPct, setWarningPct] = useState(String(config.warningThresholdPct));
  const [catValues, setCatValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'ok' | 'err'; text: string } | null>(
    null
  );

  // Custom Category Creator State
  const [newName, setNewName] = useState('');
  const [newBudget, setNewBudget] = useState('35');
  const [newColor, setNewColor] = useState(CUSTOM_COLOR_SWATCHES[4]);
  const [addingCat, setAddingCat] = useState(false);
  const [customErr, setCustomErr] = useState<string | null>(null);

  useEffect(() => {
    setOverall(String(config.overallMonthlyBudget));
    setWarningPct(String(config.warningThresholdPct));
    const next: Record<string, string> = {};
    for (const cat of summary.categories) {
      next[cat.category] = String(
        config.categoryBudgets[cat.category] ?? cat.fixedBudget
      );
    }
    setCatValues(next);
  }, [config, summary.categories]);

  const handleSaveAll = async (e: React.FormEvent) => {
    e.preventDefault();
    setMessage(null);
    const overallNum = Number(overall);
    const warningNum = Number(warningPct);
    if (!Number.isFinite(overallNum) || overallNum < 1) {
      setMessage({ type: 'err', text: 'Monthly budget must be at least $1.00.' });
      return;
    }
    if (!Number.isFinite(warningNum) || warningNum < 50 || warningNum > 99) {
      setMessage({ type: 'err', text: 'Alert threshold must be between 50% and 99%.' });
      return;
    }

    const parsedBudgets: Record<string, number> = {};
    for (const cat of summary.categories) {
      const val = Number(catValues[cat.category] ?? cat.fixedBudget);
      if (!Number.isFinite(val) || val < 1) {
        setMessage({
          type: 'err',
          text: `Limit for ${cat.category} must be at least $1.00.`,
        });
        return;
      }
      parsedBudgets[cat.category] = Math.round(val * 100) / 100;
    }

    setSaving(true);
    try {
      const res = await onSaveConfig({
        overallMonthlyBudget: Math.round(overallNum * 100) / 100,
        warningThresholdPct: Math.round(warningNum),
        categoryBudgets: parsedBudgets,
        customCategories: config.customCategories,
      });
      if (res.ok) {
        setMessage({ type: 'ok', text: 'Your monthly & category limits have been saved!' });
      } else {
        setMessage({ type: 'err', text: res.error ?? 'Could not save limits.' });
      }
    } finally {
      setSaving(false);
    }
  };

  const handleAddCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    setCustomErr(null);
    const budgetNum = Number(newBudget);
    if (!newName.trim() || newName.trim().length < 2) {
      setCustomErr('Please enter a category name (at least 2 letters).');
      return;
    }
    if (!Number.isFinite(budgetNum) || budgetNum < 1) {
      setCustomErr('Please enter a monthly limit of at least $1.00.');
      return;
    }

    setAddingCat(true);
    try {
      const res = await onCreateCustomCategory({
        name: newName.trim(),
        color: newColor,
        budget: budgetNum,
      });
      if (res.ok) {
        setNewName('');
        setNewBudget('35');
      } else {
        setCustomErr(res.error ?? 'Unable to create category.');
      }
    } finally {
      setAddingCat(false);
    }
  };

  return (
    <div className="space-y-8">
      <form onSubmit={handleSaveAll} className="space-y-6">
        {/* Overall Monthly Budget Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-100 pb-4">
            <div>
              <h2 className="font-display text-lg font-semibold text-slate-900">
                Monthly Budget & Category Limits
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Set how much you want to spend each month overall and for each grocery aisle.
              </p>
            </div>
            <motion.button
              type="submit"
              whileTap={{ scale: 0.98 }}
              disabled={saving}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-60 text-white text-sm font-medium whitespace-nowrap shrink-0 cursor-pointer"
            >
              <Check className="w-4 h-4" aria-hidden="true" />
              <span>{saving ? 'Saving...' : 'Save All Limits'}</span>
            </motion.button>
          </div>

          {message && (
            <div
              className={`p-3 rounded-lg border text-xs ${
                message.type === 'ok'
                  ? 'border-emerald-200 bg-emerald-50 text-emerald-800'
                  : 'border-rose-200 bg-rose-50 text-rose-800'
              }`}
            >
              {message.text}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            <div>
              <label
                htmlFor="overall-budget"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Monthly Grocery Budget ($)
              </label>
              <input
                id="overall-budget"
                type="number"
                step="1"
                value={overall}
                onChange={(e) => setOverall(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm font-mono tabular-nums rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-emerald-600"
              />
            </div>

            <div>
              <label
                htmlFor="warning-threshold"
                className="block text-xs font-medium text-slate-700 mb-1"
              >
                Early Warning Alert (%)
              </label>
              <input
                id="warning-threshold"
                type="number"
                min="50"
                max="99"
                value={warningPct}
                onChange={(e) => setWarningPct(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm font-mono tabular-nums rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-emerald-600"
              />
              <p className="mt-1 text-xs text-slate-500">
                Alert me once spending reaches {warningPct}% of a limit.
              </p>
            </div>
          </div>
        </div>

        {/* Colorful All-Categories Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {summary.categories.map((cat, idx) => {
            const visual = getCategoryVisual(cat.category, config);
            const Icon = visual.icon;
            const fillPct = Math.min(100, cat.utilizationPct);

            return (
              <motion.div
                key={cat.category}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.2, delay: Math.min(idx * 0.025, 0.25) }}
                className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-xs flex flex-col justify-between"
              >
                <div className="h-1.5" style={{ backgroundColor: visual.hex }} />
                <div className="p-4 space-y-3 flex-1">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-2.5 min-w-0">
                      <span
                        className="w-9 h-9 rounded-lg flex items-center justify-center shrink-0"
                        style={{ backgroundColor: `${visual.hex}18`, color: visual.hex }}
                      >
                        <Icon className="w-4 h-4" aria-hidden="true" />
                      </span>
                      <div className="min-w-0">
                        <div className="text-sm font-semibold text-slate-900 truncate">
                          {cat.category}
                        </div>
                        <button
                          type="button"
                          onClick={() => onOpenCategoryItems(cat.category)}
                          className="text-[11px] text-slate-500 hover:text-emerald-700 underline underline-offset-2 cursor-pointer"
                        >
                          {cat.itemCount} {cat.itemCount === 1 ? 'item' : 'items'}
                        </button>
                      </div>
                    </div>

                    {cat.isCustom && (
                      <button
                        type="button"
                        onClick={() => onDeleteCustomCategory(cat.category)}
                        className="p-1 rounded-md text-slate-400 hover:text-rose-600 hover:bg-rose-50 cursor-pointer"
                        aria-label={`Remove custom category ${cat.category}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>

                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs font-mono tabular-nums">
                      <span className="font-semibold text-slate-900">
                        ${cat.totalSpend.toFixed(2)} spent
                      </span>
                      <span className="text-slate-500">
                        {cat.utilizationPct.toFixed(0)}%
                      </span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-slate-100 overflow-hidden">
                      <motion.div
                        initial={{ width: 0 }}
                        animate={{ width: `${fillPct}%` }}
                        transition={{ duration: 0.45 }}
                        className="h-full rounded-full"
                        style={{
                          backgroundColor:
                            cat.status === 'Over Budget' ? '#e11d48' : visual.hex,
                        }}
                      />
                    </div>
                    <StatusLabel status={cat.status} compact />
                  </div>

                  <div>
                    <label
                      htmlFor={`limit-${cat.category}`}
                      className="block text-[11px] font-medium text-slate-500 mb-1"
                    >
                      Monthly Limit ($)
                    </label>
                    <input
                      id={`limit-${cat.category}`}
                      type="number"
                      step="1"
                      value={catValues[cat.category] ?? String(cat.fixedBudget)}
                      onChange={(e) =>
                        setCatValues((prev) => ({
                          ...prev,
                          [cat.category]: e.target.value,
                        }))
                      }
                      className="w-full px-3 py-1.5 text-sm font-mono tabular-nums rounded-lg border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-emerald-600"
                    />
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </form>

      {/* Add Custom Category Card */}
      <section className="bg-white border border-slate-200 rounded-2xl p-6 shadow-xs space-y-4">
        <div>
          <h3 className="font-display text-base font-semibold text-slate-900">
            Create Your Own Category
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Need a specific aisle like Party Food, Fitness Supplements, or Gardening? Add it here.
          </p>
        </div>

        {customErr && (
          <div className="p-3 rounded-lg border border-rose-200 bg-rose-50 text-xs text-rose-800">
            {customErr}
          </div>
        )}

        <form
          onSubmit={handleAddCategory}
          className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end"
        >
          <div className="md:col-span-5">
            <label htmlFor="custom-cat-name" className="block text-xs font-medium text-slate-700 mb-1">
              Category Name
            </label>
            <input
              id="custom-cat-name"
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g. Organic Smoothies or Party Supplies"
              className="w-full px-3 py-2 text-sm rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-emerald-600"
            />
          </div>

          <div className="md:col-span-2">
            <label htmlFor="custom-cat-budget" className="block text-xs font-medium text-slate-700 mb-1">
              Monthly Limit ($)
            </label>
            <input
              id="custom-cat-budget"
              type="number"
              step="1"
              value={newBudget}
              onChange={(e) => setNewBudget(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono tabular-nums rounded-xl border border-slate-300 bg-white text-slate-900 focus:outline-none focus:border-emerald-600"
            />
          </div>

          <div className="md:col-span-3">
            <span className="block text-xs font-medium text-slate-700 mb-1.5">
              Pick Color
            </span>
            <div className="flex flex-wrap items-center gap-1.5">
              {CUSTOM_COLOR_SWATCHES.map((swatch) => (
                <button
                  key={swatch}
                  type="button"
                  onClick={() => setNewColor(swatch)}
                  style={{ backgroundColor: swatch }}
                  className={`w-6 h-6 rounded-full cursor-pointer transition-transform ${
                    newColor === swatch
                      ? 'ring-2 ring-offset-2 ring-slate-900 scale-110'
                      : 'hover:scale-105'
                  }`}
                  aria-label={`Select color ${swatch}`}
                />
              ))}
            </div>
          </div>

          <div className="md:col-span-2">
            <button
              type="submit"
              disabled={addingCat}
              className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-sm font-medium cursor-pointer whitespace-nowrap"
            >
              <Plus className="w-4 h-4" />
              <span>{addingCat ? 'Adding...' : 'Add Category'}</span>
            </button>
          </div>
        </form>
      </section>

      {/* Simple Reset Options */}
      <div className="bg-white border border-slate-200 rounded-2xl p-5 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h3 className="font-display text-sm font-semibold text-slate-900">
            Start Fresh or Load Sample Groceries
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Clear your grocery list to start from $0, or restore the sample household month.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => onResetSampleData('empty')}
            className="px-3.5 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-700 cursor-pointer"
          >
            Clear All Items
          </button>
          <button
            type="button"
            onClick={() => onResetSampleData('seed')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl border border-slate-300 bg-white hover:bg-slate-50 text-xs font-medium text-slate-900 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
            <span>Load Sample Month</span>
          </button>
        </div>
      </div>
    </div>
  );
}
