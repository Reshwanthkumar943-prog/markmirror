import { AlertTriangle, CheckCircle2, XOctagon } from 'lucide-react';
import type { BudgetStatus } from '../types/grocery.ts';

interface StatusLabelProps {
  status: BudgetStatus;
  compact?: boolean;
}

export function StatusLabel({ status, compact = false }: StatusLabelProps) {
  if (status === 'Over Budget') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-rose-700 whitespace-nowrap shrink-0">
        <XOctagon className="w-3.5 h-3.5 text-rose-600 shrink-0" aria-hidden="true" />
        <span>{compact ? 'Over' : 'Over Target'}</span>
      </span>
    );
  }

  if (status === 'Near Limit') {
    return (
      <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-700 whitespace-nowrap shrink-0">
        <AlertTriangle className="w-3.5 h-3.5 text-amber-600 shrink-0" aria-hidden="true" />
        <span>{compact ? 'Near' : 'Near Limit'}</span>
      </span>
    );
  }

  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-700 whitespace-nowrap shrink-0">
      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" aria-hidden="true" />
      <span>{compact ? 'On Track' : 'On Track'}</span>
    </span>
  );
}
