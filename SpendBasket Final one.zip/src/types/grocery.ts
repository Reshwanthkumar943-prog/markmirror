export const BUILT_IN_CATEGORIES = [
  'Fresh Fruits & Veggies',
  'Milk, Cheese & Eggs',
  'Meat, Poultry & Fish',
  'Bread & Bakery',
  'Snacks & Sweets',
  'Drinks & Coffee',
  'Rice, Pasta & Grains',
  'Spices, Sauces & Oils',
  'Frozen Meals & Ice Cream',
  'Breakfast & Cereal',
  'Baby & Pet Care',
  'Cleaning & Home Supplies',
] as const;

export type BuiltInCategory = (typeof BUILT_IN_CATEGORIES)[number];
export type GroceryCategory = string;

export type BudgetStatus = 'Within Budget' | 'Near Limit' | 'Over Budget';

export interface CustomCategoryDef {
  name: string;
  color: string;
  budget: number;
}

export interface GroceryRecord {
  id: string;
  itemName: string;
  category: GroceryCategory;
  quantity: number;
  unitPrice: number;
  totalCost: number;
  itemBudget: number;
  purchaseDate: string; // YYYY-MM-DD
  store: string;
  notes: string;
  createdAt: string;
}

export interface GroceryRecordInput {
  itemName: string;
  category: string;
  quantity: number | string;
  unitPrice: number | string;
  itemBudget: number | string;
  purchaseDate: string;
  store: string;
  notes?: string;
}

export interface EvaluatedRecord extends GroceryRecord {
  variance: number;
  utilizationPct: number;
  status: BudgetStatus;
  isAnomalous: boolean;
  anomalyReason: string | null;
}

export interface BudgetConfig {
  overallMonthlyBudget: number;
  warningThresholdPct: number;
  categoryBudgets: Record<string, number>;
  customCategories: CustomCategoryDef[];
}

export interface CategorySummary {
  category: string;
  color: string;
  isCustom: boolean;
  itemCount: number;
  totalSpend: number;
  fixedBudget: number;
  variance: number;
  utilizationPct: number;
  status: BudgetStatus;
  overspentItemCount: number;
  averageItemCost: number;
}

export interface DailySpendPoint {
  date: string;
  dailySpend: number;
  cumulativeSpend: number;
  budgetCeiling: number;
}

export interface ThresholdWarning {
  id: string;
  severity: 'critical' | 'warning';
  scope: 'Monthly Budget' | 'Category Limit' | 'Item Target' | 'Price Spike';
  title: string;
  detail: string;
  amountDelta: number;
}

export interface ExecutiveSummary {
  totalSpend: number;
  overallBudget: number;
  remainingBudget: number;
  overallUtilizationPct: number;
  overallStatus: BudgetStatus;
  totalEntries: number;
  averageEntryCost: number;
  overspentEntriesCount: number;
  nearLimitEntriesCount: number;
  withinBudgetEntriesCount: number;
  complianceRatePct: number;
  highestCategory: CategorySummary | null;
  categories: CategorySummary[];
  dailyTrend: DailySpendPoint[];
  warnings: ThresholdWarning[];
}

export interface FieldValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  valid: boolean;
  errors: FieldValidationError[];
  sanitized?: Omit<GroceryRecord, 'id' | 'createdAt'>;
}
