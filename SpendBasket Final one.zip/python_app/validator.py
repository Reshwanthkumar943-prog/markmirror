"""Defensive input validation and terminal prompt wrappers."""
from __future__ import annotations

import re
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from models import VALID_CATEGORIES

DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")
SAFE_TEXT_PATTERN = re.compile(r"^[\w\s\-.,&'()/%#]+$")


def sanitize_text(value: str) -> str:
    cleaned = re.sub(r"[\r\n\t\x00-\x1f\x7f]", " ", str(value))
    return re.sub(r"\s+", " ", cleaned).strip()


def normalize_category(raw: str) -> Optional[str]:
    cleaned = sanitize_text(raw).lower()
    for category in VALID_CATEGORIES:
        if category.lower() == cleaned:
            return category
    return None


def validate_calendar_date(date_str: str) -> bool:
    if not DATE_PATTERN.match(date_str):
        return False
    try:
        parsed = datetime.strptime(date_str, "%Y-%m-%d")
        return 2000 <= parsed.year <= 2100
    except ValueError:
        return False


def validate_record_payload(
    payload: Dict[str, object],
) -> Tuple[List[str], Optional[Dict[str, object]]]:
    errors: List[str] = []

    item_name = sanitize_text(str(payload.get("item_name", "")))
    if not item_name or len(item_name) < 2 or len(item_name) > 80:
        errors.append("item_name: Must be between 2 and 80 non-blank characters.")
    elif not SAFE_TEXT_PATTERN.match(item_name):
        errors.append("item_name: Contains unsupported special characters.")

    category = normalize_category(str(payload.get("category", "")))
    if not category:
        errors.append(f"category: Must be one of {', '.join(VALID_CATEGORIES)}.")

    try:
        quantity = float(str(payload.get("quantity", 0)))
        if not (0 < quantity <= 10000):
            errors.append("quantity: Must be > 0 and <= 10,000.")
    except (TypeError, ValueError):
        quantity = 0.0
        errors.append("quantity: Must be a valid number.")

    try:
        unit_price = float(str(payload.get("unit_price", 0)))
        if not (0.01 <= unit_price <= 100000):
            errors.append("unit_price: Must be between 0.01 and 100,000.00.")
    except (TypeError, ValueError):
        unit_price = 0.0
        errors.append("unit_price: Must be a valid currency amount.")

    try:
        item_budget = float(str(payload.get("item_budget", 0)))
        if not (0.01 <= item_budget <= 100000):
            errors.append("item_budget: Must be between 0.01 and 100,000.00.")
    except (TypeError, ValueError):
        item_budget = 0.0
        errors.append("item_budget: Must be a valid currency amount.")

    purchase_date = sanitize_text(str(payload.get("purchase_date", "")))
    if not validate_calendar_date(purchase_date):
        errors.append("purchase_date: Must be a valid calendar date (YYYY-MM-DD).")

    store = sanitize_text(str(payload.get("store", "")))
    if not store or len(store) < 2 or len(store) > 50:
        errors.append("store: Must be between 2 and 50 characters.")

    notes = sanitize_text(str(payload.get("notes", "")))[:160]

    if errors or not category:
        return errors, None

    rounded_qty = round(quantity, 2)
    rounded_price = round(unit_price, 2)
    total_cost = round(rounded_qty * rounded_price, 2)
    return [], {
        "item_name": item_name,
        "category": category,
        "quantity": rounded_qty,
        "unit_price": rounded_price,
        "total_cost": total_cost,
        "item_budget": round(item_budget, 2),
        "purchase_date": purchase_date,
        "store": store,
        "notes": notes,
    }


def prompt_non_empty_text(label: str, min_len: int = 2, max_len: int = 80) -> str:
    while True:
        raw = sanitize_text(input(f"{label}: "))
        if min_len <= len(raw) <= max_len and SAFE_TEXT_PATTERN.match(raw):
            return raw
        print(f"  [Invalid] Enter {min_len}-{max_len} valid characters.")


def prompt_positive_float(
    label: str, min_val: float = 0.01, max_val: float = 100000.0
) -> float:
    while True:
        raw = input(f"{label}: ").strip()
        try:
            val = float(raw)
            if min_val <= val <= max_val:
                return round(val, 2)
            print(f"  [Invalid] Value must be between {min_val:.2f} and {max_val:,.2f}.")
        except ValueError:
            print("  [Invalid] Please enter a valid numeric value.")


def prompt_valid_date(label: str) -> str:
    while True:
        raw = sanitize_text(input(f"{label} (YYYY-MM-DD): "))
        if validate_calendar_date(raw):
            return raw
        print("  [Invalid] Date must be a real calendar date in YYYY-MM-DD format.")


def prompt_category() -> str:
    print("  Available Categories:")
    for idx, cat in enumerate(VALID_CATEGORIES, start=1):
        print(f"    {idx}. {cat}")
    while True:
        raw = input("Select category (number or name): ").strip()
        if raw.isdigit():
            idx = int(raw)
            if 1 <= idx <= len(VALID_CATEGORIES):
                return VALID_CATEGORIES[idx - 1]
        matched = normalize_category(raw)
        if matched:
            return matched
        print("  [Invalid] Choose a valid category number or name.")
