# SpendBasket — Python Web Server & CLI Suite

Standalone Python 3.10+ web server, interactive terminal assistant, and reporting suite for **SpendBasket (Grocery Budget Assistant)**.

## 1. Run the Full Website via Python (Zero Dependencies)
```bash
python3 web_server.py
```
Then open **`http://localhost:8000`** in your browser.

## 2. Run the Interactive Python CLI
```bash
python3 main.py
```

## 3. Run Automated Unit & API Tests
```bash
python3 -m unittest discover -s . -v
```

## 4. Optional Matplotlib PNG Charts
```bash
pip install -r requirements.txt
```
*(If Matplotlib is not installed, `charts.py` automatically generates an ASCII chart fallback.)*
