"""Matplotlib chart exports with graceful fallback when Matplotlib is unavailable."""
from __future__ import annotations

from collections import defaultdict
from pathlib import Path
from typing import Dict, List

from models import BudgetConfig, GroceryRecord, VALID_CATEGORIES


def generate_budget_charts(
    records: List[GroceryRecord],
    config: BudgetConfig,
    output_dir: Path,
) -> List[Path]:
    output_dir.mkdir(parents=True, exist_ok=True)
    generated: List[Path] = []

    try:
        import matplotlib.pyplot as plt
    except ImportError:
        fallback_txt = output_dir / "chart_ascii_fallback.txt"
        cat_totals: Dict[str, float] = defaultdict(float)
        for r in records:
            cat_totals[r.category] += r.total_cost
        lines = ["Matplotlib not installed — ASCII Spend Distribution Fallback", "=" * 60]
        for cat in VALID_CATEGORIES:
            spent = cat_totals.get(cat, 0.0)
            cap = config.category_budgets.get(cat, 0.0)
            bars = "#" * min(40, int(spent / 3))
            flag = " [OVER]" if spent > cap else ""
            lines.append(f"{cat:<16} | {bars:<40} ${spent:>6.2f} / ${cap:>6.2f}{flag}")
        fallback_txt.write_text("\n".join(lines), encoding="utf-8")
        return [fallback_txt]

    cat_totals = defaultdict(float)
    for r in records:
        cat_totals[r.category] += r.total_cost

    categories = list(VALID_CATEGORIES)
    actuals = [round(cat_totals.get(c, 0.0), 2) for c in categories]
    budgets = [round(config.category_budgets.get(c, 0.0), 2) for c in categories]

    fig, ax = plt.subplots(figsize=(10, 5.5))
    x = range(len(categories))
    width = 0.38
    ax.bar([i - width / 2 for i in x], actuals, width, label="Actual Spend", color="#059669")
    ax.bar([i + width / 2 for i in x], budgets, width, label="Fixed Budget", color="#94A3B8")
    ax.set_xticks(list(x))
    ax.set_xticklabels(categories, rotation=25, ha="right")
    ax.set_ylabel("Amount ($ USD)")
    ax.set_title("Grocery Spend vs. Fixed Category Budget")
    ax.legend()
    ax.grid(axis="y", linestyle="--", alpha=0.4)
    plt.tight_layout()

    bar_path = output_dir / "category_budget_comparison.png"
    fig.savefig(bar_path, dpi=150)
    plt.close(fig)
    generated.append(bar_path)
    return generated
