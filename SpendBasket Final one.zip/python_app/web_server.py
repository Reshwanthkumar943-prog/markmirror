"""Pure Python 3.10+ HTTP web server for SpendBasket (zero external dependencies)."""
from __future__ import annotations

import json
import mimetypes
import re
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import unquote, urlparse

from models import BudgetConfig, GroceryRecord, VALID_CATEGORIES
from storage import (
    load_raw_budget_config,
    load_records,
    record_to_api_dict,
    save_raw_budget_config,
    save_records,
)
from validator import sanitize_text, validate_calendar_date

ROOT_DIR = Path(__file__).resolve().parent.parent
DIST_DIR = ROOT_DIR / "dist"


def validate_web_payload(
    payload: Dict[str, Any], allowed_categories: List[str]
) -> Tuple[List[Dict[str, str]], Optional[Dict[str, Any]]]:
    errors: List[Dict[str, str]] = []

    item_name = sanitize_text(str(payload.get("itemName", payload.get("item_name", ""))))
    if not item_name or len(item_name) < 2 or len(item_name) > 80:
        errors.append(
            {"field": "itemName", "message": "Item name should be between 2 and 80 characters."}
        )

    raw_category = sanitize_text(str(payload.get("category", "")))
    resolved_cat = raw_category
    if not raw_category or len(raw_category) < 2 or len(raw_category) > 50:
        errors.append({"field": "category", "message": "Please choose or enter a category."})
    else:
        for cat in allowed_categories:
            if cat.lower() == raw_category.lower():
                resolved_cat = cat
                break

    try:
        quantity = float(payload.get("quantity", 0))
        if not (0 < quantity <= 10000):
            raise ValueError
    except (TypeError, ValueError):
        quantity = 0.0
        errors.append({"field": "quantity", "message": "Quantity must be greater than 0."})

    try:
        unit_price = float(payload.get("unitPrice", payload.get("unit_price", 0)))
        if not (0.01 <= unit_price <= 100000):
            raise ValueError
    except (TypeError, ValueError):
        unit_price = 0.0
        errors.append({"field": "unitPrice", "message": "Price must be at least $0.01."})

    try:
        item_budget = float(payload.get("itemBudget", payload.get("item_budget", 0)))
        if not (0.01 <= item_budget <= 100000):
            raise ValueError
    except (TypeError, ValueError):
        item_budget = 0.0
        errors.append({"field": "itemBudget", "message": "Target limit must be at least $0.01."})

    purchase_date = sanitize_text(
        str(payload.get("purchaseDate", payload.get("purchase_date", "")))
    )
    if not validate_calendar_date(purchase_date):
        errors.append({"field": "purchaseDate", "message": "Please pick a valid date."})

    store = sanitize_text(str(payload.get("store", "")))
    if not store or len(store) < 2 or len(store) > 50:
        errors.append({"field": "store", "message": "Store name should be 2-50 characters."})

    notes = sanitize_text(str(payload.get("notes", "")))[:160]

    if errors:
        return errors, None

    rounded_qty = round(quantity, 2)
    rounded_price = round(unit_price, 2)
    return [], {
        "item_name": item_name,
        "category": resolved_cat,
        "quantity": rounded_qty,
        "unit_price": rounded_price,
        "total_cost": round(rounded_qty * rounded_price, 2),
        "item_budget": round(item_budget, 2),
        "purchase_date": purchase_date,
        "store": store,
        "notes": notes,
    }


class SpendBasketHandler(BaseHTTPRequestHandler):
    def log_message(self, format: str, *args: object) -> None:
        # Clean concise request logs
        super().log_message(format, *args)

    def _send_json(self, status: int, data: object) -> None:
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _read_json_body(self) -> Dict[str, Any]:
        length = int(self.headers.get("Content-Length", "0"))
        if length <= 0:
            return {}
        raw = self.rfile.read(length).decode("utf-8")
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else {}

    def do_GET(self) -> None:
        parsed_url = urlparse(self.path)
        req_path = parsed_url.path

        if req_path == "/api/health":
            self._send_json(HTTPStatus.OK, {"ok": True, "runtime": "python"})
            return

        if req_path == "/api/state":
            records, _ = load_records()
            cfg = load_raw_budget_config()
            self._send_json(
                HTTPStatus.OK,
                {
                    "records": [record_to_api_dict(r) for r in records],
                    "budgetConfig": cfg,
                },
            )
            return

        # Serve built React frontend from dist/
        if DIST_DIR.exists():
            rel = "index.html" if req_path == "/" else req_path.lstrip("/")
            candidate = (DIST_DIR / rel).resolve()
            if str(candidate).startswith(str(DIST_DIR.resolve())) and candidate.is_file():
                mime, _ = mimetypes.guess_type(str(candidate))
                content = candidate.read_bytes()
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", mime or "application/octet-stream")
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return

            index_file = DIST_DIR / "index.html"
            if index_file.exists():
                content = index_file.read_bytes()
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(content)))
                self.end_headers()
                self.wfile.write(content)
                return

        self._send_json(
            HTTPStatus.OK,
            {
                "app": "SpendBasket Python Web Server",
                "note": "API running. Build frontend with 'npm run build' or run 'python3 python_app/main.py' for CLI.",
            },
        )

    def do_POST(self) -> None:
        req_path = urlparse(self.path).path
        body = self._read_json_body()

        if req_path == "/api/records":
            cfg = load_raw_budget_config()
            custom_names = [
                str(c.get("name", ""))
                for c in cfg.get("customCategories", [])  # type: ignore[union-attr]
            ]
            errs, cleaned = validate_web_payload(body, list(VALID_CATEGORIES) + custom_names)
            if errs or not cleaned:
                self._send_json(
                    HTTPStatus.BAD_REQUEST, {"error": "Validation failed", "errors": errs}
                )
                return

            records, _ = load_records()
            existing_ids = {r.id for r in records}
            next_num = 1001 + len(records)
            while f"GRB-{next_num}" in existing_ids:
                next_num += 1

            rec = GroceryRecord(
                id=f"GRB-{next_num}",
                created_at=datetime.now(timezone.utc).isoformat(),
                **cleaned,
            )
            updated = [rec, *records]
            save_records(updated)
            self._send_json(
                HTTPStatus.CREATED,
                {
                    "record": record_to_api_dict(rec),
                    "records": [record_to_api_dict(r) for r in updated],
                },
            )
            return

        if req_path == "/api/categories":
            name = sanitize_text(str(body.get("name", "")))
            color = sanitize_text(str(body.get("color", "#10b981")))
            try:
                budget = float(body.get("budget", 0))
            except (TypeError, ValueError):
                budget = 0.0

            if len(name) < 2 or len(name) > 40:
                self._send_json(
                    HTTPStatus.BAD_REQUEST,
                    {"error": "Category name must be between 2 and 40 characters."},
                )
                return
            if budget < 1 or budget > 500000:
                self._send_json(
                    HTTPStatus.BAD_REQUEST,
                    {"error": "Category budget must be at least $1.00."},
                )
                return

            cfg = load_raw_budget_config()
            customs: List[Dict[str, Any]] = list(cfg.get("customCategories", []))  # type: ignore[arg-type]
            if any(c.lower() == name.lower() for c in VALID_CATEGORIES) or any(
                str(c.get("name", "")).lower() == name.lower() for c in customs
            ):
                self._send_json(
                    HTTPStatus.BAD_REQUEST, {"error": f'Category "{name}" already exists.'}
                )
                return

            safe_color = color if re.match(r"^#[0-9a-fA-F]{6}$", color) else "#10b981"
            customs.append({"name": name, "color": safe_color, "budget": round(budget, 2)})
            cat_budgets: Dict[str, Any] = dict(cfg.get("categoryBudgets", {}))  # type: ignore[arg-type]
            cat_budgets[name] = round(budget, 2)
            cfg["customCategories"] = customs
            cfg["categoryBudgets"] = cat_budgets
            save_raw_budget_config(cfg)
            self._send_json(HTTPStatus.CREATED, {"budgetConfig": cfg})
            return

        if req_path == "/api/reset":
            mode = body.get("mode")
            if mode == "empty":
                save_records([])
                cfg = {
                    "overallMonthlyBudget": BudgetConfig().overall_monthly_budget,
                    "warningThresholdPct": BudgetConfig().warning_threshold_pct,
                    "categoryBudgets": dict(BudgetConfig().category_budgets),
                    "customCategories": [],
                }
                save_raw_budget_config(cfg)
                self._send_json(HTTPStatus.OK, {"records": [], "budgetConfig": cfg})
                return
            records, _ = load_records()
            cfg = load_raw_budget_config()
            self._send_json(
                HTTPStatus.OK,
                {
                    "records": [record_to_api_dict(r) for r in records],
                    "budgetConfig": cfg,
                },
            )
            return

        self._send_json(HTTPStatus.NOT_FOUND, {"error": "Endpoint not found"})

    def do_PUT(self) -> None:
        req_path = urlparse(self.path).path
        body = self._read_json_body()

        if req_path.startswith("/api/records/"):
            rec_id = unquote(req_path.split("/api/records/", 1)[1])
            cfg = load_raw_budget_config()
            custom_names = [
                str(c.get("name", ""))
                for c in cfg.get("customCategories", [])  # type: ignore[union-attr]
            ]
            errs, cleaned = validate_web_payload(body, list(VALID_CATEGORIES) + custom_names)
            if errs or not cleaned:
                self._send_json(
                    HTTPStatus.BAD_REQUEST, {"error": "Validation failed", "errors": errs}
                )
                return

            records, _ = load_records()
            idx = next((i for i, r in enumerate(records) if r.id == rec_id), -1)
            if idx == -1:
                self._send_json(HTTPStatus.NOT_FOUND, {"error": f"Item {rec_id} not found"})
                return

            updated_rec = GroceryRecord(
                id=rec_id, created_at=records[idx].created_at, **cleaned
            )
            records[idx] = updated_rec
            save_records(records)
            self._send_json(
                HTTPStatus.OK,
                {
                    "record": record_to_api_dict(updated_rec),
                    "records": [record_to_api_dict(r) for r in records],
                },
            )
            return

        if req_path == "/api/budget":
            try:
                overall = float(body.get("overallMonthlyBudget", 0))
                warning = float(body.get("warningThresholdPct", 85))
            except (TypeError, ValueError):
                self._send_json(HTTPStatus.BAD_REQUEST, {"error": "Invalid budget numbers."})
                return

            if overall < 1 or overall > 1000000:
                self._send_json(
                    HTTPStatus.BAD_REQUEST, {"error": "Monthly budget must be at least $1.00."}
                )
                return
            if warning < 50 or warning > 99:
                self._send_json(
                    HTTPStatus.BAD_REQUEST,
                    {"error": "Warning threshold must be between 50% and 99%."},
                )
                return

            cfg = load_raw_budget_config()
            cfg["overallMonthlyBudget"] = round(overall, 2)
            cfg["warningThresholdPct"] = round(warning)
            if isinstance(body.get("categoryBudgets"), dict):
                next_cats = dict(cfg.get("categoryBudgets", {}))  # type: ignore[arg-type]
                for k, v in body["categoryBudgets"].items():
                    next_cats[str(k)] = round(float(v), 2)
                cfg["categoryBudgets"] = next_cats
            save_raw_budget_config(cfg)
            self._send_json(HTTPStatus.OK, {"budgetConfig": cfg})
            return

        self._send_json(HTTPStatus.NOT_FOUND, {"error": "Endpoint not found"})

    def do_DELETE(self) -> None:
        req_path = urlparse(self.path).path

        if req_path.startswith("/api/records/"):
            rec_id = unquote(req_path.split("/api/records/", 1)[1])
            records, _ = load_records()
            updated = [r for r in records if r.id != rec_id]
            if len(updated) == len(records):
                self._send_json(HTTPStatus.NOT_FOUND, {"error": f"Item {rec_id} not found"})
                return
            save_records(updated)
            self._send_json(
                HTTPStatus.OK, {"records": [record_to_api_dict(r) for r in updated]}
            )
            return

        if req_path.startswith("/api/categories/"):
            target = unquote(req_path.split("/api/categories/", 1)[1])
            cfg = load_raw_budget_config()
            customs = [
                c
                for c in cfg.get("customCategories", [])  # type: ignore[union-attr]
                if str(c.get("name", "")).lower() != target.lower()
            ]
            cat_budgets: Dict[str, Any] = dict(cfg.get("categoryBudgets", {}))  # type: ignore[arg-type]
            cat_budgets.pop(target, None)
            cfg["customCategories"] = customs
            cfg["categoryBudgets"] = cat_budgets
            save_raw_budget_config(cfg)
            self._send_json(HTTPStatus.OK, {"budgetConfig": cfg})
            return

        self._send_json(HTTPStatus.NOT_FOUND, {"error": "Endpoint not found"})


def run_server(port: int = 8000) -> None:
    server = ThreadingHTTPServer(("0.0.0.0", port), SpendBasketHandler)
    print(f"SpendBasket Python Web Server running at http://localhost:{port}")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down SpendBasket Python Web Server.")
        server.server_close()


if __name__ == "__main__":
    run_server(8000)
