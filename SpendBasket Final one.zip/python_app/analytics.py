"""Core business logic engine for budget comparisons and executive reporting."""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

from models import BudgetConfig, GroceryRecord, VALID_CATEGORIES


def classify_status(spent: float, budget: float, warning_pct: float = 85.0) -> str:
    if budget <= 0 or spent > budget + 0.001:
        return "Over Budget"
    if (spent / budget) * 100.0 >= warning_pct:
        return "Near Limit"
    return "Within Budget"


def compute_executive_summary(
    records: List[GroceryRecord], config: BudgetConfig
) -> Dict[str, Any]:
    total_spend = round(sum(r.total_cost for r in records), 2)
    overall_budget = round(config.overall_monthly_budget, 2)
    remaining = round(overall_budget - total_spend, 2)
    utilization = (
        round((total_spend / overall_budget) * 100.0, 1) if overall_budget > 0 else 0.0
    )
    overall_status = classify_status(
        total_spend, overall_budget, config.warning_threshold_pct
    )

    overspent_items = [r for r in records if r.total_cost > r.item_budget + 0.001]
    cat_totals: Dict[str, float] = defaultdict(float)
    cat_counts: Dict[str, int] = defaultdict(int)
    for r in records:
        cat_totals[r.category] += r.total_cost
        cat_counts[r.category] += 1

    category_rows = []
    for cat in VALID_CATEGORIES:
        spent = round(cat_totals.get(cat, 0.0), 2)
        cap = round(config.category_budgets.get(cat, 0.0), 2)
        variance = round(cap - spent, 2)
        util = round((spent / cap) * 100.0, 1) if cap > 0 else 0.0
        category_rows.append(
            {
                "category": cat,
                "items": cat_counts.get(cat, 0),
                "spent": spent,
                "budget": cap,
                "variance": variance,
                "utilization_pct": util,
                "status": classify_status(spent, cap, config.warning_threshold_pct),
            }
        )

    return {
        "total_spend": total_spend,
        "overall_budget": overall_budget,
        "remaining": remaining,
        "utilization_pct": utilization,
        "overall_status": overall_status,
        "total_entries": len(records),
        "average_cost": round(total_spend / len(records), 2) if records else 0.0,
        "overspent_count": len(overspent_items),
        "overspent_items": overspent_items,
        "categories": category_rows,
    }


def export_markdown_report(
    records: List[GroceryRecord], config: BudgetConfig, out_path: Path
) -> Path:
    summary = compute_executive_summary(records, config)
    lines = [
        "# Grocery Budget Assistant — Executive Summary",
        f"Generated: {datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S UTC')}",
        f"Status: **{summary['overall_status']}** ({summary['utilization_pct']}% of ${summary['overall_budget']:.2f})",
        "",
        "| Category | Items | Spent | Fixed Budget | Variance | Status |",
        "| :--- | ---: | ---: | ---: | ---: | :--- |",
    ]
    for row in summary["categories"]:
        lines.append(
            f"| {row['category']} | {row['items']} | ${row['spent']:.2f} | ${row['budget']:.2f} | ${row['variance']:+.2f} | {row['status']} |"
        )
    out_path.write_text("\n".join(lines), encoding="utf-8")
    return out_path
