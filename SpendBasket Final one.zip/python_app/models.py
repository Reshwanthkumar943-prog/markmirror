"""Core data models for SpendBasket — Grocery Budget Assistant."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Dict, List


VALID_CATEGORIES: List[str] = [
    "Fresh Fruits & Veggies",
    "Milk, Cheese & Eggs",
    "Meat, Poultry & Fish",
    "Bread & Bakery",
    "Snacks & Sweets",
    "Drinks & Coffee",
    "Rice, Pasta & Grains",
    "Spices, Sauces & Oils",
    "Frozen Meals & Ice Cream",
    "Breakfast & Cereal",
    "Baby & Pet Care",
    "Cleaning & Home Supplies",
]

DEFAULT_CATEGORY_BUDGETS: Dict[str, float] = {
    "Fresh Fruits & Veggies": 80.0,
    "Milk, Cheese & Eggs": 55.0,
    "Meat, Poultry & Fish": 95.0,
    "Bread & Bakery": 35.0,
    "Snacks & Sweets": 35.0,
    "Drinks & Coffee": 45.0,
    "Rice, Pasta & Grains": 45.0,
    "Spices, Sauces & Oils": 35.0,
    "Frozen Meals & Ice Cream": 40.0,
    "Breakfast & Cereal": 30.0,
    "Baby & Pet Care": 35.0,
    "Cleaning & Home Supplies": 30.0,
}


@dataclass
class GroceryRecord:
    id: str
    item_name: str
    category: str
    quantity: float
    unit_price: float
    total_cost: float
    item_budget: float
    purchase_date: str
    store: str
    notes: str = ""
    created_at: str = ""

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)

    @property
    def variance(self) -> float:
        return round(self.item_budget - self.total_cost, 2)

    @property
    def utilization_pct(self) -> float:
        if self.item_budget <= 0:
            return 100.0
        return round((self.total_cost / self.item_budget) * 100.0, 1)


@dataclass
class BudgetConfig:
    overall_monthly_budget: float = 560.0
    warning_threshold_pct: float = 85.0
    category_budgets: Dict[str, float] = field(
        default_factory=lambda: dict(DEFAULT_CATEGORY_BUDGETS)
    )

    def to_dict(self) -> Dict[str, object]:
        return asdict(self)
