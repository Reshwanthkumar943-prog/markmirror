"""Local JSON/CSV persistence with defensive corruption recovery."""
from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from models import BudgetConfig, GroceryRecord
from validator import validate_record_payload

ROOT_DATA_DIR = Path(__file__).resolve().parent.parent / "data"
LOCAL_DATA_DIR = Path(__file__).resolve().parent / "data"
DATA_DIR = ROOT_DATA_DIR if ROOT_DATA_DIR.exists() else LOCAL_DATA_DIR
RECORDS_JSON = DATA_DIR / "grocery_records.json"
RECORDS_CSV = DATA_DIR / "grocery_records.csv"
CONFIG_JSON = DATA_DIR / "budget_config.json"


def ensure_data_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _normalize_record_dict(item: dict) -> GroceryRecord:
    return GroceryRecord(
        id=str(item.get("id", "")),
        item_name=str(item.get("item_name") or item.get("itemName") or ""),
        category=str(item.get("category", "")),
        quantity=float(item.get("quantity", 0)),
        unit_price=float(
            item.get("unit_price") if "unit_price" in item else item.get("unitPrice", 0)
        ),
        total_cost=float(
            item.get("total_cost") if "total_cost" in item else item.get("totalCost", 0)
        ),
        item_budget=float(
            item.get("item_budget") if "item_budget" in item else item.get("itemBudget", 0)
        ),
        purchase_date=str(item.get("purchase_date") or item.get("purchaseDate") or ""),
        store=str(item.get("store", "")),
        notes=str(item.get("notes", "")),
        created_at=str(item.get("created_at") or item.get("createdAt") or ""),
    )


def record_to_api_dict(r: GroceryRecord) -> Dict[str, object]:
    return {
        "id": r.id,
        "itemName": r.item_name,
        "category": r.category,
        "quantity": r.quantity,
        "unitPrice": r.unit_price,
        "totalCost": r.total_cost,
        "itemBudget": r.item_budget,
        "purchaseDate": r.purchase_date,
        "store": r.store,
        "notes": r.notes,
        "createdAt": r.created_at,
    }


def load_raw_budget_config() -> Dict[str, object]:
    ensure_data_dir()
    defaults: Dict[str, object] = {
        "overallMonthlyBudget": BudgetConfig().overall_monthly_budget,
        "warningThresholdPct": BudgetConfig().warning_threshold_pct,
        "categoryBudgets": dict(BudgetConfig().category_budgets),
        "customCategories": [],
    }
    try:
        raw = json.loads(CONFIG_JSON.read_text(encoding="utf-8"))
        if not isinstance(raw, dict):
            raise ValueError("Config must be a JSON object")
        return {
            "overallMonthlyBudget": float(
                raw.get("overallMonthlyBudget", raw.get("overall_monthly_budget", 560.0))
            ),
            "warningThresholdPct": float(
                raw.get("warningThresholdPct", raw.get("warning_threshold_pct", 85.0))
            ),
            "categoryBudgets": dict(
                raw.get(
                    "categoryBudgets",
                    raw.get("category_budgets", BudgetConfig().category_budgets),
                )
            ),
            "customCategories": list(raw.get("customCategories", [])),
        }
    except (FileNotFoundError, json.JSONDecodeError, ValueError, TypeError):
        CONFIG_JSON.write_text(json.dumps(defaults, indent=2), encoding="utf-8")
        return defaults


def save_raw_budget_config(cfg_dict: Dict[str, object]) -> None:
    ensure_data_dir()
    CONFIG_JSON.write_text(json.dumps(cfg_dict, indent=2), encoding="utf-8")


def load_budget_config() -> BudgetConfig:
    raw = load_raw_budget_config()
    return BudgetConfig(
        overall_monthly_budget=float(raw["overallMonthlyBudget"]),  # type: ignore[arg-type]
        warning_threshold_pct=float(raw["warningThresholdPct"]),  # type: ignore[arg-type]
        category_budgets=dict(raw["categoryBudgets"]),  # type: ignore[arg-type]
    )


def save_budget_config(cfg: BudgetConfig) -> None:
    raw = load_raw_budget_config()
    raw["overallMonthlyBudget"] = cfg.overall_monthly_budget
    raw["warningThresholdPct"] = cfg.warning_threshold_pct
    raw["categoryBudgets"] = cfg.category_budgets
    save_raw_budget_config(raw)


def load_records() -> Tuple[List[GroceryRecord], Optional[str]]:
    ensure_data_dir()
    try:
        raw_text = RECORDS_JSON.read_text(encoding="utf-8")
        data = json.loads(raw_text)
        if not isinstance(data, list):
            raise ValueError("Expected JSON array")
        records = [_normalize_record_dict(item) for item in data]
        return records, None
    except FileNotFoundError:
        save_records([])
        return [], "Initialized clean empty grocery_records.json template."
    except (json.JSONDecodeError, TypeError, ValueError) as exc:
        backup_path = (
            DATA_DIR / f"grocery_records.corrupt.{int(datetime.now().timestamp())}.bak"
        )
        if RECORDS_JSON.exists():
            backup_path.write_text(
                RECORDS_JSON.read_text(encoding="utf-8", errors="ignore"),
                encoding="utf-8",
            )
        save_records([])
        return (
            [],
            f"Recovered from corrupted JSON ({exc}). Backup saved to {backup_path.name}.",
        )


def save_records(records: List[GroceryRecord]) -> None:
    ensure_data_dir()
    RECORDS_JSON.write_text(
        json.dumps([record_to_api_dict(r) for r in records], indent=2),
        encoding="utf-8",
    )
    fieldnames = [
        "id",
        "item_name",
        "category",
        "quantity",
        "unit_price",
        "total_cost",
        "item_budget",
        "purchase_date",
        "store",
        "notes",
        "created_at",
    ]
    with RECORDS_CSV.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        for r in records:
            writer.writerow(r.to_dict())


def bulk_import_csv(
    csv_path: Path, existing_records: List[GroceryRecord]
) -> Tuple[List[GroceryRecord], List[str]]:
    accepted: List[GroceryRecord] = []
    error_logs: List[str] = []
    existing_ids = {r.id for r in existing_records}
    next_num = 2000
    while f"GRB-{next_num}" in existing_ids:
        next_num += 1

    try:
        with csv_path.open("r", newline="", encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            for row_idx, row in enumerate(reader, start=2):
                errs, cleaned = validate_record_payload(row)
                if errs or not cleaned:
                    error_logs.append(f"Row {row_idx}: {'; '.join(errs)}")
                    continue
                rec_id = f"GRB-{next_num}"
                next_num += 1
                existing_ids.add(rec_id)
                accepted.append(
                    GroceryRecord(
                        id=rec_id,
                        created_at=datetime.now(timezone.utc).isoformat(),
                        **cleaned,
                    )
                )
    except FileNotFoundError:
        error_logs.append(f"File not found: {csv_path}")
    except csv.Error as exc:
        error_logs.append(f"CSV parsing error: {exc}")

    return accepted, error_logs
