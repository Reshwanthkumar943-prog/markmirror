"""Unit and integration tests for SpendBasket Python CLI, persistence, charts, and web server."""
from __future__ import annotations

import json
import tempfile
import threading
import unittest
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError
from urllib.request import Request, urlopen

from analytics import classify_status, compute_executive_summary, export_markdown_report
from charts import generate_budget_charts
from models import BudgetConfig, GroceryRecord
from storage import bulk_import_csv
from validator import validate_calendar_date, validate_record_payload
from web_server import SpendBasketHandler, validate_web_payload


class SpendBasketTests(unittest.TestCase):
    def test_calendar_date_validation(self) -> None:
        self.assertTrue(validate_calendar_date("2026-11-24"))
        self.assertFalse(validate_calendar_date("2026-02-30"))
        self.assertFalse(validate_calendar_date("2026-13-01"))
        self.assertFalse(validate_calendar_date("24-11-2026"))

    def test_defensive_record_validation(self) -> None:
        errs, cleaned = validate_record_payload(
            {
                "item_name": "Organic Honeycrisp Apples",
                "category": "Fresh Fruits & Veggies",
                "quantity": "3",
                "unit_price": "2.45",
                "item_budget": "9.00",
                "purchase_date": "2026-11-24",
                "store": "FreshMarket",
            }
        )
        self.assertEqual(errs, [])
        self.assertIsNotNone(cleaned)
        assert cleaned is not None
        self.assertEqual(cleaned["total_cost"], 7.35)

        bad_errs, bad_cleaned = validate_record_payload(
            {
                "item_name": "   ",
                "category": "Unknown",
                "quantity": -2,
                "unit_price": 0,
                "item_budget": -5,
                "purchase_date": "2026-99-99",
                "store": "A",
            }
        )
        self.assertIsNone(bad_cleaned)
        self.assertGreaterEqual(len(bad_errs), 5)

    def test_overspending_status_and_summary(self) -> None:
        self.assertEqual(classify_status(7.35, 9.0, 85.0), "Within Budget")
        self.assertEqual(classify_status(8.0, 9.0, 85.0), "Near Limit")
        self.assertEqual(classify_status(9.5, 9.0, 85.0), "Over Budget")

        cfg = BudgetConfig(overall_monthly_budget=50.0)
        recs = [
            GroceryRecord(
                id="GRB-1",
                item_name="Apples",
                category="Fresh Fruits & Veggies",
                quantity=2,
                unit_price=3.0,
                total_cost=6.0,
                item_budget=8.0,
                purchase_date="2026-11-24",
                store="FreshMarket",
            ),
            GroceryRecord(
                id="GRB-2",
                item_name="Salmon",
                category="Meat, Poultry & Fish",
                quantity=2,
                unit_price=15.0,
                total_cost=30.0,
                item_budget=25.0,
                purchase_date="2026-11-24",
                store="Harbor Grocer",
            ),
        ]
        summary = compute_executive_summary(recs, cfg)
        self.assertEqual(summary["total_spend"], 36.0)
        self.assertEqual(summary["remaining"], 14.0)
        self.assertEqual(summary["overspent_count"], 1)

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            md_file = export_markdown_report(recs, cfg, tmp_path / "summary.md")
            self.assertTrue(md_file.exists())
            self.assertIn("Grocery Budget Assistant", md_file.read_text(encoding="utf-8"))

            chart_paths = generate_budget_charts(recs, cfg, tmp_path / "charts")
            self.assertGreaterEqual(len(chart_paths), 1)
            self.assertTrue(chart_paths[0].exists())

    def test_bulk_csv_import_row_errors(self) -> None:
        csv_body = (
            "item_name,category,quantity,unit_price,item_budget,purchase_date,store,notes\n"
            "Milk,Milk, Cheese & Eggs,1,4.50,5.00,2026-11-24,FreshMarket,Bad comma\n"
            "Sourdough Loaf,Bread & Bakery,2,4.50,9.00,2026-11-24,Corner Bakery,Valid row\n"
            ",Snacks & Sweets,-1,0,5.00,2026-13-40,Metro Mart,Multiple errors\n"
        )
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "import.csv"
            path.write_text(csv_body, encoding="utf-8")
            accepted, errs = bulk_import_csv(path, [])
            self.assertEqual(len(accepted), 1)
            self.assertEqual(accepted[0].item_name, "Sourdough Loaf")
            self.assertEqual(len(errs), 2)

    def test_python_web_server_api(self) -> None:
        errs, cleaned = validate_web_payload(
            {
                "itemName": "Cold Brew Coffee",
                "category": "Drinks & Coffee",
                "quantity": 2,
                "unitPrice": 4.5,
                "itemBudget": 10.0,
                "purchaseDate": "2026-11-24",
                "store": "Metro Mart",
            },
            ["Drinks & Coffee"],
        )
        self.assertEqual(errs, [])
        self.assertIsNotNone(cleaned)

        server = ThreadingHTTPServer(("127.0.0.1", 0), SpendBasketHandler)
        port = server.server_address[1]
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            with urlopen(f"http://127.0.0.1:{port}/api/health", timeout=3) as resp:
                data = json.loads(resp.read().decode("utf-8"))
                self.assertTrue(data["ok"])
                self.assertEqual(data["runtime"], "python")

            bad_req = Request(
                f"http://127.0.0.1:{port}/api/records",
                data=json.dumps({"itemName": "", "quantity": -1}).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with self.assertRaises(HTTPError) as ctx:
                urlopen(bad_req, timeout=3)
            self.assertEqual(ctx.exception.code, 400)
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    unittest.main()
