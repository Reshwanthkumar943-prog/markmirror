# SpendBasket — Grocery Budget Assistant

A colorful, animated grocery budget web application powered by a **zero-dependency Python 3.10+ backend (`python_app/web_server.py`)**, a full **Python CLI & Matplotlib reporting suite (`python_app/main.py`)**, and a React + TypeScript frontend (`src/`).

## Quick Start in VS Code (Pure Python — No `npm install` Required)
1. Unzip and open the folder in VS Code.
2. Launch the **SpendBasket Website** powered by Python:
   ```bash
   python3 python_app/web_server.py
   ```
   Open **`http://localhost:8000`** in your browser.
3. Or launch the **Interactive Python CLI**:
   ```bash
   python3 python_app/main.py
   ```
4. Run the **Automated Python Test Suite**:
   ```bash
   python3 -m unittest discover -s python_app -v
   ```

## Alternative: Node.js Development Mode
```bash
npm install
npm run dev
```
Open `http://localhost:3000`.

## Key Features
- **Monthly Budget Hero & Live Spending Pace**: Animated progress meter, cubic-eased counters, and plain-English remaining/overage status.
- **12 Everyday Categories + Custom Category Creator**: Track Fresh Fruits & Veggies, Milk/Cheese/Eggs, Meat/Poultry/Fish, Bread & Bakery, Snacks & Sweets, Drinks & Coffee, Rice/Pasta/Grains, Spices/Sauces/Oils, Frozen Meals & Ice Cream, Breakfast & Cereal, Baby & Pet Care, and Cleaning & Home Supplies, or add custom categories with color swatches.
- **Interactive Analytics**: Animated category donut chart, spending rhythm timeline with monthly budget ceiling line, and per-category limit meters.
- **Defensive Input Validation & Overspending Flags**: Sanitizes and validates item names, quantities, unit prices, target budgets, and calendar dates (`YYYY-MM-DD`) on both frontend and backend.
- **Local JSON & CSV Persistence**: Automatically saves records to `data/grocery_records.json`, `data/grocery_records.csv`, and `data/budget_config.json` with corruption recovery, seeded with 36 realistic sample items.
