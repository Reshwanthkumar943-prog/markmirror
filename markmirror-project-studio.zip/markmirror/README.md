# MarkMirror — University Exam Result Portal & Cohort Analytics

MarkMirror is an institutional Examination Cell portal and cohort analytics platform built with **Express**, **Node.js `node:sqlite` (WAL mode)**, **React 19**, **TypeScript**, **Tailwind CSS**, and **Chart.js**.

## Architecture & Engineering Highlights

- **Relational Persistence (`server/repository.ts`)**:
  - **Repository & Factory Patterns**: `createStorageRepository()` provisions `SqliteStudentRepository` (using `node:sqlite` with `PRAGMA journal_mode = WAL`, normalized tables `students`, `subject_results`, `semester_history`, `revaluation_applications`, `audit_logs`, foreign keys, indexes, and ACID `BEGIN IMMEDIATE` transactions) with an `AtomicJsonStudentRepository` fallback (`temp` write + `fs.renameSync`).
  - **Retry Resilience**: `withRetry()` wraps transactional storage mutations with exponential backoff recovery.
  - **Observer & Facade (`server/store.ts`)**: `PortalDataService` coordinates the repository and `AnalyticsEventBus` to automatically rebuild cached analytics slices whenever records mutate.
- **Security & Transcript Authenticity (`server/security.ts`)**:
  - **Admin Passkey Auth**: `POST /api/admin/auth` verifies the Exam Cell passkey (`ADMIN_ACCESS_KEY`, demo default `NIET-ADMIN-2026`) via SHA-256 + `crypto.timingSafeEqual` and issues a signed HMAC-SHA256 Bearer token protecting `POST /api/students/import` and `GET /api/admin/audit`.
  - **Cryptographic Transcript Seal**: Each marksheet computes a canonical HMAC-SHA256 digest (`XXXX-XXXX-XXXX-XXXX`) verifiable live via `GET /api/verify/:hallTicket?hash=...`.
  - **Hardening**: Sliding-window rate limiting on auth/mutation endpoints, HTTP security headers (`X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, `Permissions-Policy`), and strict input validation.
- **Statistical & Predictive Engine (`src/shared/statistics.ts`)**:
  - **Subject Z-Scores & Normal CDF Percentiles**: Per-subject standardized performance ($z = (x - \mu)/\sigma$) and Abramowitz–Stegun normal CDF percentile estimation.
  - **Gaussian Bell Curve Overlay**: Continuous normal distribution fit plotted over the cohort CGPA histogram alongside $\mu$, $\sigma$, median, IQR, and skewness.
  - **Graduation Target CGPA Forecaster**: Interactive solver computing the required SGPA across remaining degree credits (`Sem VI–VIII`).

## Prerequisites

- **Node.js** `v22.12+` (native `node:sqlite` support)
- **npm** (bundled with Node.js)
- **VS Code**

## Running in VS Code

1. Extract `markmirror-project.zip` and open the folder in **VS Code** (`File -> Open Folder...`).
2. Install dependencies:
   ```bash
   npm install
   ```
3. Configure optional environment variables (copy `.env.example` to `.env`):
   ```bash
   ADMIN_ACCESS_KEY="NIET-ADMIN-2026"
   ```
4. Start the Express + Vite server on port `3000`:
   ```bash
   npm run dev
   ```
5. Open `http://localhost:3000` in your browser.

## Automated Verification & Tests

```bash
npm test     # Runs unit tests (grading, statistics, HMAC security, retry) & live HTTP API integration suite
npm run lint # TypeScript strict type-check (tsc --noEmit)
npm run build
```

## Demo Hall Tickets & Admin Key

- **Exam Cell Import Passkey**: `NIET-ADMIN-2026`
- `22CSE104` — SGPA **8.85** (`First Class with Distinction`, 177/20 credits)
- `22CSE101` — SGPA **10.00** (Branch Rank #1)
- `22CSE118` — Operating Systems backlog (Re-Evaluation Fee Estimator & Challan demo)
- `22ECE105` / `22IT103` — ECE & IT sample records
