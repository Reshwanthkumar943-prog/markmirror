import 'dotenv/config';
import crypto from 'crypto';
import express from 'express';
import type {NextFunction, Request, Response} from 'express';
import fs from 'fs';
import JSZip from 'jszip';
import path from 'path';
import {fileURLToPath, pathToFileURL} from 'url';
import {
  computeMarksheetVerificationHash,
  createRateLimiter,
  issueAdminToken,
  requireAdminAuth,
  securityHeadersMiddleware,
  verifyAdminPasskey,
} from './server/security.ts';
import type {AuthenticatedRequest} from './server/security.ts';
import {PortalDataService, defaultPortalService} from './server/store.ts';
import type {ImportStudentInput} from './server/store.ts';
import type {BatchId, BranchCode} from './src/shared/grading.ts';
import {
  REVALUATION_FEE_PER_LAB,
  REVALUATION_FEE_PER_THEORY,
  REVALUATION_PROCESSING_FEE,
  SUBJECT_CATALOG,
} from './src/shared/grading.ts';
import {computeZScore} from './src/shared/statistics.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

const VALID_BATCHES: BatchId[] = ['2022-2026', '2021-2025', '2020-2024'];
const VALID_BRANCHES: Array<BranchCode | 'ALL'> = ['ALL', 'CSE', 'ECE', 'IT'];

const EXCLUDED_ZIP_DIRS = new Set(['node_modules', 'dist', '.git', 'workspace', '.aistudio', 'data']);
const EXCLUDED_ZIP_FILES = new Set(['bun.lock', 'markmirror-project.zip']);

async function buildProjectZipBuffer(): Promise<Buffer> {
  const zip = new JSZip();
  const rootFolder = zip.folder('markmirror');

  function walkDir(dirPath: string) {
    const entries = fs.readdirSync(dirPath, {withFileTypes: true});
    for (const entry of entries) {
      if (entry.isDirectory()) {
        if (EXCLUDED_ZIP_DIRS.has(entry.name)) continue;
        walkDir(path.join(dirPath, entry.name));
      } else if (entry.isFile()) {
        if (EXCLUDED_ZIP_FILES.has(entry.name) || entry.name.endsWith('.zip')) continue;
        const fullPath = path.join(dirPath, entry.name);
        const relPath = path.relative(__dirname, fullPath).split(path.sep).join('/');
        if (relPath.startsWith('public/assets/aistudio')) continue;
        rootFolder?.file(relPath, fs.readFileSync(fullPath));
      }
    }
  }

  walkDir(__dirname);
  return zip.generateAsync({type: 'nodebuffer', compression: 'DEFLATE'});
}

export async function createApp(service: PortalDataService = defaultPortalService) {
  await service.init();

  const app = express();
  app.use(securityHeadersMiddleware);
  app.use(express.json({limit: '2mb'}));

  const authRateLimiter = createRateLimiter({windowMs: 60_000, maxRequests: 20});
  const writeRateLimiter = createRateLimiter({windowMs: 60_000, maxRequests: 30});

  // Health & storage engine diagnostics
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      storageEngine: service.getStorageEngine(),
      totalRecords: service.getAllStudents().length,
    });
  });

  // Exam Cell Admin Authentication (returns HMAC-SHA256 signed token)
  app.post('/api/admin/auth', authRateLimiter, (req, res) => {
    const passkey = typeof req.body?.passkey === 'string' ? req.body.passkey : '';
    const actor =
      typeof req.body?.actor === 'string' && req.body.actor.trim()
        ? req.body.actor.trim().slice(0, 60)
        : 'Exam Cell Administrator';

    if (!verifyAdminPasskey(passkey)) {
      res.status(401).json({error: 'Invalid Exam Cell passkey.'});
      return;
    }

    const {token, expiresAt} = issueAdminToken(actor);
    res.json({token, expiresAt, actor});
  });

  // Protected Audit Log Endpoint
  app.get('/api/admin/audit', requireAdminAuth, (_req, res) => {
    res.json({logs: service.getAuditLogs(25)});
  });

  // Hall Ticket Result Lookup with Z-scores & cryptographic verification digest
  app.get('/api/results/:hallTicket', (req, res) => {
    const queryTicket = req.params.hallTicket.trim().toUpperCase();
    if (!/^[A-Z0-9]{4,16}$/.test(queryTicket)) {
      res.status(400).json({error: 'Invalid hall ticket format.'});
      return;
    }

    const allStudents = service.getAllStudents();
    const student = service.findStudentByHallTicket(queryTicket);

    if (!student) {
      res.status(404).json({
        error: 'Hall ticket record not found',
        hallTicket: queryTicket,
        suggestions: ['22CSE104', '22CSE101', '22CSE118', '22ECE105', '22IT103'],
      });
      return;
    }

    const branchPeers = allStudents
      .filter((s) => s.batch === student.batch && s.branch === student.branch)
      .sort((a, b) => {
        if (a.hasBacklog !== b.hasBacklog) return a.hasBacklog ? 1 : -1;
        if (b.sgpa !== a.sgpa) return b.sgpa - a.sgpa;
        return b.totalMarks - a.totalMarks;
      });

    const branchRank = branchPeers.findIndex((s) => s.hallTicket === student.hallTicket) + 1;
    const branchPercentile =
      branchPeers.length > 1
        ? Number((((branchPeers.length - branchRank) / (branchPeers.length - 1)) * 100).toFixed(1))
        : 100;

    const branchAnalytics = service.getCachedAnalytics(student.batch, student.branch);
    const subjectAverages = branchAnalytics.subjectAnalytics.map((sa, idx) => {
      const studentMark = student.subjects[idx]?.totalMarks ?? sa.avgMarks;
      const zStats = computeZScore(studentMark, sa.avgMarks, sa.stdDevMarks);
      return {
        code: sa.code,
        avgMarks: sa.avgMarks,
        stdDevMarks: sa.stdDevMarks,
        passRate: sa.passRate,
        zScore: zStats.zScore,
        percentile: zStats.percentile,
      };
    });

    const verificationHash = computeMarksheetVerificationHash(student);

    res.json({
      student,
      standing: {
        branchRank,
        branchTotal: branchPeers.length,
        branchPercentile,
      },
      subjectAverages,
      verificationHash,
    });
  });

  // Cryptographic Transcript Verification Endpoint
  app.get('/api/verify/:hallTicket', (req, res) => {
    const queryTicket = req.params.hallTicket.trim().toUpperCase();
    const providedHash = String(req.query.hash || '').trim().toUpperCase();

    const student = service.findStudentByHallTicket(queryTicket);
    if (!student) {
      res.status(404).json({verified: false, error: 'Hall ticket record not found'});
      return;
    }

    const expectedHash = computeMarksheetVerificationHash(student);
    const a = Buffer.from(providedHash, 'utf8');
    const b = Buffer.from(expectedHash, 'utf8');
    const verified = a.length === b.length && crypto.timingSafeEqual(a, b);

    res.json({
      verified,
      hallTicket: student.hallTicket,
      studentName: student.name,
      sgpa: student.sgpa,
      cgpa: student.cgpa,
      expectedHash: verified ? expectedHash : undefined,
      checkedAt: new Date().toISOString(),
    });
  });

  // Student directory search / autocomplete
  app.get('/api/students', (req, res) => {
    const q = String(req.query.q || '').trim().toLowerCase().slice(0, 64);
    const branch = String(req.query.branch || 'ALL').toUpperCase();
    const batch = String(req.query.batch || '2022-2026');
    const limit = Math.min(50, Math.max(1, Number(req.query.limit || 12)));

    const filtered = service
      .getAllStudents()
      .filter((s) => {
        if (batch !== 'ALL' && s.batch !== batch) return false;
        if (branch !== 'ALL' && s.branch !== branch) return false;
        if (!q) return true;
        return (
          s.hallTicket.toLowerCase().includes(q) ||
          s.name.toLowerCase().includes(q)
        );
      })
      .slice(0, limit);

    res.json({
      students: filtered.map((s) => ({
        hallTicket: s.hallTicket,
        name: s.name,
        branch: s.branch,
        batch: s.batch,
        sgpa: s.sgpa,
        cgpa: s.cgpa,
        hasBacklog: s.hasBacklog,
        classification: s.classification,
      })),
    });
  });

  // Protected Batch CSV / JSON Student Record Importer
  app.post(
    '/api/students/import',
    writeRateLimiter,
    requireAdminAuth,
    (req: AuthenticatedRequest, res) => {
      const rawRows: unknown = req.body?.records;
      if (!Array.isArray(rawRows) || rawRows.length === 0) {
        res.status(400).json({error: 'Provide a non-empty array of student records to import.'});
        return;
      }

      if (rawRows.length > 500) {
        res.status(400).json({error: 'Maximum 500 student records per batch import.'});
        return;
      }

      const validInputs: ImportStudentInput[] = [];
      for (const item of rawRows) {
        if (!item || typeof item !== 'object') continue;
        const obj = item as Record<string, unknown>;
        const hallTicket = typeof obj.hallTicket === 'string' ? obj.hallTicket.trim().toUpperCase() : '';
        const name = typeof obj.name === 'string' ? obj.name.trim() : '';
        const branchRaw = typeof obj.branch === 'string' ? obj.branch.trim().toUpperCase() : 'CSE';
        const batchRaw = typeof obj.batch === 'string' ? obj.batch.trim() : '2022-2026';

        if (!/^[A-Z0-9]{4,16}$/.test(hallTicket) || name.length < 2) {
          res.status(400).json({
            error: `Invalid record (${hallTicket || 'missing hallTicket'}): valid alphanumeric hallTicket and name required.`,
          });
          return;
        }

        const branch: BranchCode =
          branchRaw === 'ECE' || branchRaw === 'IT' ? branchRaw : 'CSE';
        const batch: BatchId =
          batchRaw === '2021-2025' || batchRaw === '2020-2024' ? batchRaw : '2022-2026';

        const rawMarks = Array.isArray(obj.marks) ? obj.marks : [];
        const marks = rawMarks
          .filter((m): m is Record<string, unknown> => Boolean(m && typeof m === 'object'))
          .map((m) => ({
            code: String(m.code || ''),
            internal: Number(m.internal ?? 0),
            external: Number(m.external ?? 0),
          }));

        validInputs.push({
          hallTicket,
          name,
          fatherName: typeof obj.fatherName === 'string' ? obj.fatherName : undefined,
          branch,
          batch,
          marks,
        });
      }

      try {
        const actor = req.adminUser?.sub || 'Exam Cell Admin';
        const summary = service.upsertStudents(validInputs, actor);
        res.json({
          ...summary,
          totalRecords: service.getAllStudents().length,
        });
      } catch (err) {
        res.status(400).json({
          error: err instanceof Error ? err.message : 'Validation failed during import.',
        });
      }
    },
  );

  // Pre-computed Batch Analytics
  app.get('/api/analytics', (req, res) => {
    const rawBatch = String(req.query.batch || '2022-2026') as BatchId;
    const rawBranch = String(req.query.branch || 'ALL').toUpperCase() as BranchCode | 'ALL';

    const batch: BatchId = VALID_BATCHES.includes(rawBatch) ? rawBatch : '2022-2026';
    const branch: BranchCode | 'ALL' = VALID_BRANCHES.includes(rawBranch) ? rawBranch : 'ALL';

    res.json(service.getCachedAnalytics(batch, branch));
  });

  // Export Cohort CSV Report
  app.get('/api/analytics/export.csv', (req, res) => {
    const rawBatch = String(req.query.batch || '2022-2026') as BatchId;
    const rawBranch = String(req.query.branch || 'ALL').toUpperCase() as BranchCode | 'ALL';
    const batch: BatchId = VALID_BATCHES.includes(rawBatch) ? rawBatch : '2022-2026';
    const branch: BranchCode | 'ALL' = VALID_BRANCHES.includes(rawBranch) ? rawBranch : 'ALL';

    const csv = service.exportBatchCsv(batch, branch);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="markmirror_${batch}_${branch}.csv"`,
    );
    res.send(csv);
  });

  // Re-evaluation fee calculator & persisted submission endpoints
  app.post('/api/revaluation/estimate', (req, res) => {
    const codes: unknown = req.body?.subjectCodes;
    const selectedCodes = Array.isArray(codes)
      ? codes.filter((c): c is string => typeof c === 'string')
      : [];

    const matchedSubjects = SUBJECT_CATALOG.filter((s) => selectedCodes.includes(s.code));
    const items = matchedSubjects.map((s) => ({
      code: s.code,
      name: s.name,
      type: s.type,
      fee: s.type === 'Lab' ? REVALUATION_FEE_PER_LAB : REVALUATION_FEE_PER_THEORY,
    }));

    const paperSubtotal = items.reduce((acc, item) => acc + item.fee, 0);
    const processingFee = items.length > 0 ? REVALUATION_PROCESSING_FEE : 0;
    const totalFee = paperSubtotal + processingFee;

    res.json({
      items,
      paperSubtotal,
      processingFee,
      totalFee,
      currency: 'INR',
    });
  });

  app.get('/api/revaluation/:hallTicket', (req, res) => {
    const applications = service.getRevaluationsForStudent(req.params.hallTicket);
    res.json({applications});
  });

  app.post('/api/revaluation/submit', writeRateLimiter, (req, res) => {
    const hallTicket = String(req.body?.hallTicket || '').trim().toUpperCase();
    const codes: unknown = req.body?.subjectCodes;
    const selectedCodes = Array.isArray(codes)
      ? codes.filter((c): c is string => typeof c === 'string')
      : [];

    const student = service.findStudentByHallTicket(hallTicket);
    if (!student) {
      res.status(404).json({error: 'Student record not found'});
      return;
    }

    const matchedSubjects = SUBJECT_CATALOG.filter((s) => selectedCodes.includes(s.code));
    if (matchedSubjects.length === 0) {
      res.status(400).json({error: 'Select at least one subject for re-evaluation'});
      return;
    }

    const paperSubtotal = matchedSubjects.reduce(
      (acc, s) => acc + (s.type === 'Lab' ? REVALUATION_FEE_PER_LAB : REVALUATION_FEE_PER_THEORY),
      0,
    );
    const processingFee = REVALUATION_PROCESSING_FEE;
    const totalFee = paperSubtotal + processingFee;

    const application = service.saveRevaluationApplication({
      hallTicket: student.hallTicket,
      studentName: student.name,
      subjectCodes: matchedSubjects.map((s) => s.code),
      paperSubtotal,
      processingFee,
      totalFee,
      currency: 'INR',
    });

    res.status(201).json({application});
  });

  // Direct project zip download (dynamically generated if missing)
  app.get('/markmirror-project.zip', async (_req, res) => {
    try {
      const zipBuffer = await buildProjectZipBuffer();
      const zipPath = path.resolve(__dirname, 'public', 'markmirror-project.zip');
      fs.mkdirSync(path.dirname(zipPath), {recursive: true});
      fs.writeFileSync(zipPath, zipBuffer);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="markmirror-project.zip"');
      res.send(zipBuffer);
    } catch {
      res.status(500).json({error: 'Unable to generate project archive'});
    }
  });

  // Clean HTML download page with direct zip link
  app.get('/download.html', (_req, res) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(`<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Download MarkMirror Project (.zip)</title>
    <style>
      body { font-family: system-ui, -apple-system, sans-serif; background: #f8fafc; color: #0f172a; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 24px; }
      .card { background: #fff; border: 1px solid #e2e8f0; border-radius: 16px; padding: 32px; max-width: 520px; width: 100%; }
      h1 { margin: 0 0 8px; font-size: 24px; }
      p { color: #475569; line-height: 1.5; margin: 0 0 20px; }
      .actions { display: flex; flex-wrap: wrap; gap: 12px; }
      a.btn { display: inline-block; padding: 12px 20px; border-radius: 10px; font-weight: 600; font-size: 14px; text-decoration: none; }
      a.primary { background: #4338ca; color: #fff; }
      a.secondary { background: #f1f5f9; color: #0f172a; }
    </style>
  </head>
  <body>
    <main class="card">
      <h1>MarkMirror Source Archive</h1>
      <p>Download the complete MarkMirror project (.zip including index.html, SQLite repository, React frontend, and test suite) or open the live web portal.</p>
      <div class="actions">
        <a class="btn primary" href="/markmirror-project.zip" download="markmirror-project.zip">Download markmirror-project.zip</a>
        <a class="btn secondary" href="/">Open Live Portal</a>
      </div>
    </main>
  </body>
</html>`);
  });

  // Global error handler
  app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    const message = err instanceof Error ? err.message : 'Internal server error';
    res.status(500).json({error: message});
  });

  return app;
}

async function startServer() {
  const app = await createApp(defaultPortalService);

  if (!isProduction) {
    const {createServer: createViteServer} = await import('vite');
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(
      `MarkMirror server running at http://0.0.0.0:${PORT} (storage: ${defaultPortalService.getStorageEngine()})`,
    );
  });
}

const isEntryModule =
  Boolean(process.argv[1]) &&
  import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;

if (isEntryModule) {
  startServer().catch((err) => {
    console.error('Failed to start MarkMirror server:', err);
    process.exit(1);
  });
}
