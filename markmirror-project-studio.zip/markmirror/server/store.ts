import path from 'path';
import {fileURLToPath} from 'url';
import {computeBatchAnalytics} from './dataset.ts';
import type {BatchAnalyticsResponse} from './dataset.ts';
import {
  AnalyticsEventBus,
  createStorageRepository,
} from './repository.ts';
import type {
  AuditLogEntry,
  ImportStudentInput,
  RevaluationApplication,
  StudentRepository,
  UpsertSummary,
} from './repository.ts';
import type {BatchId, BranchCode, StudentRecord} from '../src/shared/grading.ts';

export type {AuditLogEntry, ImportStudentInput, RevaluationApplication, UpsertSummary};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DEFAULT_DATA_DIR = path.resolve(__dirname, '..', 'data');

// Service / Facade Layer coordinating Repository, Cache, and Event Bus
export class PortalDataService {
  private repo: StudentRepository | null = null;
  private readonly eventBus = new AnalyticsEventBus();
  private readonly analyticsCache = new Map<string, BatchAnalyticsResponse>();
  private readonly dataDir: string;

  constructor(dataDir = DEFAULT_DATA_DIR) {
    this.dataDir = dataDir;
    this.eventBus.subscribe('students:mutated', () => {
      this.rebuildAnalyticsCache();
    });
  }

  async init(): Promise<void> {
    if (this.repo) return;
    this.repo = await createStorageRepository(this.dataDir);
    this.rebuildAnalyticsCache();
  }

  private getRepo(): StudentRepository {
    if (!this.repo) {
      throw new Error('PortalDataService has not been initialized.');
    }
    return this.repo;
  }

  getStorageEngine(): string {
    return this.getRepo().engineName;
  }

  rebuildAnalyticsCache(): void {
    this.analyticsCache.clear();
    const allStudents = this.getRepo().getAllStudents();
    const batches: BatchId[] = ['2022-2026', '2021-2025', '2020-2024'];
    const branches: Array<BranchCode | 'ALL'> = ['ALL', 'CSE', 'ECE', 'IT'];

    for (const batch of batches) {
      for (const branch of branches) {
        this.analyticsCache.set(
          `${batch}:${branch}`,
          computeBatchAnalytics(batch, branch, allStudents),
        );
      }
    }
  }

  getAllStudents(): StudentRecord[] {
    return this.getRepo().getAllStudents();
  }

  findStudentByHallTicket(hallTicket: string): StudentRecord | null {
    return this.getRepo().findStudentByHallTicket(hallTicket);
  }

  getCachedAnalytics(batch: BatchId, branch: BranchCode | 'ALL'): BatchAnalyticsResponse {
    const key = `${batch}:${branch}`;
    const cached = this.analyticsCache.get(key);
    if (cached) return cached;
    const computed = computeBatchAnalytics(batch, branch, this.getRepo().getAllStudents());
    this.analyticsCache.set(key, computed);
    return computed;
  }

  upsertStudents(inputs: ImportStudentInput[], actor = 'Exam Cell Admin'): UpsertSummary {
    const summary = this.getRepo().upsertStudents(inputs, actor);
    this.eventBus.emit('students:mutated');
    return summary;
  }

  getRevaluationsForStudent(hallTicket: string): RevaluationApplication[] {
    return this.getRepo().getRevaluations(hallTicket);
  }

  saveRevaluationApplication(
    app: Omit<RevaluationApplication, 'challanId' | 'submittedAt'>,
  ): RevaluationApplication {
    const saved = this.getRepo().saveRevaluation(app);
    this.eventBus.emit('revaluation:created');
    return saved;
  }

  getAuditLogs(limit = 25): AuditLogEntry[] {
    return this.getRepo().getAuditLogs(limit);
  }

  exportBatchCsv(batch: BatchId, branch: BranchCode | 'ALL'): string {
    const rows = this.getRepo()
      .getAllStudents()
      .filter((s) => s.batch === batch && (branch === 'ALL' || s.branch === branch));
    const headers = [
      'HallTicket',
      'Name',
      'Branch',
      'Batch',
      'MA301_Total',
      'CS302_Total',
      'CS303_OS_Total',
      'CS304_Total',
      'CS305_Total',
      'CS306L_Total',
      'TotalMarks',
      'Percentage',
      'SGPA',
      'CGPA',
      'Backlogs',
      'Classification',
    ];

    const lines = [headers.join(',')];
    for (const s of rows) {
      const subjTotals = s.subjects.map((sub) => sub.totalMarks);
      const cols = [
        s.hallTicket,
        `"${s.name.replace(/"/g, '""')}"`,
        s.branch,
        s.batch,
        ...subjTotals,
        s.totalMarks,
        s.percentage,
        s.sgpa.toFixed(2),
        s.cgpa.toFixed(2),
        s.backlogCount,
        `"${s.classification}"`,
      ];
      lines.push(cols.join(','));
    }
    return lines.join('\n');
  }

  close(): void {
    this.repo?.close();
    this.repo = null;
  }
}

export const defaultPortalService = new PortalDataService();
