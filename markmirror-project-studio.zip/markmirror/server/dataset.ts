import {
  BRANCH_NAMES,
  GRADE_POINTS_MAP,
  SUBJECT_CATALOG,
  classifyAcademicStanding,
  computeCGPA,
  computeDifficultyIndex,
  computeSGPA,
  determineLetterGrade,
} from '../src/shared/grading.ts';
import {
  computeDescriptiveStats,
  evaluateGaussianBinExpectation,
} from '../src/shared/statistics.ts';
import type {DescriptiveStats} from '../src/shared/statistics.ts';
import type {
  BatchId,
  BranchCode,
  LetterGrade,
  SemesterSnapshot,
  StudentRecord,
  SubjectResult,
} from '../src/shared/grading.ts';

const FIRST_NAMES = [
  'Aarav', 'Ananya', 'Rohan', 'Priya', 'Karthik', 'Divya', 'Siddharth', 'Meera',
  'Vikram', 'Sneha', 'Aditya', 'Neha', 'Arjun', 'Kavya', 'Rahul', 'Ishita',
  'Nikhil', 'Pooja', 'Varun', 'Shruti', 'Pranav', 'Riya', 'Harsha', 'Nandini',
  'Tanvi', 'Gaurav', 'Aishwarya', 'Kiran', 'Manish', 'Swathi', 'Dev', 'Bhavana',
  'Surya', 'Keerthi', 'Vivek', 'Sana', 'Tarun', 'Lakshmi', 'Abhinav', 'Deepika',
  'Yash', 'Mansi', 'Tejas', 'Pallavi', 'Akash', 'Shreya', 'Rishabh', 'Anjali',
  'Kunal', 'Chaitra',
];

const LAST_NAMES = [
  'Sharma', 'Reddy', 'Deshmukh', 'Nair', 'Patel', 'Kulkarni', 'Iyer', 'Verma',
  'Gupta', 'Rao', 'Menon', 'Joshi', 'Chopra', 'Singh', 'Bhat', 'Agarwal',
  'Choudhary', 'Mishra', 'Pillai', 'Bansal', 'Saxena', 'Kaur', 'Krishnan', 'Jain',
  'Tiwari', 'Hegde', 'Subramanian', 'Gowda', 'Das', 'Mukherjee',
];

const FATHER_FIRST_NAMES = [
  'Rajesh', 'Suresh', 'Ramesh', 'Venkatesh', 'Prakash', 'Mahesh', 'Anand', 'Mohan',
  'Sanjay', 'Vijay', 'Ashok', 'Deepak', 'Harish', 'Satish', 'Narendra', 'Govind',
  'Subhash', 'Ravindra', 'Kishore', 'Uday',
];

// Deterministic PRNG (Mulberry32) so dataset is stable across restarts
function createRng(seed: number) {
  let a = seed >>> 0;
  return function next(): number {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

function buildSubjectResult(
  subjIndex: number,
  internalMarks: number,
  externalMarks: number,
): SubjectResult {
  const def = SUBJECT_CATALOG[subjIndex];
  const grade = determineLetterGrade(internalMarks, externalMarks);
  const gradePoints = GRADE_POINTS_MAP[grade];
  const creditPoints = def.credits * gradePoints;
  return {
    code: def.code,
    name: def.name,
    shortName: def.shortName,
    credits: def.credits,
    type: def.type,
    internalMarks,
    externalMarks,
    totalMarks: internalMarks + externalMarks,
    grade,
    gradePoints,
    creditPoints,
    passed: grade !== 'F',
  };
}

function buildMarksForTargetTotal(targetTotal: number, rng: () => number): {internal: number; external: number} {
  if (targetTotal < 40) {
    // Realistic fail: internal may pass or border, external < 24 or total < 40
    const internal = clamp(Math.round(11 + rng() * 11), 8, 22);
    const external = clamp(targetTotal - internal, 6, 22);
    return {internal, external};
  }
  const internalRatio = 0.39 + rng() * 0.04;
  let internal = clamp(Math.round(targetTotal * internalRatio), 16, 40);
  let external = clamp(targetTotal - internal, 24, 60);
  if (internal + external !== targetTotal) {
    internal = clamp(targetTotal - external, 16, 40);
  }
  return {internal, external};
}

// Per-subject baseline characteristics
const SUBJECT_BIAS = [
  0,    // MA301 Mathematics III
  4,    // CS302 DBMS
  -8,   // CS303 Operating Systems (challenging core paper)
  1,    // CS304 Computer Networks
  7,    // CS305 Software Engineering
  12,   // CS306L AI Lab
];

function generateCohort(
  batch: BatchId,
  batchPrefix: string,
  branchCounts: Array<{branch: BranchCode; count: number; osPassCount: number}>,
  seed: number,
  batchOffset: number,
): StudentRecord[] {
  const rng = createRng(seed);
  const records: StudentRecord[] = [];
  let globalIdx = 0;

  const examSessionMap: Record<BatchId, string> = {
    '2022-2026': 'November 2026',
    '2021-2025': 'November 2025',
    '2020-2024': 'November 2024',
  };

  for (const group of branchCounts) {
    const {branch, count, osPassCount} = group;
    // Create deterministic list of OS pass/fail flags so exact pass rate is guaranteed
    const osFlags: boolean[] = Array.from({length: count}, (_, idx) => idx < osPassCount);
    // Shuffle flags deterministically while keeping index 0, 1, 3 (22CSE101, 22CSE102, 22CSE104) passing
    for (let i = osFlags.length - 1; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      const tmp = osFlags[i];
      osFlags[i] = osFlags[j];
      osFlags[j] = tmp;
    }

    // Ensure showcase hall tickets in 2022-2026 CSE have deterministic pass/fail states
    if (batch === '2022-2026' && branch === 'CSE') {
      const ensurePass = (idx: number) => {
        if (!osFlags[idx]) {
          const swapIdx = osFlags.findIndex((f, k) => f && k > 20);
          if (swapIdx !== -1) {
            osFlags[swapIdx] = false;
            osFlags[idx] = true;
          }
        }
      };
      const ensureFail = (idx: number) => {
        if (osFlags[idx]) {
          const swapIdx = osFlags.findIndex((f, k) => !f && k > 20);
          if (swapIdx !== -1) {
            osFlags[swapIdx] = true;
            osFlags[idx] = false;
          }
        }
      };
      ensurePass(0); // 22CSE101 (Topper)
      ensurePass(1); // 22CSE102
      ensurePass(3); // 22CSE104 (8.85 SGPA Demo)
      ensureFail(17); // 22CSE118 (Re-eval Demo with OS backlog)
    }

    for (let i = 0; i < count; i++) {
      const rollNum = 101 + i;
      const hallTicket = `${batchPrefix}${branch}${rollNum}`;
      const firstName = FIRST_NAMES[(globalIdx * 7 + i * 3) % FIRST_NAMES.length];
      const lastName = LAST_NAMES[(globalIdx * 5 + i * 2) % LAST_NAMES.length];
      const fatherFirst = FATHER_FIRST_NAMES[(globalIdx + i * 3) % FATHER_FIRST_NAMES.length];

      // Override specific demo students for crisp presentation
      let name = `${firstName} ${lastName}`;
      let fatherName = `${fatherFirst} ${lastName}`;

      if (hallTicket === '22CSE104') {
        name = 'Rohan Deshmukh';
        fatherName = 'Rajesh Deshmukh';
      } else if (hallTicket === '22CSE101') {
        name = 'Ananya Krishnan';
        fatherName = 'Venkatesh Krishnan';
      } else if (hallTicket === '22CSE118') {
        name = 'Siddharth Verma';
        fatherName = 'Sanjay Verma';
      } else if (hallTicket === '22ECE105') {
        name = 'Kavya Subramanian';
        fatherName = 'Prakash Subramanian';
      }

      // Base student ability tier
      let baseAbility = 67 + (rng() - 0.42) * 28 + batchOffset;
      if (i < 3) baseAbility = 89 + rng() * 6; // Top achievers
      if (hallTicket === '22CSE101') baseAbility = 94;

      let subjects: SubjectResult[];

      if (hallTicket === '22CSE104') {
        // Exact marks to produce SGPA = 8.85 (177 / 20) with Distinction
        // Grades: A+ (9), O (10), A (8), A+ (9), A (8), A+ (9) -> 36+40+32+27+24+18 = 177 / 20 = 8.85
        subjects = [
          buildSubjectResult(0, 34, 51), // 85 -> A+ (9)
          buildSubjectResult(1, 37, 56), // 93 -> O (10)
          buildSubjectResult(2, 30, 46), // 76 -> A (8)
          buildSubjectResult(3, 35, 49), // 84 -> A+ (9)
          buildSubjectResult(4, 31, 44), // 75 -> A (8)
          buildSubjectResult(5, 36, 51), // 87 -> A+ (9)
        ];
      } else if (hallTicket === '22CSE101') {
        // Rank 1 Topper in CSE
        subjects = [
          buildSubjectResult(0, 38, 56), // 94 -> O (10)
          buildSubjectResult(1, 39, 57), // 96 -> O (10)
          buildSubjectResult(2, 36, 54), // 90 -> O (10)
          buildSubjectResult(3, 37, 55), // 92 -> O (10)
          buildSubjectResult(4, 38, 54), // 92 -> O (10)
          buildSubjectResult(5, 39, 58), // 97 -> O (10)
        ];
      } else if (hallTicket === '22CSE118') {
        // Student with OS backlog for Re-Evaluation demo
        subjects = [
          buildSubjectResult(0, 27, 42), // 69 -> B+ (7)
          buildSubjectResult(1, 30, 45), // 75 -> A (8)
          buildSubjectResult(2, 16, 19), // 35 -> F (0)
          buildSubjectResult(3, 28, 43), // 71 -> A (8)
          buildSubjectResult(4, 31, 46), // 77 -> A (8)
          buildSubjectResult(5, 34, 50), // 84 -> A+ (9)
        ];
      } else {
        subjects = SUBJECT_CATALOG.map((_, sIdx) => {
          const noise = (rng() - 0.5) * 18;
          let targetTotal = Math.round(baseAbility + SUBJECT_BIAS[sIdx] + noise);

          if (sIdx === 2) {
            // Operating Systems controlled pass/fail for exact 68% in 2022-2026
            if (osFlags[i]) {
              targetTotal = clamp(targetTotal, 46, 94);
            } else {
              targetTotal = clamp(Math.round(22 + rng() * 15), 18, 37);
            }
          } else {
            // Ensure other subjects keep pass rates comfortably > 78%
            const passThreshold = sIdx === 5 ? 0.03 : sIdx === 4 ? 0.07 : sIdx === 1 ? 0.11 : 0.16;
            if (rng() < passThreshold && i >= 6) {
              targetTotal = clamp(Math.round(24 + rng() * 13), 20, 37);
            } else {
              targetTotal = clamp(targetTotal, 44, 98);
            }
          }

          const {internal, external} = buildMarksForTargetTotal(targetTotal, rng);
          return buildSubjectResult(sIdx, internal, external);
        });
      }

      const sgpaMetrics = computeSGPA(subjects);

      // Generate realistic historical semesters (Sem I - Sem IV)
      const semLabels = ['Semester I', 'Semester II', 'Semester III', 'Semester IV'];
      const semCredits = [20, 20, 21, 21];
      const batchAvgBase = [7.35, 7.48, 7.62, 7.54];
      const semesterHistory: SemesterSnapshot[] = semLabels.map((semLabel, idx) => {
        const drift = (rng() - 0.48) * 0.65;
        const base = sgpaMetrics.hasBacklog ? Math.max(6.1, sgpaMetrics.sgpa + 0.5) : sgpaMetrics.sgpa;
        const histSgpa =
          hallTicket === '22CSE104'
            ? [8.42, 8.6, 8.71, 8.76][idx]
            : clamp(Number((base - 0.35 + idx * 0.1 + drift).toFixed(2)), 5.4, 9.85);
        return {
          semester: semLabel,
          sgpa: histSgpa,
          credits: semCredits[idx],
          batchAverage: Number((batchAvgBase[idx] + batchOffset * 0.03).toFixed(2)),
        };
      });

      const cgpa = computeCGPA(semesterHistory, sgpaMetrics.sgpa, sgpaMetrics.totalCredits);

      records.push({
        hallTicket,
        name,
        fatherName,
        branch,
        branchName: BRANCH_NAMES[branch],
        batch,
        semester: 'Semester V',
        examSession: examSessionMap[batch],
        regulation: 'R22 Autonomous',
        subjects,
        sgpa: sgpaMetrics.sgpa,
        cgpa,
        totalCredits: sgpaMetrics.totalCredits,
        earnedCredits: sgpaMetrics.earnedCredits,
        totalWeightedPoints: sgpaMetrics.totalWeightedPoints,
        totalMarks: sgpaMetrics.totalMarks,
        maxMarks: sgpaMetrics.maxMarks,
        percentage: sgpaMetrics.percentage,
        hasBacklog: sgpaMetrics.hasBacklog,
        backlogCount: sgpaMetrics.backlogCount,
        classification: classifyAcademicStanding(sgpaMetrics.sgpa, sgpaMetrics.hasBacklog),
        semesterHistory: [
          ...semesterHistory,
          {
            semester: 'Semester V',
            sgpa: sgpaMetrics.sgpa,
            credits: sgpaMetrics.totalCredits,
            batchAverage: Number((7.65 + batchOffset * 0.03).toFixed(2)),
          },
        ],
      });

      globalIdx += 1;
    }
  }

  return records;
}

export const ALL_STUDENTS: StudentRecord[] = [
  // Primary Active Cohort: 2022-2026 (100 students, exact 68% OS pass rate overall & per branch)
  ...generateCohort(
    '2022-2026',
    '22',
    [
      {branch: 'CSE', count: 50, osPassCount: 34}, // 34/50 = 68%
      {branch: 'ECE', count: 25, osPassCount: 17}, // 17/25 = 68%
      {branch: 'IT', count: 25, osPassCount: 17},  // 17/25 = 68%
    ],
    20261119,
    0,
  ),
  // Historical Cohort: 2021-2025 (40 students)
  ...generateCohort(
    '2021-2025',
    '21',
    [
      {branch: 'CSE', count: 20, osPassCount: 15}, // 75%
      {branch: 'ECE', count: 10, osPassCount: 7},  // 70%
      {branch: 'IT', count: 10, osPassCount: 8},   // 80%
    ],
    20251119,
    1.5,
  ),
  // Historical Cohort: 2020-2024 (40 students)
  ...generateCohort(
    '2020-2024',
    '20',
    [
      {branch: 'CSE', count: 20, osPassCount: 14}, // 70%
      {branch: 'ECE', count: 10, osPassCount: 7},  // 70%
      {branch: 'IT', count: 10, osPassCount: 7},   // 70%
    ],
    20241119,
    -1.2,
  ),
];

export interface SubjectAnalyticsItem {
  code: string;
  name: string;
  shortName: string;
  credits: number;
  appeared: number;
  passed: number;
  failed: number;
  passRate: number;
  failRate: number;
  avgMarks: number;
  stdDevMarks: number;
  highestMarks: number;
  difficultyScore: number;
  difficultyTier: 'High' | 'Moderate' | 'Low';
}

export interface CgpaBinItem {
  label: string;
  midpoint: number;
  count: number;
  percentage: number;
  gaussianExpected: number;
}

export interface GradeDistributionItem {
  grade: LetterGrade;
  count: number;
  percentage: number;
}

export interface TopperItem {
  rank: number;
  hallTicket: string;
  name: string;
  branch: BranchCode;
  sgpa: number;
  cgpa: number;
  earnedCredits: number;
  totalMarks: number;
  percentage: number;
  classification: string;
}

export interface BatchComparisonItem {
  batch: BatchId;
  totalStudents: number;
  overallPassRate: number;
  meanCgpa: number;
  meanSgpa: number;
  distinctionRate: number;
  osPassRate: number;
}

export interface BatchAnalyticsResponse {
  batch: BatchId;
  branch: BranchCode | 'ALL';
  summary: {
    totalStudents: number;
    passedStudents: number;
    overallPassRate: number;
    meanSgpa: number;
    meanCgpa: number;
    distinctionCount: number;
    distinctionRate: number;
    lowestPassSubject: {
      name: string;
      code: string;
      passRate: number;
    };
  };
  cgpaStats: DescriptiveStats;
  subjectAnalytics: SubjectAnalyticsItem[];
  cgpaDistribution: CgpaBinItem[];
  gradeDistribution: GradeDistributionItem[];
  toppers: TopperItem[];
  batchComparison: BatchComparisonItem[];
}

export function computeBatchAnalytics(
  batch: BatchId = '2022-2026',
  branch: BranchCode | 'ALL' = 'ALL',
  sourceRecords: readonly StudentRecord[] = ALL_STUDENTS,
): BatchAnalyticsResponse {
  const cohort = sourceRecords.filter(
    (s) => s.batch === batch && (branch === 'ALL' || s.branch === branch),
  );

  const totalStudents = cohort.length;
  const passedStudents = cohort.filter((s) => !s.hasBacklog).length;
  const overallPassRate = totalStudents > 0 ? Number(((passedStudents / totalStudents) * 100).toFixed(1)) : 0;

  const meanSgpa =
    totalStudents > 0
      ? Number((cohort.reduce((acc, s) => acc + s.sgpa, 0) / totalStudents).toFixed(2))
      : 0;

  const meanCgpa =
    totalStudents > 0
      ? Number((cohort.reduce((acc, s) => acc + s.cgpa, 0) / totalStudents).toFixed(2))
      : 0;

  const distinctionCount = cohort.filter(
    (s) => !s.hasBacklog && s.sgpa >= 8.0,
  ).length;
  const distinctionRate =
    totalStudents > 0 ? Number(((distinctionCount / totalStudents) * 100).toFixed(1)) : 0;

  // Subject pass-rate & difficulty analytics
  const subjectAnalytics: SubjectAnalyticsItem[] = SUBJECT_CATALOG.map((subj, idx) => {
    let passed = 0;
    const marksList: number[] = [];

    for (const student of cohort) {
      const sr = student.subjects[idx];
      if (sr.passed) passed += 1;
      marksList.push(sr.totalMarks);
    }

    const subjStats = computeDescriptiveStats(marksList);
    const failed = totalStudents - passed;
    const passRate = totalStudents > 0 ? Number(((passed / totalStudents) * 100).toFixed(1)) : 0;
    const failRate = Number((100 - passRate).toFixed(1));
    const avgMarks = subjStats.mean;
    const diff = computeDifficultyIndex(passRate, avgMarks);

    return {
      code: subj.code,
      name: subj.name,
      shortName: subj.shortName,
      credits: subj.credits,
      appeared: totalStudents,
      passed,
      failed,
      passRate,
      failRate,
      avgMarks,
      stdDevMarks: subjStats.stdDev,
      highestMarks: subjStats.max,
      difficultyScore: diff.score,
      difficultyTier: diff.tier,
    };
  });

  const sortedByPass = [...subjectAnalytics].sort((a, b) => a.passRate - b.passRate);
  const lowestSubj = sortedByPass[0] ?? {name: 'Operating Systems', code: 'CS303', passRate: 68};

  // CGPA Descriptive Statistics & Gaussian Bell Curve Overlay
  const cgpaStats = computeDescriptiveStats(cohort.map((s) => s.cgpa));

  const binDefs = [
    {label: '9.0 – 10.0', min: 9.0, max: 10.01, midpoint: 9.5, width: 1.0},
    {label: '8.0 – 8.99', min: 8.0, max: 9.0, midpoint: 8.5, width: 1.0},
    {label: '7.0 – 7.99', min: 7.0, max: 8.0, midpoint: 7.5, width: 1.0},
    {label: '6.0 – 6.99', min: 6.0, max: 7.0, midpoint: 6.5, width: 1.0},
    {label: '< 6.0', min: 0, max: 6.0, midpoint: 5.5, width: 1.0},
  ];
  const cgpaDistribution: CgpaBinItem[] = binDefs.map((b) => {
    const count = cohort.filter((s) => s.cgpa >= b.min && s.cgpa < b.max).length;
    return {
      label: b.label,
      midpoint: b.midpoint,
      count,
      percentage: totalStudents > 0 ? Number(((count / totalStudents) * 100).toFixed(1)) : 0,
      gaussianExpected: evaluateGaussianBinExpectation(
        b.midpoint,
        b.width,
        totalStudents,
        cgpaStats.mean,
        cgpaStats.stdDev,
      ),
    };
  });

  // Letter Grade Distribution across all subject papers
  const gradesOrder: LetterGrade[] = ['O', 'A+', 'A', 'B+', 'B', 'C', 'F'];
  const gradeCounts: Record<LetterGrade, number> = {O: 0, 'A+': 0, A: 0, 'B+': 0, B: 0, C: 0, F: 0};
  let totalPapers = 0;

  for (const s of cohort) {
    for (const subj of s.subjects) {
      gradeCounts[subj.grade] += 1;
      totalPapers += 1;
    }
  }

  const gradeDistribution: GradeDistributionItem[] = gradesOrder.map((g) => ({
    grade: g,
    count: gradeCounts[g],
    percentage: totalPapers > 0 ? Number(((gradeCounts[g] / totalPapers) * 100).toFixed(1)) : 0,
  }));

  // Top 10 Department Toppers (prioritize zero-backlog students, then SGPA, then CGPA, then totalMarks)
  const sortedToppers = [...cohort].sort((a, b) => {
    if (a.hasBacklog !== b.hasBacklog) return a.hasBacklog ? 1 : -1;
    if (b.sgpa !== a.sgpa) return b.sgpa - a.sgpa;
    if (b.cgpa !== a.cgpa) return b.cgpa - a.cgpa;
    return b.totalMarks - a.totalMarks;
  });

  const toppers: TopperItem[] = sortedToppers.slice(0, 10).map((s, idx) => ({
    rank: idx + 1,
    hallTicket: s.hallTicket,
    name: s.name,
    branch: s.branch,
    sgpa: s.sgpa,
    cgpa: s.cgpa,
    earnedCredits: s.earnedCredits,
    totalMarks: s.totalMarks,
    percentage: s.percentage,
    classification: s.classification,
  }));

  // Cross-Batch Comparison across 2020-2024, 2021-2025, 2022-2026
  const batches: BatchId[] = ['2020-2024', '2021-2025', '2022-2026'];
  const batchComparison: BatchComparisonItem[] = batches.map((bId) => {
    const bCohort = sourceRecords.filter(
      (s) => s.batch === bId && (branch === 'ALL' || s.branch === branch),
    );
    const n = bCohort.length;
    const passCount = bCohort.filter((s) => !s.hasBacklog).length;
    const distCount = bCohort.filter((s) => !s.hasBacklog && s.sgpa >= 8.0).length;
    const osPass = bCohort.filter((s) => s.subjects[2].passed).length;

    return {
      batch: bId,
      totalStudents: n,
      overallPassRate: n > 0 ? Number(((passCount / n) * 100).toFixed(1)) : 0,
      meanCgpa: n > 0 ? Number((bCohort.reduce((acc, s) => acc + s.cgpa, 0) / n).toFixed(2)) : 0,
      meanSgpa: n > 0 ? Number((bCohort.reduce((acc, s) => acc + s.sgpa, 0) / n).toFixed(2)) : 0,
      distinctionRate: n > 0 ? Number(((distCount / n) * 100).toFixed(1)) : 0,
      osPassRate: n > 0 ? Number(((osPass / n) * 100).toFixed(1)) : 0,
    };
  });

  return {
    batch,
    branch,
    summary: {
      totalStudents,
      passedStudents,
      overallPassRate,
      meanSgpa,
      meanCgpa,
      distinctionCount,
      distinctionRate,
      lowestPassSubject: {
        name: lowestSubj.name,
        code: lowestSubj.code,
        passRate: lowestSubj.passRate,
      },
    },
    cgpaStats,
    subjectAnalytics,
    cgpaDistribution,
    gradeDistribution,
    toppers,
    batchComparison,
  };
}
