import fs from 'fs';
import path from 'path';
import type {DatabaseSync as NodeDatabaseSync} from 'node:sqlite';
import {ALL_STUDENTS} from './dataset.ts';
import {computeMarksheetVerificationHash} from './security.ts';
import {
  BRANCH_NAMES,
  GRADE_POINTS_MAP,
  SUBJECT_CATALOG,
  classifyAcademicStanding,
  computeCGPA,
  computeSGPA,
  determineLetterGrade,
} from '../src/shared/grading.ts';
import type {
  BatchId,
  BranchCode,
  LetterGrade,
  SemesterSnapshot,
  StudentRecord,
  SubjectResult,
} from '../src/shared/grading.ts';

export interface RevaluationApplication {
  challanId: string;
  hallTicket: string;
  studentName: string;
  subjectCodes: string[];
  paperSubtotal: number;
  processingFee: number;
  totalFee: number;
  currency: 'INR';
  submittedAt: string;
}

export interface AuditLogEntry {
  id: number;
  action: string;
  actor: string;
  details: string;
  createdAt: string;
}

export interface ImportStudentInput {
  hallTicket: string;
  name: string;
  fatherName?: string;
  branch: BranchCode;
  batch?: BatchId;
  marks: Array<{
    code: string;
    internal: number;
    external: number;
  }>;
}

export interface UpsertSummary {
  importedCount: number;
  updatedCount: number;
  records: StudentRecord[];
}

export interface StudentRepository {
  readonly engineName: 'sqlite-wal' | 'json-atomic';
  init(): Promise<void>;
  getAllStudents(): StudentRecord[];
  findStudentByHallTicket(hallTicket: string): StudentRecord | null;
  upsertStudents(inputs: ImportStudentInput[], actor: string): UpsertSummary;
  getRevaluations(hallTicket: string): RevaluationApplication[];
  saveRevaluation(
    app: Omit<RevaluationApplication, 'challanId' | 'submittedAt'>,
  ): RevaluationApplication;
  getAuditLogs(limit?: number): AuditLogEntry[];
  close(): void;
}

// Observer Pattern: Event bus for cache invalidation and audit listeners
export type PortalEvent = 'students:mutated' | 'revaluation:created';

export class AnalyticsEventBus {
  private listeners = new Map<PortalEvent, Array<() => void>>();

  subscribe(event: PortalEvent, listener: () => void): () => void {
    const existing = this.listeners.get(event) ?? [];
    existing.push(listener);
    this.listeners.set(event, existing);
    return () => {
      const current = this.listeners.get(event) ?? [];
      this.listeners.set(
        event,
        current.filter((fn) => fn !== listener),
      );
    };
  }

  emit(event: PortalEvent): void {
    const handlers = this.listeners.get(event) ?? [];
    for (const handler of handlers) {
      handler();
    }
  }
}

// Granular retry with exponential backoff for transient file/lock contention
export function withRetry<T>(operation: () => T, maxAttempts = 3, baseDelayMs = 15): T {
  let lastError: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return operation();
    } catch (err) {
      lastError = err;
      if (attempt === maxAttempts) break;
      const waitUntil = Date.now() + baseDelayMs * attempt;
      while (Date.now() < waitUntil) {
        // Brief synchronous backoff for atomic fs/sqlite lock recovery
      }
    }
  }
  throw lastError;
}

function writeFileAtomic(targetPath: string, content: string): void {
  withRetry(() => {
    const dir = path.dirname(targetPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, {recursive: true});
    }
    const tmpPath = `${targetPath}.${process.pid}.${Date.now()}.tmp`;
    fs.writeFileSync(tmpPath, content, 'utf8');
    fs.renameSync(tmpPath, targetPath);
  });
}

export function buildValidatedStudentRecord(entry: ImportStudentInput): StudentRecord {
  const hallTicket = entry.hallTicket.trim().toUpperCase();
  const branch: BranchCode =
    entry.branch === 'ECE' || entry.branch === 'IT' ? entry.branch : 'CSE';
  const batch: BatchId =
    entry.batch === '2021-2025' || entry.batch === '2020-2024' ? entry.batch : '2022-2026';

  const subjects: SubjectResult[] = SUBJECT_CATALOG.map((def) => {
    const found = entry.marks.find(
      (m) => m.code.trim().toUpperCase() === def.code.toUpperCase(),
    );
    const rawInternal = Number(found?.internal ?? 24);
    const rawExternal = Number(found?.external ?? 36);
    if (!Number.isFinite(rawInternal) || rawInternal < 0 || rawInternal > 40) {
      throw new Error(`Invalid internal marks (${found?.internal}) for ${hallTicket} ${def.code}. Must be 0–40.`);
    }
    if (!Number.isFinite(rawExternal) || rawExternal < 0 || rawExternal > 60) {
      throw new Error(`Invalid external marks (${found?.external}) for ${hallTicket} ${def.code}. Must be 0–60.`);
    }

    const internal = Math.round(rawInternal);
    const external = Math.round(rawExternal);
    const grade = determineLetterGrade(internal, external);
    const gradePoints = GRADE_POINTS_MAP[grade];
    return {
      code: def.code,
      name: def.name,
      shortName: def.shortName,
      credits: def.credits,
      type: def.type,
      internalMarks: internal,
      externalMarks: external,
      totalMarks: internal + external,
      grade,
      gradePoints,
      creditPoints: def.credits * gradePoints,
      passed: grade !== 'F',
    };
  });

  const sgpaMetrics = computeSGPA(subjects);
  const priorSemesters: SemesterSnapshot[] = [
    {semester: 'Semester I', sgpa: Number(Math.max(5.5, sgpaMetrics.sgpa - 0.25).toFixed(2)), credits: 20, batchAverage: 7.35},
    {semester: 'Semester II', sgpa: Number(Math.max(5.5, sgpaMetrics.sgpa - 0.15).toFixed(2)), credits: 20, batchAverage: 7.48},
    {semester: 'Semester III', sgpa: Number(Math.max(5.5, sgpaMetrics.sgpa - 0.1).toFixed(2)), credits: 21, batchAverage: 7.62},
    {semester: 'Semester IV', sgpa: Number(Math.max(5.5, sgpaMetrics.sgpa - 0.05).toFixed(2)), credits: 21, batchAverage: 7.54},
  ];
  const cgpa = computeCGPA(priorSemesters, sgpaMetrics.sgpa, sgpaMetrics.totalCredits);

  return {
    hallTicket,
    name: entry.name.trim(),
    fatherName: (entry.fatherName || 'Guardian').trim(),
    branch,
    branchName: BRANCH_NAMES[branch],
    batch,
    semester: 'Semester V',
    examSession:
      batch === '2022-2026'
        ? 'November 2026'
        : batch === '2021-2025'
          ? 'November 2025'
          : 'November 2024',
    regulation: 'R22 Autonomous',
    subjects,
    sgpa: sgpaMetrics.sgpa,
    cgpa,
    totalCredits: sgpaMetrics.totalCredits,
    earnedCredits: sgpaMetrics.earnedCredits,
    totalWeightedPoints: sgpaMetrics.totalWeightedPoints,
    totalMarks: sgpaMetrics.totalMarks,
    maxMarks: sgpaMetrics.maxMarks,
    percentage: sgpaMetrics.percentage,
    hasBacklog: sgpaMetrics.hasBacklog,
    backlogCount: sgpaMetrics.backlogCount,
    classification: classifyAcademicStanding(sgpaMetrics.sgpa, sgpaMetrics.hasBacklog),
    semesterHistory: [
      ...priorSemesters,
      {
        semester: 'Semester V',
        sgpa: sgpaMetrics.sgpa,
        credits: sgpaMetrics.totalCredits,
        batchAverage: 7.65,
      },
    ],
  };
}

// Primary Repository: Indexed SQLite with WAL mode and ACID transactions
export class SqliteStudentRepository implements StudentRepository {
  readonly engineName = 'sqlite-wal' as const;
  private db: NodeDatabaseSync | null = null;
  private readonly dbPath: string;
  private readonly DatabaseSyncCtor: typeof NodeDatabaseSync;

  constructor(dbPath: string, DatabaseSyncCtor: typeof NodeDatabaseSync) {
    this.dbPath = dbPath;
    this.DatabaseSyncCtor = DatabaseSyncCtor;
  }

  async init(): Promise<void> {
    const dir = path.dirname(this.dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, {recursive: true});
    }

    this.db = new this.DatabaseSyncCtor(this.dbPath);
    this.db.exec(`
      PRAGMA journal_mode = WAL;
      PRAGMA synchronous = NORMAL;
      PRAGMA foreign_keys = ON;

      CREATE TABLE IF NOT EXISTS students (
        hall_ticket TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        father_name TEXT NOT NULL,
        branch TEXT NOT NULL,
        branch_name TEXT NOT NULL,
        batch TEXT NOT NULL,
        semester TEXT NOT NULL,
        exam_session TEXT NOT NULL,
        regulation TEXT NOT NULL,
        sgpa REAL NOT NULL,
        cgpa REAL NOT NULL,
        total_credits INTEGER NOT NULL,
        earned_credits INTEGER NOT NULL,
        total_weighted_points INTEGER NOT NULL,
        total_marks INTEGER NOT NULL,
        max_marks INTEGER NOT NULL,
        percentage REAL NOT NULL,
        has_backlog INTEGER NOT NULL,
        backlog_count INTEGER NOT NULL,
        classification TEXT NOT NULL,
        verification_hash TEXT NOT NULL,
        updated_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS subject_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hall_ticket TEXT NOT NULL REFERENCES students(hall_ticket) ON DELETE CASCADE,
        seq_order INTEGER NOT NULL,
        code TEXT NOT NULL,
        name TEXT NOT NULL,
        short_name TEXT NOT NULL,
        credits INTEGER NOT NULL,
        type TEXT NOT NULL,
        internal_marks INTEGER NOT NULL,
        external_marks INTEGER NOT NULL,
        total_marks INTEGER NOT NULL,
        grade TEXT NOT NULL,
        grade_points INTEGER NOT NULL,
        credit_points INTEGER NOT NULL,
        passed INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS semester_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hall_ticket TEXT NOT NULL REFERENCES students(hall_ticket) ON DELETE CASCADE,
        seq_order INTEGER NOT NULL,
        semester TEXT NOT NULL,
        sgpa REAL NOT NULL,
        credits INTEGER NOT NULL,
        batch_average REAL NOT NULL
      );

      CREATE TABLE IF NOT EXISTS revaluation_applications (
        challan_id TEXT PRIMARY KEY,
        hall_ticket TEXT NOT NULL,
        student_name TEXT NOT NULL,
        subject_codes_json TEXT NOT NULL,
        paper_subtotal INTEGER NOT NULL,
        processing_fee INTEGER NOT NULL,
        total_fee INTEGER NOT NULL,
        currency TEXT NOT NULL,
        submitted_at TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS audit_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        action TEXT NOT NULL,
        actor TEXT NOT NULL,
        details TEXT NOT NULL,
        created_at TEXT NOT NULL
      );

      CREATE INDEX IF NOT EXISTS idx_students_batch_branch ON students(batch, branch);
      CREATE INDEX IF NOT EXISTS idx_students_sgpa ON students(sgpa DESC);
      CREATE INDEX IF NOT EXISTS idx_subjects_hall_ticket ON subject_results(hall_ticket, seq_order);
      CREATE INDEX IF NOT EXISTS idx_history_hall_ticket ON semester_history(hall_ticket, seq_order);
      CREATE INDEX IF NOT EXISTS idx_reval_hall_ticket ON revaluation_applications(hall_ticket);
    `);

    const countRow = this.db.prepare('SELECT COUNT(*) AS cnt FROM students').get() as {cnt: number};
    if (countRow.cnt === 0) {
      this.runTransaction(() => {
        for (const student of ALL_STUDENTS) {
          this.insertOrReplaceStudentRow(student);
        }
        this.insertAudit('SYSTEM_SEED', 'System', `Seeded ${ALL_STUDENTS.length} deterministic examination records`);
      });
    }
  }

  private getDb(): NodeDatabaseSync {
    if (!this.db) {
      throw new Error('SQLite repository is not initialized.');
    }
    return this.db;
  }

  private runTransaction<T>(fn: () => T): T {
    return withRetry(() => {
      const db = this.getDb();
      db.exec('BEGIN IMMEDIATE');
      try {
        const result = fn();
        db.exec('COMMIT');
        return result;
      } catch (err) {
        try {
          db.exec('ROLLBACK');
        } catch {
          // Ignore rollback failure
        }
        throw err;
      }
    });
  }

  private insertAudit(action: string, actor: string, details: string): void {
    const db = this.getDb();
    db.prepare(
      'INSERT INTO audit_logs (action, actor, details, created_at) VALUES (?, ?, ?, ?)',
    ).run(action, actor, details, new Date().toISOString());
  }

  private insertOrReplaceStudentRow(student: StudentRecord): void {
    const db = this.getDb();
    const digest = computeMarksheetVerificationHash(student);
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO students (
        hall_ticket, name, father_name, branch, branch_name, batch,
        semester, exam_session, regulation, sgpa, cgpa, total_credits,
        earned_credits, total_weighted_points, total_marks, max_marks,
        percentage, has_backlog, backlog_count, classification, verification_hash, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(hall_ticket) DO UPDATE SET
        name = excluded.name,
        father_name = excluded.father_name,
        branch = excluded.branch,
        branch_name = excluded.branch_name,
        batch = excluded.batch,
        semester = excluded.semester,
        exam_session = excluded.exam_session,
        regulation = excluded.regulation,
        sgpa = excluded.sgpa,
        cgpa = excluded.cgpa,
        total_credits = excluded.total_credits,
        earned_credits = excluded.earned_credits,
        total_weighted_points = excluded.total_weighted_points,
        total_marks = excluded.total_marks,
        max_marks = excluded.max_marks,
        percentage = excluded.percentage,
        has_backlog = excluded.has_backlog,
        backlog_count = excluded.backlog_count,
        classification = excluded.classification,
        verification_hash = excluded.verification_hash,
        updated_at = excluded.updated_at
    `).run(
      student.hallTicket,
      student.name,
      student.fatherName,
      student.branch,
      student.branchName,
      student.batch,
      student.semester,
      student.examSession,
      student.regulation,
      student.sgpa,
      student.cgpa,
      student.totalCredits,
      student.earnedCredits,
      student.totalWeightedPoints,
      student.totalMarks,
      student.maxMarks,
      student.percentage,
      student.hasBacklog ? 1 : 0,
      student.backlogCount,
      student.classification,
      digest,
      now,
    );

    db.prepare('DELETE FROM subject_results WHERE hall_ticket = ?').run(student.hallTicket);
    const insertSubj = db.prepare(`
      INSERT INTO subject_results (
        hall_ticket, seq_order, code, name, short_name, credits, type,
        internal_marks, external_marks, total_marks, grade, grade_points, credit_points, passed
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    student.subjects.forEach((subj, idx) => {
      insertSubj.run(
        student.hallTicket,
        idx,
        subj.code,
        subj.name,
        subj.shortName,
        subj.credits,
        subj.type,
        subj.internalMarks,
        subj.externalMarks,
        subj.totalMarks,
        subj.grade,
        subj.gradePoints,
        subj.creditPoints,
        subj.passed ? 1 : 0,
      );
    });

    db.prepare('DELETE FROM semester_history WHERE hall_ticket = ?').run(student.hallTicket);
    const insertHist = db.prepare(`
      INSERT INTO semester_history (hall_ticket, seq_order, semester, sgpa, credits, batch_average)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    student.semesterHistory.forEach((snap, idx) => {
      insertHist.run(
        student.hallTicket,
        idx,
        snap.semester,
        snap.sgpa,
        snap.credits,
        snap.batchAverage,
      );
    });
  }

  private hydrateRows(
    studentRows: Array<Record<string, unknown>>,
    subjectRows: Array<Record<string, unknown>>,
    historyRows: Array<Record<string, unknown>>,
  ): StudentRecord[] {
    const subjByTicket = new Map<string, SubjectResult[]>();
    for (const r of subjectRows) {
      const ticket = String(r.hall_ticket);
      const list = subjByTicket.get(ticket) ?? [];
      list.push({
        code: String(r.code),
        name: String(r.name),
        shortName: String(r.short_name),
        credits: Number(r.credits),
        type: r.type === 'Lab' ? 'Lab' : 'Theory',
        internalMarks: Number(r.internal_marks),
        externalMarks: Number(r.external_marks),
        totalMarks: Number(r.total_marks),
        grade: String(r.grade) as LetterGrade,
        gradePoints: Number(r.grade_points),
        creditPoints: Number(r.credit_points),
        passed: Number(r.passed) === 1,
      });
      subjByTicket.set(ticket, list);
    }

    const histByTicket = new Map<string, SemesterSnapshot[]>();
    for (const r of historyRows) {
      const ticket = String(r.hall_ticket);
      const list = histByTicket.get(ticket) ?? [];
      list.push({
        semester: String(r.semester),
        sgpa: Number(r.sgpa),
        credits: Number(r.credits),
        batchAverage: Number(r.batch_average),
      });
      histByTicket.set(ticket, list);
    }

    return studentRows.map((row) => {
      const ticket = String(row.hall_ticket);
      return {
        hallTicket: ticket,
        name: String(row.name),
        fatherName: String(row.father_name),
        branch: String(row.branch) as BranchCode,
        branchName: String(row.branch_name),
        batch: String(row.batch) as BatchId,
        semester: String(row.semester),
        examSession: String(row.exam_session),
        regulation: String(row.regulation),
        subjects: subjByTicket.get(ticket) ?? [],
        sgpa: Number(row.sgpa),
        cgpa: Number(row.cgpa),
        totalCredits: Number(row.total_credits),
        earnedCredits: Number(row.earned_credits),
        totalWeightedPoints: Number(row.total_weighted_points),
        totalMarks: Number(row.total_marks),
        maxMarks: Number(row.max_marks),
        percentage: Number(row.percentage),
        hasBacklog: Number(row.has_backlog) === 1,
        backlogCount: Number(row.backlog_count),
        classification: String(row.classification),
        semesterHistory: histByTicket.get(ticket) ?? [],
      };
    });
  }

  getAllStudents(): StudentRecord[] {
    const db = this.getDb();
    const studentRows = db.prepare('SELECT * FROM students ORDER BY hall_ticket ASC').all() as Array<Record<string, unknown>>;
    const subjectRows = db
      .prepare('SELECT * FROM subject_results ORDER BY hall_ticket ASC, seq_order ASC')
      .all() as Array<Record<string, unknown>>;
    const historyRows = db
      .prepare('SELECT * FROM semester_history ORDER BY hall_ticket ASC, seq_order ASC')
      .all() as Array<Record<string, unknown>>;
    return this.hydrateRows(studentRows, subjectRows, historyRows);
  }

  findStudentByHallTicket(hallTicket: string): StudentRecord | null {
    const db = this.getDb();
    const normalized = hallTicket.trim().toUpperCase();
    const row = db
      .prepare('SELECT * FROM students WHERE UPPER(hall_ticket) = ?')
      .get(normalized) as Record<string, unknown> | undefined;
    if (!row) return null;

    const subjectRows = db
      .prepare('SELECT * FROM subject_results WHERE hall_ticket = ? ORDER BY seq_order ASC')
      .all(String(row.hall_ticket)) as Array<Record<string, unknown>>;
    const historyRows = db
      .prepare('SELECT * FROM semester_history WHERE hall_ticket = ? ORDER BY seq_order ASC')
      .all(String(row.hall_ticket)) as Array<Record<string, unknown>>;
    return this.hydrateRows([row], subjectRows, historyRows)[0] ?? null;
  }

  upsertStudents(inputs: ImportStudentInput[], actor: string): UpsertSummary {
    return this.runTransaction(() => {
      const db = this.getDb();
      let importedCount = 0;
      let updatedCount = 0;
      const records: StudentRecord[] = [];
      const checkExists = db.prepare('SELECT 1 FROM students WHERE hall_ticket = ?');

      for (const entry of inputs) {
        const record = buildValidatedStudentRecord(entry);
        const existed = Boolean(checkExists.get(record.hallTicket));
        this.insertOrReplaceStudentRow(record);
        if (existed) {
          updatedCount += 1;
        } else {
          importedCount += 1;
        }
        records.push(record);
      }

      this.insertAudit(
        'BATCH_IMPORT',
        actor,
        `Imported ${importedCount} new and ${updatedCount} updated records (${records.map((r) => r.hallTicket).slice(0, 5).join(', ')})`,
      );

      return {importedCount, updatedCount, records};
    });
  }

  getRevaluations(hallTicket: string): RevaluationApplication[] {
    const db = this.getDb();
    const normalized = hallTicket.trim().toUpperCase();
    const rows = db
      .prepare(
        'SELECT * FROM revaluation_applications WHERE UPPER(hall_ticket) = ? ORDER BY submitted_at DESC',
      )
      .all(normalized) as Array<Record<string, unknown>>;

    return rows.map((r) => ({
      challanId: String(r.challan_id),
      hallTicket: String(r.hall_ticket),
      studentName: String(r.student_name),
      subjectCodes: JSON.parse(String(r.subject_codes_json)) as string[],
      paperSubtotal: Number(r.paper_subtotal),
      processingFee: Number(r.processing_fee),
      totalFee: Number(r.total_fee),
      currency: 'INR',
      submittedAt: String(r.submitted_at),
    }));
  }

  saveRevaluation(
    app: Omit<RevaluationApplication, 'challanId' | 'submittedAt'>,
  ): RevaluationApplication {
    return this.runTransaction(() => {
      const db = this.getDb();
      const countRow = db
        .prepare('SELECT COUNT(*) AS cnt FROM revaluation_applications')
        .get() as {cnt: number};
      const challanId = `MM-REV-${new Date().getFullYear()}-${String(countRow.cnt + 101)}`;
      const submittedAt = new Date().toISOString();

      db.prepare(`
        INSERT INTO revaluation_applications (
          challan_id, hall_ticket, student_name, subject_codes_json,
          paper_subtotal, processing_fee, total_fee, currency, submitted_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(
        challanId,
        app.hallTicket,
        app.studentName,
        JSON.stringify(app.subjectCodes),
        app.paperSubtotal,
        app.processingFee,
        app.totalFee,
        app.currency,
        submittedAt,
      );

      this.insertAudit(
        'REVALUATION_SUBMIT',
        app.hallTicket,
        `Challan ${challanId} for [${app.subjectCodes.join(', ')}] (₹${app.totalFee})`,
      );

      return {
        ...app,
        challanId,
        submittedAt,
      };
    });
  }

  getAuditLogs(limit = 25): AuditLogEntry[] {
    const db = this.getDb();
    const rows = db
      .prepare('SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?')
      .all(limit) as Array<Record<string, unknown>>;
    return rows.map((r) => ({
      id: Number(r.id),
      action: String(r.action),
      actor: String(r.actor),
      details: String(r.details),
      createdAt: String(r.created_at),
    }));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

// Fallback Repository: Atomic temp-file-and-rename JSON store with retry
export class AtomicJsonStudentRepository implements StudentRepository {
  readonly engineName = 'json-atomic' as const;
  private readonly dataDir: string;
  private students: StudentRecord[] = [];
  private revaluations: RevaluationApplication[] = [];
  private auditLogs: AuditLogEntry[] = [];

  constructor(dataDir: string) {
    this.dataDir = dataDir;
  }

  private get studentsFile() {
    return path.join(this.dataDir, 'students.json');
  }
  private get revalFile() {
    return path.join(this.dataDir, 'revaluations.json');
  }
  private get auditFile() {
    return path.join(this.dataDir, 'audit.json');
  }

  async init(): Promise<void> {
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, {recursive: true});
    }
    this.students = this.readJsonOrSeed(this.studentsFile, () => [...ALL_STUDENTS]);
    this.revaluations = this.readJsonOrSeed(this.revalFile, () => []);
    this.auditLogs = this.readJsonOrSeed(this.auditFile, () => [
      {
        id: 1,
        action: 'SYSTEM_SEED',
        actor: 'System',
        details: `Seeded ${this.students.length} records`,
        createdAt: new Date().toISOString(),
      },
    ]);
  }

  private readJsonOrSeed<T>(filePath: string, seedFactory: () => T): T {
    if (fs.existsSync(filePath)) {
      try {
        const raw = withRetry(() => fs.readFileSync(filePath, 'utf8'));
        const parsed = JSON.parse(raw) as T;
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch {
        // Recover by re-seeding
      }
    }
    const seeded = seedFactory();
    writeFileAtomic(filePath, JSON.stringify(seeded, null, 2));
    return seeded;
  }

  getAllStudents(): StudentRecord[] {
    return this.students;
  }

  findStudentByHallTicket(hallTicket: string): StudentRecord | null {
    const normalized = hallTicket.trim().toUpperCase();
    return this.students.find((s) => s.hallTicket.toUpperCase() === normalized) ?? null;
  }

  upsertStudents(inputs: ImportStudentInput[], actor: string): UpsertSummary {
    let importedCount = 0;
    let updatedCount = 0;
    const records: StudentRecord[] = [];

    for (const entry of inputs) {
      const record = buildValidatedStudentRecord(entry);
      const idx = this.students.findIndex((s) => s.hallTicket === record.hallTicket);
      if (idx >= 0) {
        this.students[idx] = record;
        updatedCount += 1;
      } else {
        this.students.push(record);
        importedCount += 1;
      }
      records.push(record);
    }

    writeFileAtomic(this.studentsFile, JSON.stringify(this.students, null, 2));
    this.auditLogs.unshift({
      id: this.auditLogs.length + 1,
      action: 'BATCH_IMPORT',
      actor,
      details: `Imported ${importedCount} new and ${updatedCount} updated records`,
      createdAt: new Date().toISOString(),
    });
    writeFileAtomic(this.auditFile, JSON.stringify(this.auditLogs.slice(0, 100), null, 2));

    return {importedCount, updatedCount, records};
  }

  getRevaluations(hallTicket: string): RevaluationApplication[] {
    const normalized = hallTicket.trim().toUpperCase();
    return this.revaluations.filter((r) => r.hallTicket.toUpperCase() === normalized);
  }

  saveRevaluation(
    app: Omit<RevaluationApplication, 'challanId' | 'submittedAt'>,
  ): RevaluationApplication {
    const created: RevaluationApplication = {
      ...app,
      challanId: `MM-REV-${new Date().getFullYear()}-${String(this.revaluations.length + 101)}`,
      submittedAt: new Date().toISOString(),
    };
    this.revaluations.unshift(created);
    writeFileAtomic(this.revalFile, JSON.stringify(this.revaluations, null, 2));
    return created;
  }

  getAuditLogs(limit = 25): AuditLogEntry[] {
    return this.auditLogs.slice(0, limit);
  }

  close(): void {
    // No persistent handle to close
  }
}

// Factory Pattern: selects SQLite WAL repository when node:sqlite is available, else Atomic JSON
export async function createStorageRepository(dataDir: string): Promise<StudentRepository> {
  try {
    const sqliteModule = await import('node:sqlite');
    if (sqliteModule && typeof sqliteModule.DatabaseSync === 'function') {
      const repo = new SqliteStudentRepository(
        path.join(dataDir, 'markmirror.db'),
        sqliteModule.DatabaseSync,
      );
      await repo.init();
      return repo;
    }
  } catch {
    // Fallback to AtomicJsonStudentRepository on Node < 22.5
  }

  const fallbackRepo = new AtomicJsonStudentRepository(dataDir);
  await fallbackRepo.init();
  return fallbackRepo;
}
