import crypto from 'crypto';
import type {NextFunction, Request, Response} from 'express';
import type {StudentRecord} from '../src/shared/grading.ts';

const ADMIN_PASSKEY = process.env.ADMIN_ACCESS_KEY || 'NIET-ADMIN-2026';
const SIGNING_SECRET = process.env.SIGNING_SECRET || 'markmirror-dev-hmac-signing-secret';
const TOKEN_TTL_MS = 60 * 60 * 1000; // 1 hour

function sha256Buffer(value: string): Buffer {
  return crypto.createHash('sha256').update(value, 'utf8').digest();
}

export function verifyAdminPasskey(candidate: string): boolean {
  if (!candidate || typeof candidate !== 'string') return false;
  const a = sha256Buffer(candidate.trim());
  const b = sha256Buffer(ADMIN_PASSKEY);
  return crypto.timingSafeEqual(a, b);
}

export interface AdminTokenPayload {
  sub: string;
  role: 'exam_admin';
  iat: number;
  exp: number;
}

export function issueAdminToken(actor = 'Exam Cell Admin'): {
  token: string;
  expiresAt: string;
} {
  const now = Date.now();
  const payload: AdminTokenPayload = {
    sub: actor,
    role: 'exam_admin',
    iat: now,
    exp: now + TOKEN_TTL_MS,
  };
  const encodedPayload = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const signature = crypto
    .createHmac('sha256', SIGNING_SECRET)
    .update(encodedPayload)
    .digest('base64url');
  return {
    token: `${encodedPayload}.${signature}`,
    expiresAt: new Date(payload.exp).toISOString(),
  };
}

export function verifyAdminToken(authHeader: string | undefined): AdminTokenPayload | null {
  if (!authHeader || typeof authHeader !== 'string') return null;
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7).trim() : authHeader.trim();
  const parts = token.split('.');
  if (parts.length !== 2) return null;

  const [encodedPayload, providedSig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', SIGNING_SECRET)
    .update(encodedPayload)
    .digest('base64url');

  const sigBufA = Buffer.from(providedSig, 'utf8');
  const sigBufB = Buffer.from(expectedSig, 'utf8');
  if (sigBufA.length !== sigBufB.length || !crypto.timingSafeEqual(sigBufA, sigBufB)) {
    return null;
  }

  try {
    const decoded = JSON.parse(
      Buffer.from(encodedPayload, 'base64url').toString('utf8'),
    ) as AdminTokenPayload;
    if (!decoded || decoded.role !== 'exam_admin' || Date.now() > decoded.exp) {
      return null;
    }
    return decoded;
  } catch {
    return null;
  }
}

export interface AuthenticatedRequest extends Request {
  adminUser?: AdminTokenPayload;
}

export function requireAdminAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
) {
  const authHeader = req.header('authorization') || req.header('x-admin-token');
  const payload = verifyAdminToken(authHeader);
  if (!payload) {
    res.status(401).json({
      error: 'Administrator authorization required. Authenticate via /api/admin/auth first.',
    });
    return;
  }
  req.adminUser = payload;
  next();
}

export function computeMarksheetVerificationHash(student: Pick<
  StudentRecord,
  'hallTicket' | 'batch' | 'sgpa' | 'cgpa' | 'totalWeightedPoints' | 'subjects'
>): string {
  const canonicalSubjects = student.subjects
    .map((s) => `${s.code}:${s.internalMarks}+${s.externalMarks}=${s.grade}`)
    .join('|');
  const payload = `${student.hallTicket}|${student.batch}|${student.sgpa.toFixed(2)}|${student.cgpa.toFixed(2)}|${student.totalWeightedPoints}|${canonicalSubjects}`;
  const rawHex = crypto
    .createHmac('sha256', SIGNING_SECRET)
    .update(payload)
    .digest('hex')
    .toUpperCase()
    .slice(0, 16);
  return `${rawHex.slice(0, 4)}-${rawHex.slice(4, 8)}-${rawHex.slice(8, 12)}-${rawHex.slice(12, 16)}`;
}

export function securityHeadersMiddleware(
  _req: Request,
  res: Response,
  next: NextFunction,
) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  next();
}

export function createRateLimiter(options: {windowMs: number; maxRequests: number}) {
  const hits = new Map<string, number[]>();

  return function rateLimitMiddleware(
    req: Request,
    res: Response,
    next: NextFunction,
  ) {
    const key = req.ip || req.socket.remoteAddress || 'local';
    const now = Date.now();
    const cutoff = now - options.windowMs;
    const recent = (hits.get(key) ?? []).filter((ts) => ts > cutoff);

    if (recent.length >= options.maxRequests) {
      const oldest = recent[0] ?? now;
      const retryAfterSec = Math.max(1, Math.ceil((oldest + options.windowMs - now) / 1000));
      res.setHeader('Retry-After', String(retryAfterSec));
      res.status(429).json({
        error: 'Rate limit exceeded. Please retry shortly.',
        retryAfterSeconds: retryAfterSec,
      });
      return;
    }

    recent.push(now);
    hits.set(key, recent);
    next();
  };
}
