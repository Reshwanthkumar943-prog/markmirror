export interface DescriptiveStats {
  count: number;
  mean: number;
  stdDev: number;
  median: number;
  q1: number;
  q3: number;
  iqr: number;
  min: number;
  max: number;
  skewness: number;
}

export interface GraduationForecast {
  targetCgpa: number;
  requiredSgpa: number;
  feasible: boolean;
  remainingCredits: number;
  status: 'achieved' | 'achievable' | 'stretch' | 'infeasible';
  summary: string;
}

function quantileSorted(sorted: readonly number[], q: number): number {
  if (sorted.length === 0) return 0;
  if (sorted.length === 1) return sorted[0];
  const pos = (sorted.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  const next = sorted[base + 1] ?? sorted[base];
  return Number((sorted[base] + rest * (next - sorted[base])).toFixed(2));
}

export function computeDescriptiveStats(values: readonly number[]): DescriptiveStats {
  const n = values.length;
  if (n === 0) {
    return {
      count: 0,
      mean: 0,
      stdDev: 0,
      median: 0,
      q1: 0,
      q3: 0,
      iqr: 0,
      min: 0,
      max: 0,
      skewness: 0,
    };
  }

  const sorted = [...values].sort((a, b) => a - b);
  const sum = sorted.reduce((acc, v) => acc + v, 0);
  const mean = sum / n;

  const variance =
    sorted.reduce((acc, v) => {
      const diff = v - mean;
      return acc + diff * diff;
    }, 0) / n;
  const stdDev = Math.sqrt(variance);

  let skewness = 0;
  if (stdDev > 1e-6) {
    const m3 =
      sorted.reduce((acc, v) => {
        const z = (v - mean) / stdDev;
        return acc + z * z * z;
      }, 0) / n;
    skewness = Number(m3.toFixed(2));
  }

  const q1 = quantileSorted(sorted, 0.25);
  const median = quantileSorted(sorted, 0.5);
  const q3 = quantileSorted(sorted, 0.75);

  return {
    count: n,
    mean: Number(mean.toFixed(2)),
    stdDev: Number(stdDev.toFixed(2)),
    median,
    q1,
    q3,
    iqr: Number((q3 - q1).toFixed(2)),
    min: Number(sorted[0].toFixed(2)),
    max: Number(sorted[n - 1].toFixed(2)),
    skewness,
  };
}

// Abramowitz and Stegun 7.1.26 rational approximation for erf(x)
function erf(x: number): number {
  const sign = x >= 0 ? 1 : -1;
  const absX = Math.abs(x);
  const t = 1 / (1 + 0.3275911 * absX);
  const y =
    1 -
    (((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t +
      0.254829592) *
      t) *
      Math.exp(-absX * absX);
  return sign * y;
}

export function normalCdfPercentile(zScore: number): number {
  const cdf = 0.5 * (1 + erf(zScore / Math.SQRT2));
  return Number((Math.max(0.1, Math.min(99.9, cdf * 100))).toFixed(1));
}

export function computeZScore(value: number, mean: number, stdDev: number): {
  zScore: number;
  percentile: number;
} {
  if (stdDev <= 1e-6) {
    return {zScore: 0, percentile: 50};
  }
  const z = (value - mean) / stdDev;
  return {
    zScore: Number(z.toFixed(2)),
    percentile: normalCdfPercentile(z),
  };
}

export function evaluateGaussianBinExpectation(
  binMidpoint: number,
  binWidth: number,
  totalCount: number,
  mean: number,
  stdDev: number,
): number {
  if (totalCount === 0 || stdDev <= 1e-6) return 0;
  const exponent = -0.5 * Math.pow((binMidpoint - mean) / stdDev, 2);
  const pdf = (1 / (stdDev * Math.sqrt(2 * Math.PI))) * Math.exp(exponent);
  return Number((totalCount * binWidth * pdf).toFixed(1));
}

export function forecastTargetGraduationCGPA(
  currentCgpa: number,
  completedCredits: number,
  remainingCredits: number,
  targetCgpa: number,
): GraduationForecast {
  if (remainingCredits <= 0) {
    return {
      targetCgpa,
      requiredSgpa: currentCgpa,
      feasible: currentCgpa >= targetCgpa,
      remainingCredits: 0,
      status: currentCgpa >= targetCgpa ? 'achieved' : 'infeasible',
      summary: 'All degree credits completed.',
    };
  }

  const totalCredits = completedCredits + remainingCredits;
  const requiredPoints = targetCgpa * totalCredits - currentCgpa * completedCredits;
  const requiredSgpa = Number((requiredPoints / remainingCredits).toFixed(2));

  if (requiredSgpa <= 0) {
    return {
      targetCgpa,
      requiredSgpa: 0,
      feasible: true,
      remainingCredits,
      status: 'achieved',
      summary: `Target ${targetCgpa.toFixed(2)} CGPA is already secured with minimum passing grades.`,
    };
  }

  if (requiredSgpa > 10) {
    return {
      targetCgpa,
      requiredSgpa,
      feasible: false,
      remainingCredits,
      status: 'infeasible',
      summary: `Requires ${requiredSgpa.toFixed(2)} SGPA across remaining ${remainingCredits} credits (exceeds 10.00 ceiling).`,
    };
  }

  if (requiredSgpa >= 9.0) {
    return {
      targetCgpa,
      requiredSgpa,
      feasible: true,
      remainingCredits,
      status: 'stretch',
      summary: `Requires ${requiredSgpa.toFixed(2)} average SGPA across Sem VI–VIII (${remainingCredits} credits).`,
    };
  }

  return {
    targetCgpa,
    requiredSgpa,
    feasible: true,
    remainingCredits,
    status: 'achievable',
    summary: `Achievable with ${requiredSgpa.toFixed(2)} average SGPA over remaining ${remainingCredits} credits.`,
  };
}
