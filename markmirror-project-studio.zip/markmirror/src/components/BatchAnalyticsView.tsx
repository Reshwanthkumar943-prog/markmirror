import {useMemo, useState} from 'react';
import {Download, Upload} from 'lucide-react';
import type {ChartConfiguration} from 'chart.js';
import type {BatchId, BranchCode} from '../shared/grading.ts';
import type {BatchAnalyticsResponse} from '../types/portal.ts';
import {ChartCanvas} from './ChartCanvas.tsx';
import {ImportModal} from './ImportModal.tsx';

interface BatchAnalyticsViewProps {
  analytics: BatchAnalyticsResponse | null;
  isLoading: boolean;
  batch: BatchId;
  branch: BranchCode | 'ALL';
  onBatchChange: (batch: BatchId) => void;
  onBranchChange: (branch: BranchCode | 'ALL') => void;
  onInspectStudent: (hallTicket: string) => void;
  onOpenToppers: () => void;
  onRefreshAnalytics: () => void;
}

const BATCH_OPTIONS: BatchId[] = ['2022-2026', '2021-2025', '2020-2024'];
const BRANCH_OPTIONS: Array<{value: BranchCode | 'ALL'; label: string}> = [
  {value: 'ALL', label: 'All Branches'},
  {value: 'CSE', label: 'CSE'},
  {value: 'ECE', label: 'ECE'},
  {value: 'IT', label: 'IT'},
];

const SUBJECT_PALETTE = ['#4f46e5', '#0d9488', '#e11d48', '#7c3aed', '#0284c7', '#10b981'];

export function BatchAnalyticsView({
  analytics,
  isLoading,
  batch,
  branch,
  onBatchChange,
  onBranchChange,
  onInspectStudent,
  onOpenToppers,
  onRefreshAnalytics,
}: BatchAnalyticsViewProps) {
  const [subjectMetricMode, setSubjectMetricMode] = useState<'passRate' | 'difficulty'>('passRate');
  const [importOpen, setImportOpen] = useState(false);

  // 1. Subject Pass-Rate / Difficulty Bar Chart
  const subjectChartConfig = useMemo<ChartConfiguration<'bar'> | null>(() => {
    if (!analytics) return null;
    const subjects = analytics.subjectAnalytics;

    if (subjectMetricMode === 'passRate') {
      const lowestPass = analytics.summary.lowestPassSubject.code;
      return {
        type: 'bar',
        data: {
          labels: subjects.map((s) => s.shortName),
          datasets: [
            {
              label: 'Pass Rate (%)',
              data: subjects.map((s) => s.passRate),
              backgroundColor: subjects.map((s, idx) =>
                s.code === lowestPass ? '#e11d48' : SUBJECT_PALETTE[idx % SUBJECT_PALETTE.length],
              ),
              borderRadius: 8,
              maxBarThickness: 48,
            },
          ],
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {display: false},
            tooltip: {
              backgroundColor: '#1e1b4b',
              padding: 10,
              callbacks: {
                afterLabel: (ctx) => {
                  const subj = subjects[ctx.dataIndex];
                  return `Passed: ${subj.passed}/${subj.appeared} · Avg Marks: ${subj.avgMarks}`;
                },
              },
            },
          },
          scales: {
            y: {
              min: 0,
              max: 100,
              ticks: {
                callback: (v) => `${v}%`,
                font: {family: "'IBM Plex Mono', monospace", size: 11},
              },
              grid: {color: '#f1f5f9'},
            },
            x: {
              ticks: {font: {family: "'Plus Jakarta Sans', sans-serif", size: 12}},
              grid: {display: false},
            },
          },
        },
      };
    }

    return {
      type: 'bar',
      data: {
        labels: subjects.map((s) => s.shortName),
        datasets: [
          {
            label: 'Difficulty Index (0–100)',
            data: subjects.map((s) => s.difficultyScore),
            backgroundColor: subjects.map((s) =>
              s.difficultyTier === 'High'
                ? '#e11d48'
                : s.difficultyTier === 'Moderate'
                  ? '#f59e0b'
                  : '#10b981',
            ),
            borderRadius: 8,
            maxBarThickness: 48,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {display: false},
          tooltip: {
            backgroundColor: '#1e1b4b',
            padding: 10,
            callbacks: {
              afterLabel: (ctx) => {
                const subj = subjects[ctx.dataIndex];
                return `Tier: ${subj.difficultyTier} · Fail Rate: ${subj.failRate}%`;
              },
            },
          },
        },
        scales: {
          y: {
            min: 0,
            max: 100,
            ticks: {font: {family: "'IBM Plex Mono', monospace", size: 11}},
            grid: {color: '#f1f5f9'},
          },
          x: {
            ticks: {font: {family: "'Plus Jakarta Sans', sans-serif", size: 12}},
            grid: {display: false},
          },
        },
      },
    };
  }, [analytics, subjectMetricMode]);

  // 2. CGPA Distribution Histogram + Gaussian Bell Curve Overlay
  const cgpaHistConfig = useMemo<ChartConfiguration<'bar' | 'line'> | null>(() => {
    if (!analytics) return null;
    const bins = analytics.cgpaDistribution;
    return {
      type: 'bar',
      data: {
        labels: bins.map((b) => b.label),
        datasets: [
          {
            type: 'line',
            label: `Gaussian Fit (μ=${analytics.cgpaStats.mean.toFixed(2)}, σ=${analytics.cgpaStats.stdDev.toFixed(2)})`,
            data: bins.map((b) => b.gaussianExpected),
            borderColor: '#0f172a',
            backgroundColor: '#0f172a',
            borderWidth: 2,
            borderDash: [4, 4],
            pointRadius: 4,
            pointBackgroundColor: '#ffffff',
            pointBorderColor: '#0f172a',
            pointBorderWidth: 2,
            tension: 0.35,
            order: 0,
          },
          {
            type: 'bar',
            label: 'Observed Students',
            data: bins.map((b) => b.count),
            backgroundColor: ['#10b981', '#4f46e5', '#0ea5e9', '#f59e0b', '#e11d48'],
            borderRadius: 8,
            maxBarThickness: 50,
            order: 1,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            display: true,
            position: 'bottom',
            labels: {
              boxWidth: 12,
              usePointStyle: true,
              font: {family: "'IBM Plex Mono', monospace", size: 11},
            },
          },
          tooltip: {
            backgroundColor: '#1e1b4b',
            padding: 10,
            callbacks: {
              label: (ctx) => {
                const bin = bins[ctx.dataIndex];
                if (ctx.datasetIndex === 0) {
                  return `Normal Fit Expected: ${bin.gaussianExpected} students`;
                }
                return `Observed: ${bin.count} students (${bin.percentage}%)`;
              },
            },
          },
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              precision: 0,
              font: {family: "'IBM Plex Mono', monospace", size: 11},
            },
            grid: {color: '#f1f5f9'},
          },
          x: {
            ticks: {font: {family: "'IBM Plex Mono', monospace", size: 11}},
            grid: {display: false},
          },
        },
      },
    };
  }, [analytics]);

  // 3. Letter Grade Distribution Doughnut
  const gradeDoughnutConfig = useMemo<ChartConfiguration<'doughnut'> | null>(() => {
    if (!analytics) return null;
    const grades = analytics.gradeDistribution;
    return {
      type: 'doughnut',
      data: {
        labels: grades.map((g) => `Grade ${g.grade}`),
        datasets: [
          {
            data: grades.map((g) => g.count),
            backgroundColor: [
              '#10b981', // O
              '#4f46e5', // A+
              '#7c3aed', // A
              '#0d9488', // B+
              '#f59e0b', // B
              '#f97316', // C
              '#e11d48', // F
            ],
            borderColor: '#ffffff',
            borderWidth: 2.5,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '62%',
        plugins: {
          legend: {
            position: 'right',
            labels: {
              boxWidth: 12,
              padding: 14,
              font: {family: "'IBM Plex Mono', monospace", size: 12},
            },
          },
          tooltip: {
            backgroundColor: '#1e1b4b',
            padding: 10,
            callbacks: {
              label: (ctx) => {
                const g = grades[ctx.dataIndex];
                return `${g.grade}: ${g.count} papers (${g.percentage}%)`;
              },
            },
          },
        },
      },
    };
  }, [analytics]);

  // 4. Cross-Batch Comparison Chart
  const batchCompareConfig = useMemo<ChartConfiguration<'bar'> | null>(() => {
    if (!analytics) return null;
    const rows = analytics.batchComparison;
    return {
      type: 'bar',
      data: {
        labels: rows.map((r) => r.batch),
        datasets: [
          {
            label: 'Overall Pass Rate (%)',
            data: rows.map((r) => r.overallPassRate),
            backgroundColor: '#4f46e5',
            borderRadius: 6,
          },
          {
            label: 'Operating Systems Pass Rate (%)',
            data: rows.map((r) => r.osPassRate),
            backgroundColor: '#e11d48',
            borderRadius: 6,
          },
          {
            label: 'Distinction Rate (%)',
            data: rows.map((r) => r.distinctionRate),
            backgroundColor: '#10b981',
            borderRadius: 6,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 12,
              usePointStyle: true,
              font: {family: "'Plus Jakarta Sans', sans-serif", size: 12},
            },
          },
          tooltip: {
            backgroundColor: '#1e1b4b',
            padding: 10,
          },
        },
        scales: {
          y: {
            min: 0,
            max: 100,
            ticks: {
              callback: (v) => `${v}%`,
              font: {family: "'IBM Plex Mono', monospace", size: 11},
            },
            grid: {color: '#f1f5f9'},
          },
          x: {
            ticks: {font: {family: "'IBM Plex Mono', monospace", size: 12}},
            grid: {display: false},
          },
        },
      },
    };
  }, [analytics]);

  return (
    <div>
      {/* Vibrant Cohort Banner */}
      <section className="relative overflow-hidden bg-gradient-to-r from-teal-900 via-indigo-950 to-violet-950 text-white border-b border-indigo-900">
        <div className="absolute inset-0 bg-radar-grid opacity-45 pointer-events-none" aria-hidden="true" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div>
            <p className="text-xs font-semibold text-teal-300 mb-1.5">
              Cohort Performance &amp; Curriculum Diagnostics
            </p>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
              Batch Examination Analytics
            </h1>
            <p className="mt-1.5 text-sm text-indigo-100/90 max-w-2xl">
              Subject pass-rate diagnostics, CGPA distribution histograms, difficulty indexing, and multi-batch benchmarks.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            {/* Batch Segmented Control */}
            <div className="flex items-center gap-1 p-1 bg-white/10 backdrop-blur-md border border-white/20 rounded-lg">
              {BATCH_OPTIONS.map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => onBatchChange(b)}
                  className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    batch === b
                      ? 'bg-amber-400 text-slate-950 font-bold'
                      : 'text-indigo-100 hover:text-white'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>

            {/* Branch Segmented Control */}
            <div className="flex items-center gap-1 p-1 bg-white/10 backdrop-blur-md border border-white/20 rounded-lg">
              {BRANCH_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => onBranchChange(opt.value)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    branch === opt.value
                      ? 'bg-white text-indigo-950 font-bold'
                      : 'text-indigo-100 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>

            {/* Cohort Export & Import Actions */}
            <div className="flex items-center gap-2">
              <a
                href={`/api/analytics/export.csv?batch=${encodeURIComponent(batch)}&branch=${encodeURIComponent(branch)}`}
                download={`markmirror_${batch}_${branch}.csv`}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-white/15 hover:bg-white/25 border border-white/25 rounded-lg transition-colors whitespace-nowrap"
              >
                <Download className="w-3.5 h-3.5" aria-hidden="true" />
                Export CSV
              </a>
              <button
                type="button"
                onClick={() => setImportOpen(true)}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-950 bg-emerald-300 hover:bg-emerald-200 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" aria-hidden="true" />
                Import Records
              </button>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {isLoading || !analytics ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {[1, 2, 3, 4].map((idx) => (
              <div key={idx} className="h-28 bg-white border border-slate-200 rounded-2xl p-5 animate-pulse" />
            ))}
          </div>
        ) : (
          <>
            {/* 4-Column Chromatic KPI Strip */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-indigo-50/70 border border-indigo-200 rounded-2xl p-5">
                <div className="text-xs font-semibold text-indigo-800">Students Evaluated</div>
                <div className="mt-2 text-3xl font-mono font-bold tabular-nums text-indigo-950">
                  {analytics.summary.totalStudents}
                </div>
                <div className="mt-1 text-xs text-indigo-700/80">
                  Batch {analytics.batch} · {analytics.branch === 'ALL' ? 'All Branches' : analytics.branch}
                </div>
              </div>

              <div className="bg-teal-50/80 border border-teal-200 rounded-2xl p-5">
                <div className="text-xs font-semibold text-teal-800">Overall Cohort Pass Rate</div>
                <div className="mt-2 text-3xl font-mono font-bold tabular-nums text-teal-950">
                  {analytics.summary.overallPassRate.toFixed(1)}%
                </div>
                <div className="mt-1 text-xs text-teal-800/80 font-mono tabular-nums">
                  {analytics.summary.passedStudents} all-clear ·{' '}
                  {analytics.summary.totalStudents - analytics.summary.passedStudents} with backlog
                </div>
              </div>

              <div className="bg-violet-50/80 border border-violet-200 rounded-2xl p-5">
                <div className="text-xs font-semibold text-violet-800">Cohort Mean CGPA</div>
                <div className="mt-2 text-3xl font-mono font-bold tabular-nums text-violet-950">
                  {analytics.summary.meanCgpa.toFixed(2)}
                </div>
                <div className="mt-1 text-xs text-violet-800/80 font-mono tabular-nums">
                  Sem V Mean SGPA: {analytics.summary.meanSgpa.toFixed(2)}
                </div>
              </div>

              <div className="bg-rose-50/80 border border-rose-200 rounded-2xl p-5">
                <div className="text-xs font-semibold text-rose-800">Lowest Subject Pass Rate</div>
                <div className="mt-2 text-3xl font-mono font-bold tabular-nums text-rose-700">
                  {analytics.summary.lowestPassSubject.passRate.toFixed(0)}%
                </div>
                <div className="mt-1 text-xs text-rose-900 font-semibold">
                  {analytics.summary.lowestPassSubject.name} ({analytics.summary.lowestPassSubject.code})
                </div>
              </div>
            </div>

            {/* Primary Charts Grid: Subject Pass-Rate & CGPA Distribution */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <section className="lg:col-span-7 bg-white border border-indigo-100 rounded-2xl p-6 shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
                  <div>
                    <h2 className="text-base font-bold text-slate-900">
                      {subjectMetricMode === 'passRate'
                        ? 'Subject Pass-Rate Analytics'
                        : 'Subject Difficulty Index'}
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {subjectMetricMode === 'passRate'
                        ? `${analytics.summary.lowestPassSubject.name} recorded the lowest pass rate at ${analytics.summary.lowestPassSubject.passRate}%`
                        : 'Computed from subject failure rate and average cohort score (0–100 scale)'}
                    </p>
                  </div>

                  <div className="flex items-center gap-1 p-1 bg-indigo-50 rounded-lg shrink-0">
                    <button
                      type="button"
                      onClick={() => setSubjectMetricMode('passRate')}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                        subjectMetricMode === 'passRate'
                          ? 'bg-indigo-700 text-white font-semibold'
                          : 'text-indigo-900 hover:bg-indigo-100'
                      }`}
                    >
                      Pass Rate %
                    </button>
                    <button
                      type="button"
                      onClick={() => setSubjectMetricMode('difficulty')}
                      className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                        subjectMetricMode === 'difficulty'
                          ? 'bg-indigo-700 text-white font-semibold'
                          : 'text-indigo-900 hover:bg-indigo-100'
                      }`}
                    >
                      Difficulty Index
                    </button>
                  </div>
                </div>

                <div className="h-72">
                  {subjectChartConfig && (
                    <ChartCanvas
                      config={subjectChartConfig}
                      ariaLabel="Subject pass rate and difficulty analytics bar chart"
                    />
                  )}
                </div>
              </section>

              <section className="lg:col-span-5 bg-white border border-teal-100 rounded-2xl p-6 shadow-sm">
                <div className="mb-4">
                  <h2 className="text-base font-bold text-slate-900">
                    CGPA Distribution &amp; Normal Curve Fit
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    μ={analytics.cgpaStats.mean.toFixed(2)} · σ={analytics.cgpaStats.stdDev.toFixed(2)} · Median={analytics.cgpaStats.median.toFixed(2)} · IQR={analytics.cgpaStats.iqr.toFixed(2)}
                  </p>
                </div>

                <div className="h-72">
                  {cgpaHistConfig && (
                    <ChartCanvas
                      config={cgpaHistConfig}
                      ariaLabel="Cohort CGPA distribution histogram with Gaussian bell curve overlay"
                    />
                  )}
                </div>
              </section>
            </div>

            {/* Secondary Charts Grid: Letter Grade Doughnut & Batch Comparison */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <section className="lg:col-span-5 bg-white border border-violet-100 rounded-2xl p-6 shadow-sm">
                <div className="mb-5">
                  <h2 className="text-base font-bold text-slate-900">
                    Letter Grade Distribution
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Aggregate distribution across {analytics.summary.totalStudents * 6} evaluated subject papers
                  </p>
                </div>

                <div className="h-64">
                  {gradeDoughnutConfig && (
                    <ChartCanvas
                      config={gradeDoughnutConfig}
                      ariaLabel="Letter grade distribution doughnut chart"
                    />
                  )}
                </div>
              </section>

              <section className="lg:col-span-7 bg-white border border-indigo-100 rounded-2xl p-6 shadow-sm">
                <div className="mb-5">
                  <h2 className="text-base font-bold text-slate-900">
                    Multi-Batch Comparison
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Historical benchmark comparing pass rates, Operating Systems outcomes, and distinction rates
                  </p>
                </div>

                <div className="h-64">
                  {batchCompareConfig && (
                    <ChartCanvas
                      config={batchCompareConfig}
                      ariaLabel="Multi-batch comparison bar chart"
                    />
                  )}
                </div>
              </section>
            </div>

            {/* Subject Breakdown Table + Top 5 Celebratory Spotlight */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              <section className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                <div className="px-6 py-4 border-b border-slate-200 bg-slate-50/80">
                  <h2 className="text-base font-bold text-slate-900">
                    Subject-Wise Pass &amp; Difficulty Matrix
                  </h2>
                </div>
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-sm">
                    <thead>
                      <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                        <th scope="col" className="py-3 pl-6 pr-3">Subject</th>
                        <th scope="col" className="py-3 px-3 text-right">Pass Rate</th>
                        <th scope="col" className="py-3 px-3 text-right">Mean Marks</th>
                        <th scope="col" className="py-3 px-3 text-right">Highest</th>
                        <th scope="col" className="py-3 pl-3 pr-6 text-right">Difficulty</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200">
                      {analytics.subjectAnalytics.map((s) => (
                        <tr key={s.code} className="hover:bg-indigo-50/30 transition-colors">
                          <td className="py-3 pl-6 pr-3">
                            <div className="font-medium text-slate-900">{s.name}</div>
                            <div className="text-xs font-mono text-indigo-600">
                              {s.code} · {s.credits} credits
                            </div>
                          </td>
                          <td className="py-3 px-3 text-right font-mono font-bold tabular-nums">
                            <span className={s.passRate < 75 ? 'text-rose-600' : 'text-teal-700'}>
                              {s.passRate.toFixed(1)}%
                            </span>
                          </td>
                          <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                            {s.avgMarks.toFixed(1)}
                          </td>
                          <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                            {s.highestMarks}
                          </td>
                          <td className="py-3 pl-3 pr-6 text-right font-mono text-xs tabular-nums">
                            <span
                              className={`font-bold ${
                                s.difficultyTier === 'High'
                                  ? 'text-rose-600'
                                  : s.difficultyTier === 'Moderate'
                                    ? 'text-amber-600'
                                    : 'text-emerald-600'
                              }`}
                            >
                              {s.difficultyScore} · {s.difficultyTier}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </section>

              {/* Top 5 Department Toppers Preview */}
              <section className="lg:col-span-5 bg-white border border-amber-200 rounded-2xl overflow-hidden shadow-sm flex flex-col justify-between">
                <div>
                  <div className="px-6 py-4 border-b border-amber-100 bg-gradient-to-r from-amber-50 to-orange-50/60 flex items-center justify-between gap-4">
                    <div>
                      <h2 className="text-base font-bold text-slate-900">
                        Top 5 Department Achievers
                      </h2>
                      <p className="text-xs text-slate-600">Click any candidate to inspect marksheet</p>
                    </div>
                    <button
                      type="button"
                      onClick={onOpenToppers}
                      className="text-xs font-bold text-indigo-700 hover:text-indigo-900 hover:underline underline-offset-4 whitespace-nowrap cursor-pointer"
                    >
                      View Top 10
                    </button>
                  </div>

                  <div className="divide-y divide-slate-200">
                    {analytics.toppers.slice(0, 5).map((topper) => (
                      <button
                        key={topper.hallTicket}
                        type="button"
                        onClick={() => onInspectStudent(topper.hallTicket)}
                        className="w-full px-6 py-3.5 text-left hover:bg-amber-50/40 transition-colors flex items-center justify-between gap-4 cursor-pointer"
                      >
                        <div className="flex items-center gap-3.5 min-w-0">
                          <span
                            className={`w-8 h-8 rounded-lg flex items-center justify-center font-mono text-xs font-bold shrink-0 ${
                              topper.rank === 1
                                ? 'bg-amber-400 text-slate-950'
                                : topper.rank === 2
                                  ? 'bg-indigo-600 text-white'
                                  : topper.rank === 3
                                    ? 'bg-orange-500 text-white'
                                    : topper.rank === 4
                                      ? 'bg-teal-600 text-white'
                                      : 'bg-violet-600 text-white'
                            }`}
                          >
                            {String(topper.rank).padStart(2, '0')}
                          </span>
                          <div className="min-w-0">
                            <div className="text-sm font-semibold text-slate-900 truncate">
                              {topper.name}
                            </div>
                            <div className="text-xs font-mono text-indigo-700">
                              {topper.hallTicket} · {topper.branch}
                            </div>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <div className="text-sm font-mono font-bold tabular-nums text-emerald-700">
                            {topper.sgpa.toFixed(2)} SGPA
                          </div>
                          <div className="text-xs font-mono tabular-nums text-slate-500">
                            {topper.cgpa.toFixed(2)} CGPA
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </section>
            </div>
          </>
        )}
      </div>

      <ImportModal
        isOpen={importOpen}
        onClose={() => setImportOpen(false)}
        onImported={() => {
          onRefreshAnalytics();
        }}
      />
    </div>
  );
}
