import {useState} from 'react';
import {CheckCircle2, Download, KeyRound, ShieldCheck, Upload, X} from 'lucide-react';
import type {BatchId, BranchCode} from '../shared/grading.ts';

interface ImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImported: (firstHallTicket?: string) => void;
}

interface ParsedStudentRow {
  hallTicket: string;
  name: string;
  branch: BranchCode;
  batch: BatchId;
  marks: Array<{code: string; internal: number; external: number}>;
}

const SAMPLE_CSV = [
  'hallTicket,name,branch,batch,MA301_int,MA301_ext,CS302_int,CS302_ext,CS303_int,CS303_ext,CS304_int,CS304_ext,CS305_int,CS305_ext,CS306L_int,CS306L_ext',
  '22CSE199,Niharika Rao,CSE,2022-2026,35,52,37,55,32,48,34,50,36,51,38,56',
  '22ECE199,Arvind Menon,ECE,2022-2026,31,45,33,47,26,39,30,44,32,46,35,50',
].join('\n');

function parseCsvText(raw: string): ParsedStudentRow[] {
  const lines = raw
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean);
  if (lines.length === 0) return [];

  const startIdx = lines[0].toLowerCase().startsWith('hallticket') ? 1 : 0;
  const rows: ParsedStudentRow[] = [];

  for (let i = startIdx; i < lines.length; i++) {
    const cols = lines[i].split(',').map((c) => c.trim());
    if (cols.length < 16) continue;
    const [
      hallTicket,
      name,
      branchRaw,
      batchRaw,
      maInt,
      maExt,
      dbmsInt,
      dbmsExt,
      osInt,
      osExt,
      cnInt,
      cnExt,
      seInt,
      seExt,
      aiInt,
      aiExt,
    ] = cols;

    if (!hallTicket || !name) continue;
    const branchUpper = branchRaw.toUpperCase();
    const branch: BranchCode =
      branchUpper === 'ECE' || branchUpper === 'IT' ? branchUpper : 'CSE';
    const batch: BatchId =
      batchRaw === '2021-2025' || batchRaw === '2020-2024' ? batchRaw : '2022-2026';

    rows.push({
      hallTicket: hallTicket.toUpperCase(),
      name,
      branch,
      batch,
      marks: [
        {code: 'MA301', internal: Number(maInt), external: Number(maExt)},
        {code: 'CS302', internal: Number(dbmsInt), external: Number(dbmsExt)},
        {code: 'CS303', internal: Number(osInt), external: Number(osExt)},
        {code: 'CS304', internal: Number(cnInt), external: Number(cnExt)},
        {code: 'CS305', internal: Number(seInt), external: Number(seExt)},
        {code: 'CS306L', internal: Number(aiInt), external: Number(aiExt)},
      ],
    });
  }
  return rows;
}

export function ImportModal({isOpen, onClose, onImported}: ImportModalProps) {
  const [passkey, setPasskey] = useState('');
  const [adminToken, setAdminToken] = useState<string | null>(null);
  const [authLoading, setAuthLoading] = useState(false);

  const [inputText, setInputText] = useState(SAMPLE_CSV);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleAuthenticate = async (keyToTry: string) => {
    setError(null);
    setAuthLoading(true);
    try {
      const res = await fetch('/api/admin/auth', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({passkey: keyToTry}),
      });
      if (!res.ok) {
        const errBody = (await res.json().catch(() => ({}))) as {error?: string};
        setError(errBody.error || 'Authentication failed.');
        setAdminToken(null);
        return;
      }
      const payload = (await res.json()) as {token: string};
      setAdminToken(payload.token);
      setPasskey(keyToTry);
    } catch {
      setError('Network error during Exam Cell authentication.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    setInputText(text);
    setError(null);
    setSuccessMsg(null);
  };

  const handleDownloadTemplate = () => {
    const blob = new Blob([SAMPLE_CSV], {type: 'text/csv;charset=utf-8'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'markmirror_import_template.csv';
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleSubmit = async () => {
    setError(null);
    setSuccessMsg(null);

    if (!adminToken) {
      setError('Authenticate with your Exam Cell passkey before importing records.');
      return;
    }

    let records: ParsedStudentRow[] = [];
    const trimmed = inputText.trim();
    if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
      try {
        const parsed = JSON.parse(trimmed) as unknown;
        const arr = Array.isArray(parsed) ? parsed : [parsed];
        records = arr as ParsedStudentRow[];
      } catch {
        setError('Invalid JSON format. Check brackets and commas.');
        return;
      }
    } else {
      records = parseCsvText(trimmed);
    }

    if (records.length === 0) {
      setError('No valid rows detected. Use the CSV template format or valid JSON.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/students/import', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${adminToken}`,
        },
        body: JSON.stringify({records}),
      });

      if (!res.ok) {
        const errBody = (await res.json().catch(() => ({}))) as {error?: string};
        if (res.status === 401) setAdminToken(null);
        setError(errBody.error || 'Import failed.');
        return;
      }

      const data = (await res.json()) as {
        importedCount: number;
        updatedCount: number;
        totalRecords: number;
      };
      setSuccessMsg(
        `Committed ${data.importedCount} new and ${data.updatedCount} updated records to SQLite (${data.totalRecords} total).`,
      );
      onImported(records[0]?.hallTicket);
    } catch {
      setError('Network error while importing records.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="import-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/60 backdrop-blur-sm"
    >
      <div className="bg-white border border-indigo-200 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden">
        <div className="px-6 py-4 bg-gradient-to-r from-indigo-900 to-violet-900 text-white flex items-center justify-between gap-4">
          <div>
            <h2 id="import-modal-title" className="text-base font-bold">
              Authorized Exam Cell Import (CSV / JSON)
            </h2>
            <p className="text-xs text-indigo-100 mt-0.5">
              HMAC-authenticated import into persistent SQLite storage with automatic analytics rebuild
            </p>
          </div>
          <button
            type="button"
            aria-label="Close modal"
            onClick={onClose}
            className="p-1.5 text-indigo-200 hover:text-white rounded-lg cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4">
          {/* Exam Cell Authorization Bar */}
          <div className="p-3.5 rounded-xl bg-slate-50 border border-slate-200 space-y-2.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-800">
                <KeyRound className="w-3.5 h-3.5 text-indigo-700" aria-hidden="true" />
                Exam Cell Authorization
              </div>
              {adminToken ? (
                <span className="inline-flex items-center gap-1 text-xs font-semibold text-emerald-700">
                  <ShieldCheck className="w-3.5 h-3.5" aria-hidden="true" />
                  Authorized Session Active
                </span>
              ) : (
                <button
                  type="button"
                  onClick={() => void handleAuthenticate('NIET-ADMIN-2026')}
                  className="text-xs font-semibold text-indigo-700 hover:underline underline-offset-4 cursor-pointer"
                >
                  Use Demo Passkey (NIET-ADMIN-2026)
                </button>
              )}
            </div>

            {!adminToken && (
              <div className="flex items-center gap-2">
                <input
                  type="password"
                  value={passkey}
                  onChange={(e) => setPasskey(e.target.value)}
                  placeholder="Enter Exam Cell Passkey"
                  className="flex-1 h-9 px-3 bg-white border border-slate-300 rounded-lg text-xs font-mono text-slate-900 focus:border-indigo-700 focus:outline-none"
                />
                <button
                  type="button"
                  disabled={authLoading || !passkey.trim()}
                  onClick={() => void handleAuthenticate(passkey)}
                  className="px-4 h-9 text-xs font-semibold text-white bg-indigo-700 hover:bg-indigo-800 disabled:bg-slate-300 rounded-lg cursor-pointer"
                >
                  {authLoading ? 'Verifying...' : 'Authorize'}
                </button>
              </div>
            )}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-3">
            <label className="inline-flex items-center gap-2 px-3.5 py-2 text-xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 rounded-lg cursor-pointer">
              <Upload className="w-3.5 h-3.5" aria-hidden="true" />
              Choose CSV / JSON File
              <input
                type="file"
                accept=".csv,.json,.txt"
                onChange={handleFileUpload}
                className="sr-only"
              />
            </label>

            <button
              type="button"
              onClick={handleDownloadTemplate}
              className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal-700 hover:text-teal-900 hover:underline underline-offset-4 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" aria-hidden="true" />
              Download CSV Template
            </button>
          </div>

          <div>
            <label
              htmlFor="import-data-textarea"
              className="block text-xs font-semibold text-slate-700 mb-1.5"
            >
              Paste CSV or JSON Payload
            </label>
            <textarea
              id="import-data-textarea"
              rows={6}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              className="w-full p-3 bg-slate-50 border border-slate-300 rounded-xl font-mono text-xs text-slate-900 focus:bg-white focus:border-indigo-700 focus:outline-none"
            />
          </div>

          {error && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
              {error}
            </div>
          )}

          {successMsg && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-900 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" aria-hidden="true" />
              <span>{successMsg}</span>
            </div>
          )}
        </div>

        <div className="px-6 py-4 bg-slate-50 border-t border-slate-200 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-300 hover:bg-slate-100 rounded-lg cursor-pointer"
          >
            Close
          </button>
          <button
            type="button"
            disabled={isSubmitting || !adminToken}
            onClick={handleSubmit}
            className="px-5 py-2 text-xs font-semibold text-white bg-gradient-to-r from-indigo-700 to-violet-700 hover:from-indigo-800 hover:to-violet-800 disabled:opacity-50 rounded-lg cursor-pointer disabled:cursor-not-allowed"
          >
            {isSubmitting ? 'Importing...' : 'Import & Recalculate Analytics'}
          </button>
        </div>
      </div>
    </div>
  );
}
