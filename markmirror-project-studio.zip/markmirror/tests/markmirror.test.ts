import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';
import os from 'os';
import path from 'path';
import type {AddressInfo} from 'net';
import {createApp} from '../server.ts';
import {ALL_STUDENTS, computeBatchAnalytics} from '../server/dataset.ts';
import {withRetry} from '../server/repository.ts';
import {
  computeMarksheetVerificationHash,
  issueAdminToken,
  verifyAdminPasskey,
  verifyAdminToken,
} from '../server/security.ts';
import {PortalDataService} from '../server/store.ts';
import {
  GRADE_POINTS_MAP,
  SUBJECT_CATALOG,
  computeCGPA,
  computeDifficultyIndex,
  computeSGPA,
  determineLetterGrade,
} from '../src/shared/grading.ts';
import {
  computeDescriptiveStats,
  computeZScore,
  evaluateGaussianBinExpectation,
  forecastTargetGraduationCGPA,
  normalCdfPercentile,
} from '../src/shared/statistics.ts';

test('Official R22 letter grade thresholds enforce internal, external, and total minimums', () => {
  assert.equal(determineLetterGrade(36, 54), 'O'); // 90
  assert.equal(determineLetterGrade(34, 51), 'A+'); // 85
  assert.equal(determineLetterGrade(30, 46), 'A'); // 76
  assert.equal(determineLetterGrade(26, 38), 'B+'); // 64
  assert.equal(determineLetterGrade(22, 30), 'B'); // 52
  assert.equal(determineLetterGrade(18, 25), 'C'); // 43
  assert.equal(determineLetterGrade(13, 45), 'F'); // Internal < 14
  assert.equal(determineLetterGrade(30, 23), 'F'); // External < 24
  assert.equal(determineLetterGrade(15, 24), 'F'); // Total 39 < 40
});

test('Demo student 22CSE104 computes exact SGPA 8.85 with First Class with Distinction', () => {
  const student = ALL_STUDENTS.find((s) => s.hallTicket === '22CSE104');
  assert.ok(student, '22CSE104 must exist in dataset');
  assert.equal(student.totalCredits, 20);
  assert.equal(student.totalWeightedPoints, 177);
  assert.equal(student.sgpa, 8.85);
  assert.equal(student.hasBacklog, false);
  assert.equal(student.classification, 'First Class with Distinction');
});

test('Credit-weighted SGPA and CGPA formulas match manual calculation', () => {
  const sampleSubjects = SUBJECT_CATALOG.map((def, idx) => {
    const grades = ['O', 'A+', 'A', 'B+', 'B', 'C'] as const;
    const grade = grades[idx];
    const gp = GRADE_POINTS_MAP[grade];
    return {
      code: def.code,
      name: def.name,
      shortName: def.shortName,
      credits: def.credits,
      type: def.type,
      internalMarks: 30,
      externalMarks: 40,
      totalMarks: 70,
      grade,
      gradePoints: gp,
      creditPoints: def.credits * gp,
      passed: true,
    };
  });

  const sgpaResult = computeSGPA(sampleSubjects);
  assert.equal(sgpaResult.totalWeightedPoints, 157);
  assert.equal(sgpaResult.sgpa, 7.85);

  const cgpa = computeCGPA(
    [{semester: 'Sem I', sgpa: 8.15, credits: 20, batchAverage: 7.4}],
    7.85,
    20,
  );
  assert.equal(cgpa, 8.0);
});

test('Batch 2022-2026 analytics report Operating Systems at exact 68% lowest pass rate', () => {
  const allBranches = computeBatchAnalytics('2022-2026', 'ALL');
  assert.equal(allBranches.summary.totalStudents, 100);
  assert.equal(allBranches.summary.lowestPassSubject.code, 'CS303');
  assert.equal(allBranches.summary.lowestPassSubject.name, 'Operating Systems');
  assert.equal(allBranches.summary.lowestPassSubject.passRate, 68);

  const cseOnly = computeBatchAnalytics('2022-2026', 'CSE');
  assert.equal(cseOnly.summary.totalStudents, 50);
  assert.equal(cseOnly.summary.lowestPassSubject.code, 'CS303');
  assert.equal(cseOnly.summary.lowestPassSubject.passRate, 68);
});

test('CGPA distribution bins sum to total students, Gaussian curve is valid, and toppers are sorted', () => {
  const analytics = computeBatchAnalytics('2022-2026', 'ALL');
  const binSum = analytics.cgpaDistribution.reduce((acc, b) => acc + b.count, 0);
  assert.equal(binSum, analytics.summary.totalStudents);
  assert.ok(analytics.cgpaStats.stdDev > 0);
  assert.ok(analytics.cgpaDistribution.every((b) => b.gaussianExpected >= 0));

  assert.equal(analytics.toppers.length, 10);
  for (let i = 1; i < analytics.toppers.length; i++) {
    assert.ok(
      analytics.toppers[i - 1].sgpa >= analytics.toppers[i].sgpa,
      'Toppers must be sorted by descending SGPA',
    );
  }
});

test('Subject Difficulty Index stays within bounded 8-98 scale', () => {
  const hard = computeDifficultyIndex(45, 48);
  assert.equal(hard.tier, 'High');
  assert.ok(hard.score >= 45 && hard.score <= 98);

  const easy = computeDifficultyIndex(98, 86);
  assert.equal(easy.tier, 'Low');
  assert.ok(easy.score >= 8 && easy.score < 22);
});

test('Statistical engine computes descriptive moments, Z-score, normal CDF, Gaussian PDF, and graduation forecast', () => {
  const stats = computeDescriptiveStats([6.5, 7.0, 7.5, 8.0, 8.5, 9.0]);
  assert.equal(stats.count, 6);
  assert.equal(stats.mean, 7.75);
  assert.equal(stats.median, 7.75);
  assert.ok(stats.iqr > 0);
  assert.ok(stats.stdDev > 0);

  const z = computeZScore(85, 70, 10);
  assert.equal(z.zScore, 1.5);
  assert.ok(z.percentile > 90 && z.percentile < 95);
  assert.equal(normalCdfPercentile(0), 50);

  const expectedCount = evaluateGaussianBinExpectation(7.5, 1.0, 100, 7.5, 1.0);
  assert.ok(expectedCount > 35 && expectedCount < 45);

  const achievable = forecastTargetGraduationCGPA(8.5, 100, 60, 8.75);
  assert.equal(achievable.feasible, true);
  assert.equal(achievable.requiredSgpa, 9.17);
  assert.equal(achievable.status, 'stretch');

  const infeasible = forecastTargetGraduationCGPA(6.0, 120, 40, 9.0);
  assert.equal(infeasible.feasible, false);
  assert.equal(infeasible.status, 'infeasible');
});

test('Security utilities verify admin passkey, HMAC tokens, and transcript verification digests', () => {
  assert.equal(verifyAdminPasskey('NIET-ADMIN-2026'), true);
  assert.equal(verifyAdminPasskey('WRONG-KEY'), false);

  const {token} = issueAdminToken('Test Controller');
  const verified = verifyAdminToken(`Bearer ${token}`);
  assert.ok(verified);
  assert.equal(verified.sub, 'Test Controller');

  const tamperedToken = `${token.slice(0, -4)}AAAA`;
  assert.equal(verifyAdminToken(`Bearer ${tamperedToken}`), null);

  const student = ALL_STUDENTS.find((s) => s.hallTicket === '22CSE104')!;
  const hash1 = computeMarksheetVerificationHash(student);
  const hash2 = computeMarksheetVerificationHash(student);
  assert.equal(hash1, hash2);
  assert.match(hash1, /^[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}-[A-F0-9]{4}$/);

  const alteredStudent = {...student, sgpa: 9.99};
  assert.notEqual(computeMarksheetVerificationHash(alteredStudent), hash1);
});

test('withRetry recovers from transient failures before succeeding', () => {
  let attempts = 0;
  const result = withRetry(() => {
    attempts += 1;
    if (attempts < 3) {
      throw new Error('Transient SQLITE_BUSY simulation');
    }
    return 'recovered';
  }, 3, 2);
  assert.equal(result, 'recovered');
  assert.equal(attempts, 3);
});

test('PortalDataService SQLite WAL repository + live Express HTTP integration suite', async (t) => {
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'markmirror-test-'));
  const service = new PortalDataService(tempDir);
  const app = await createApp(service);
  const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
    const s = app.listen(0, '127.0.0.1', () => resolve(s));
  });

  t.after(async () => {
    await new Promise<void>((resolve) => server.close(() => resolve()));
    service.close();
    fs.rmSync(tempDir, {recursive: true, force: true});
  });

  const {port} = server.address() as AddressInfo;
  const baseUrl = `http://127.0.0.1:${port}`;

  // 1. Health & SQLite engine verification
  const healthRes = await fetch(`${baseUrl}/api/health`);
  assert.equal(healthRes.status, 200);
  assert.equal(healthRes.headers.get('x-content-type-options'), 'nosniff');
  const healthJson = (await healthRes.json()) as {
    status: string;
    storageEngine: string;
    totalRecords: number;
  };
  assert.equal(healthJson.status, 'ok');
  assert.equal(healthJson.storageEngine, 'sqlite-wal');
  assert.equal(healthJson.totalRecords, 180);

  // 2. Result Lookup + Z-scores + Verification Digest
  const lookupRes = await fetch(`${baseUrl}/api/results/22CSE104`);
  assert.equal(lookupRes.status, 200);
  const lookupJson = (await lookupRes.json()) as {
    student: {sgpa: number; hallTicket: string};
    verificationHash: string;
    subjectAverages: Array<{code: string; zScore: number; percentile: number}>;
  };
  assert.equal(lookupJson.student.sgpa, 8.85);
  assert.equal(lookupJson.subjectAverages.length, 6);
  assert.ok(typeof lookupJson.subjectAverages[0].zScore === 'number');

  // 3. Cryptographic Transcript Verification (valid vs tampered hash)
  const validVerifyRes = await fetch(
    `${baseUrl}/api/verify/22CSE104?hash=${encodeURIComponent(lookupJson.verificationHash)}`,
  );
  const validVerify = (await validVerifyRes.json()) as {verified: boolean};
  assert.equal(validVerify.verified, true);

  const invalidVerifyRes = await fetch(`${baseUrl}/api/verify/22CSE104?hash=0000-0000-0000-0000`);
  const invalidVerify = (await invalidVerifyRes.json()) as {verified: boolean};
  assert.equal(invalidVerify.verified, false);

  // 4. Import authorization enforcement (401 without Bearer token)
  const unauthImport = await fetch(`${baseUrl}/api/students/import`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      records: [
        {
          hallTicket: '22CSE999',
          name: 'Unauthorized Test',
          branch: 'CSE',
          batch: '2022-2026',
          marks: [],
        },
      ],
    }),
  });
  assert.equal(unauthImport.status, 401);

  // 5. Authenticate via /api/admin/auth and perform authenticated ACID import
  const authRes = await fetch(`${baseUrl}/api/admin/auth`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({passkey: 'NIET-ADMIN-2026', actor: 'Integration Test Runner'}),
  });
  assert.equal(authRes.status, 200);
  const {token} = (await authRes.json()) as {token: string};
  assert.ok(token);

  const importRes = await fetch(`${baseUrl}/api/students/import`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    },
    body: JSON.stringify({
      records: [
        {
          hallTicket: '22CSE999',
          name: 'Aarav Integration',
          branch: 'CSE',
          batch: '2022-2026',
          marks: [
            {code: 'MA301', internal: 36, external: 54},
            {code: 'CS302', internal: 34, external: 50},
            {code: 'CS303', internal: 32, external: 48},
            {code: 'CS304', internal: 33, external: 49},
            {code: 'CS305', internal: 31, external: 47},
            {code: 'CS306L', internal: 38, external: 56},
          ],
        },
      ],
    }),
  });
  assert.equal(importRes.status, 200);
  const importSummary = (await importRes.json()) as {
    importedCount: number;
    totalRecords: number;
  };
  assert.equal(importSummary.importedCount, 1);
  assert.equal(importSummary.totalRecords, 181);

  // 6. Verify Audit Log recorded the import & CSV export reflects new record
  const auditRes = await fetch(`${baseUrl}/api/admin/audit`, {
    headers: {Authorization: `Bearer ${token}`},
  });
  assert.equal(auditRes.status, 200);
  const auditJson = (await auditRes.json()) as {logs: Array<{actor: string; action: string}>};
  assert.ok(auditJson.logs.some((log) => log.actor === 'Integration Test Runner'));

  const csvRes = await fetch(`${baseUrl}/api/analytics/export.csv?batch=2022-2026&branch=CSE`);
  assert.equal(csvRes.status, 200);
  const csvText = await csvRes.text();
  assert.ok(csvText.includes('22CSE999'));

  // 7. Revaluation submission persists to SQLite and reloads cleanly
  const revalRes = await fetch(`${baseUrl}/api/revaluation/submit`, {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      hallTicket: '22CSE118',
      subjectCodes: ['CS303'],
    }),
  });
  assert.equal(revalRes.status, 201);
  const revalJson = (await revalRes.json()) as {application: {totalFee: number; challanId: string}};
  assert.equal(revalJson.application.totalFee, 700);
  assert.match(revalJson.application.challanId, /^MM-REV-/);

  const fetchRevalRes = await fetch(`${baseUrl}/api/revaluation/22CSE118`);
  assert.equal(fetchRevalRes.status, 200);
  const fetchRevalJson = (await fetchRevalRes.json()) as {
    applications: Array<{challanId: string; totalFee: number}>;
  };
  assert.ok(fetchRevalJson.applications.some((a) => a.challanId === revalJson.application.challanId));
});
