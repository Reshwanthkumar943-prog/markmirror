import test from 'node:test';
import assert from 'node:assert/strict';
import {ALL_STUDENTS, computeBatchAnalytics} from '../server/dataset.ts';
import {
  exportBatchCsv,
  getAllStudents,
  getCachedAnalytics,
  getRevaluationsForStudent,
  initStore,
  saveRevaluationApplication,
} from '../server/store.ts';
import {
  GRADE_POINTS_MAP,
  SUBJECT_CATALOG,
  computeCGPA,
  computeDifficultyIndex,
  computeSGPA,
  determineLetterGrade,
} from '../src/shared/grading.ts';

test('Official R22 letter grade thresholds enforce internal, external, and total minimums', () => {
  assert.equal(determineLetterGrade(36, 54), 'O'); // 90
  assert.equal(determineLetterGrade(34, 51), 'A+'); // 85
  assert.equal(determineLetterGrade(30, 46), 'A'); // 76
  assert.equal(determineLetterGrade(26, 38), 'B+'); // 64
  assert.equal(determineLetterGrade(22, 30), 'B'); // 52
  assert.equal(determineLetterGrade(18, 25), 'C'); // 43
  assert.equal(determineLetterGrade(13, 45), 'F'); // Internal < 14
  assert.equal(determineLetterGrade(30, 23), 'F'); // External < 24
  assert.equal(determineLetterGrade(15, 24), 'F'); // Total 39 < 40
});

test('Demo student 22CSE104 computes exact SGPA 8.85 with First Class with Distinction', () => {
  const student = ALL_STUDENTS.find((s) => s.hallTicket === '22CSE104');
  assert.ok(student, '22CSE104 must exist in dataset');
  assert.equal(student.totalCredits, 20);
  assert.equal(student.totalWeightedPoints, 177);
  assert.equal(student.sgpa, 8.85);
  assert.equal(student.hasBacklog, false);
  assert.equal(student.classification, 'First Class with Distinction');
});

test('Credit-weighted SGPA and CGPA formulas match manual calculation', () => {
  const sampleSubjects = SUBJECT_CATALOG.map((def, idx) => {
    const grades = ['O', 'A+', 'A', 'B+', 'B', 'C'] as const;
    const grade = grades[idx];
    const gp = GRADE_POINTS_MAP[grade];
    return {
      code: def.code,
      name: def.name,
      shortName: def.shortName,
      credits: def.credits,
      type: def.type,
      internalMarks: 30,
      externalMarks: 40,
      totalMarks: 70,
      grade,
      gradePoints: gp,
      creditPoints: def.credits * gp,
      passed: true,
    };
  });

  const sgpaResult = computeSGPA(sampleSubjects);
  assert.equal(sgpaResult.totalWeightedPoints, 157);
  assert.equal(sgpaResult.sgpa, 7.85);

  const cgpa = computeCGPA(
    [{semester: 'Sem I', sgpa: 8.15, credits: 20, batchAverage: 7.4}],
    7.85,
    20,
  );
  assert.equal(cgpa, 8.0);
});

test('Batch 2022-2026 analytics report Operating Systems at exact 68% lowest pass rate', () => {
  const allBranches = computeBatchAnalytics('2022-2026', 'ALL');
  assert.equal(allBranches.summary.totalStudents, 100);
  assert.equal(allBranches.summary.lowestPassSubject.code, 'CS303');
  assert.equal(allBranches.summary.lowestPassSubject.name, 'Operating Systems');
  assert.equal(allBranches.summary.lowestPassSubject.passRate, 68);

  const cseOnly = computeBatchAnalytics('2022-2026', 'CSE');
  assert.equal(cseOnly.summary.totalStudents, 50);
  assert.equal(cseOnly.summary.lowestPassSubject.code, 'CS303');
  assert.equal(cseOnly.summary.lowestPassSubject.passRate, 68);
});

test('CGPA distribution bins sum to total students and toppers are sorted descending', () => {
  const analytics = computeBatchAnalytics('2022-2026', 'ALL');
  const binSum = analytics.cgpaDistribution.reduce((acc, b) => acc + b.count, 0);
  assert.equal(binSum, analytics.summary.totalStudents);

  assert.equal(analytics.toppers.length, 10);
  for (let i = 1; i < analytics.toppers.length; i++) {
    assert.ok(
      analytics.toppers[i - 1].sgpa >= analytics.toppers[i].sgpa,
      'Toppers must be sorted by descending SGPA',
    );
  }
});

test('Subject Difficulty Index stays within bounded 8-98 scale', () => {
  const hard = computeDifficultyIndex(45, 48);
  assert.equal(hard.tier, 'High');
  assert.ok(hard.score >= 45 && hard.score <= 98);

  const easy = computeDifficultyIndex(98, 86);
  assert.equal(easy.tier, 'Low');
  assert.ok(easy.score >= 8 && easy.score < 22);
});

test('Persistent store initializes 180 records, exports CSV, and caches analytics cleanly', () => {
  initStore();
  assert.ok(getAllStudents().length >= 180);

  const cached = getCachedAnalytics('2022-2026', 'CSE');
  assert.equal(cached.summary.lowestPassSubject.passRate, 68);

  const csv = exportBatchCsv('2022-2026', 'CSE');
  const lines = csv.trim().split('\n');
  assert.ok(lines.length >= 51);
  assert.ok(lines[0].startsWith('HallTicket,Name,Branch,Batch'));

  // Verify re-evaluation query returns an array
  const existing = getRevaluationsForStudent('22CSE104');
  assert.ok(Array.isArray(existing));
  assert.equal(typeof saveRevaluationApplication, 'function');
});
