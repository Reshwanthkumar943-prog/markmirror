# MarkMirror — Exam Result Portal & Batch Analytics

University examination result portal and cohort analytics dashboard built with Express, React, TypeScript, Tailwind CSS, and Chart.js.

## Prerequisites

- **Node.js** v20.18+ or v22+ (recommended)
- **npm** (bundled with Node.js)
- **VS Code**

## Running in VS Code

1. Extract `markmirror-project.zip` into a folder on your computer.
2. Open the extracted folder in **VS Code** (`File -> Open Folder...`).
3. Open the VS Code integrated terminal (`Ctrl + \`` or `Terminal -> New Terminal`).
4. Install dependencies:
   ```bash
   npm install
   ```
5. Start the development server (runs Express API + Vite frontend on port 3000):
   ```bash
   npm run dev
   ```
6. Open your browser to:
   ```
   http://localhost:3000
   ```

## Automated Verification & Tests

```bash
npm test     # Runs grading, SGPA/CGPA, pass-rate, and binning unit tests
npm run lint # TypeScript strict type-check
npm run build
```

## Persistence & Admin Import/Export

- Student records and re-evaluation challan submissions are persisted in `data/students.json` and `data/revaluations.json`.
- Use **Import Records** in **Batch Analytics** to upload CSV/JSON student sheets and recalculate cohort analytics live, or **Export CSV** to download cohort reports.

## Demo Hall Tickets

- `22CSE104` — SGPA **8.85** (`First Class with Distinction`)
- `22CSE101` — SGPA **10.00** (Branch Rank #1)
- `22CSE118` — Operating Systems backlog (Re-Evaluation Fee Estimator demo)
- `22ECE105` / `22IT103` — ECE & IT sample records
