import 'dotenv/config';
import express from 'express';
import fs from 'fs';
import JSZip from 'jszip';
import path from 'path';
import {fileURLToPath} from 'url';
import {
  exportBatchCsv,
  getAllStudents,
  getCachedAnalytics,
  getRevaluationsForStudent,
  initStore,
  saveRevaluationApplication,
  upsertStudents,
} from './server/store.ts';
import type {ImportStudentInput} from './server/store.ts';
import type {BatchId, BranchCode} from './src/shared/grading.ts';
import {
  REVALUATION_FEE_PER_LAB,
  REVALUATION_FEE_PER_THEORY,
  REVALUATION_PROCESSING_FEE,
  SUBJECT_CATALOG,
} from './src/shared/grading.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = Number(process.env.PORT || 3000);
const isProduction = process.env.NODE_ENV === 'production';

const VALID_BATCHES: BatchId[] = ['2022-2026', '2021-2025', '2020-2024'];
const VALID_BRANCHES: Array<BranchCode | 'ALL'> = ['ALL', 'CSE', 'ECE', 'IT'];

// Initialize persistent file-backed JSON store and pre-computed analytics cache
initStore();

async function startServer() {
  const app = express();
  app.use(express.json({limit: '2mb'}));

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({status: 'ok', totalRecords: getAllStudents().length});
  });

  // Hall Ticket Result Lookup
  app.get('/api/results/:hallTicket', (req, res) => {
    const queryTicket = req.params.hallTicket.trim().toUpperCase();
    const allStudents = getAllStudents();
    const student = allStudents.find((s) => s.hallTicket.toUpperCase() === queryTicket);

    if (!student) {
      res.status(404).json({
        error: 'Hall ticket record not found',
        hallTicket: queryTicket,
        suggestions: ['22CSE104', '22CSE101', '22CSE118', '22ECE105', '22IT103'],
      });
      return;
    }

    const branchPeers = allStudents
      .filter((s) => s.batch === student.batch && s.branch === student.branch)
      .sort((a, b) => {
        if (a.hasBacklog !== b.hasBacklog) return a.hasBacklog ? 1 : -1;
        if (b.sgpa !== a.sgpa) return b.sgpa - a.sgpa;
        return b.totalMarks - a.totalMarks;
      });

    const branchRank = branchPeers.findIndex((s) => s.hallTicket === student.hallTicket) + 1;
    const branchPercentile =
      branchPeers.length > 1
        ? Number((((branchPeers.length - branchRank) / (branchPeers.length - 1)) * 100).toFixed(1))
        : 100;

    const branchAnalytics = getCachedAnalytics(student.batch, student.branch);
    const subjectAverages = branchAnalytics.subjectAnalytics.map((sa) => ({
      code: sa.code,
      avgMarks: sa.avgMarks,
      passRate: sa.passRate,
    }));

    res.json({
      student,
      standing: {
        branchRank,
        branchTotal: branchPeers.length,
        branchPercentile,
      },
      subjectAverages,
    });
  });

  // Student directory search / autocomplete
  app.get('/api/students', (req, res) => {
    const q = String(req.query.q || '').trim().toLowerCase();
    const branch = String(req.query.branch || 'ALL').toUpperCase();
    const batch = String(req.query.batch || '2022-2026');
    const limit = Math.min(50, Math.max(1, Number(req.query.limit || 12)));

    const filtered = getAllStudents()
      .filter((s) => {
        if (batch !== 'ALL' && s.batch !== batch) return false;
        if (branch !== 'ALL' && s.branch !== branch) return false;
        if (!q) return true;
        return (
          s.hallTicket.toLowerCase().includes(q) ||
          s.name.toLowerCase().includes(q)
        );
      })
      .slice(0, limit);

    res.json({
      students: filtered.map((s) => ({
        hallTicket: s.hallTicket,
        name: s.name,
        branch: s.branch,
        batch: s.batch,
        sgpa: s.sgpa,
        cgpa: s.cgpa,
        hasBacklog: s.hasBacklog,
        classification: s.classification,
      })),
    });
  });

  // Batch CSV / JSON Student Record Importer
  app.post('/api/students/import', (req, res) => {
    const rawRows: unknown = req.body?.records;
    if (!Array.isArray(rawRows) || rawRows.length === 0) {
      res.status(400).json({error: 'Provide a non-empty array of student records to import.'});
      return;
    }

    const validInputs: ImportStudentInput[] = [];
    for (const item of rawRows) {
      if (!item || typeof item !== 'object') continue;
      const obj = item as Record<string, unknown>;
      const hallTicket = typeof obj.hallTicket === 'string' ? obj.hallTicket.trim() : '';
      const name = typeof obj.name === 'string' ? obj.name.trim() : '';
      const branchRaw = typeof obj.branch === 'string' ? obj.branch.trim().toUpperCase() : 'CSE';
      const batchRaw = typeof obj.batch === 'string' ? obj.batch.trim() : '2022-2026';

      if (!hallTicket || !name) continue;
      const branch: BranchCode =
        branchRaw === 'ECE' || branchRaw === 'IT' ? branchRaw : 'CSE';
      const batch: BatchId =
        batchRaw === '2021-2025' || batchRaw === '2020-2024' ? batchRaw : '2022-2026';

      const rawMarks = Array.isArray(obj.marks) ? obj.marks : [];
      const marks = rawMarks
        .filter((m): m is Record<string, unknown> => Boolean(m && typeof m === 'object'))
        .map((m) => ({
          code: String(m.code || ''),
          internal: Number(m.internal ?? 0),
          external: Number(m.external ?? 0),
        }));

      validInputs.push({
        hallTicket,
        name,
        fatherName: typeof obj.fatherName === 'string' ? obj.fatherName : undefined,
        branch,
        batch,
        marks,
      });
    }

    if (validInputs.length === 0) {
      res.status(400).json({error: 'No valid student records found. Each record requires hallTicket and name.'});
      return;
    }

    const summary = upsertStudents(validInputs);
    res.json({
      ...summary,
      totalRecords: getAllStudents().length,
    });
  });

  // Pre-computed Batch Analytics
  app.get('/api/analytics', (req, res) => {
    const rawBatch = String(req.query.batch || '2022-2026') as BatchId;
    const rawBranch = String(req.query.branch || 'ALL').toUpperCase() as BranchCode | 'ALL';

    const batch: BatchId = VALID_BATCHES.includes(rawBatch) ? rawBatch : '2022-2026';
    const branch: BranchCode | 'ALL' = VALID_BRANCHES.includes(rawBranch) ? rawBranch : 'ALL';

    res.json(getCachedAnalytics(batch, branch));
  });

  // Export Cohort CSV Report
  app.get('/api/analytics/export.csv', (req, res) => {
    const rawBatch = String(req.query.batch || '2022-2026') as BatchId;
    const rawBranch = String(req.query.branch || 'ALL').toUpperCase() as BranchCode | 'ALL';
    const batch: BatchId = VALID_BATCHES.includes(rawBatch) ? rawBatch : '2022-2026';
    const branch: BranchCode | 'ALL' = VALID_BRANCHES.includes(rawBranch) ? rawBranch : 'ALL';

    const csv = exportBatchCsv(batch, branch);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="markmirror_${batch}_${branch}.csv"`,
    );
    res.send(csv);
  });

  // Re-evaluation fee calculator & persisted submission endpoints
  app.post('/api/revaluation/estimate', (req, res) => {
    const codes: unknown = req.body?.subjectCodes;
    const selectedCodes = Array.isArray(codes)
      ? codes.filter((c): c is string => typeof c === 'string')
      : [];

    const matchedSubjects = SUBJECT_CATALOG.filter((s) => selectedCodes.includes(s.code));
    const items = matchedSubjects.map((s) => ({
      code: s.code,
      name: s.name,
      type: s.type,
      fee: s.type === 'Lab' ? REVALUATION_FEE_PER_LAB : REVALUATION_FEE_PER_THEORY,
    }));

    const paperSubtotal = items.reduce((acc, item) => acc + item.fee, 0);
    const processingFee = items.length > 0 ? REVALUATION_PROCESSING_FEE : 0;
    const totalFee = paperSubtotal + processingFee;

    res.json({
      items,
      paperSubtotal,
      processingFee,
      totalFee,
      currency: 'INR',
    });
  });

  app.get('/api/revaluation/:hallTicket', (req, res) => {
    const applications = getRevaluationsForStudent(req.params.hallTicket);
    res.json({applications});
  });

  app.post('/api/revaluation/submit', (req, res) => {
    const hallTicket = String(req.body?.hallTicket || '').trim().toUpperCase();
    const codes: unknown = req.body?.subjectCodes;
    const selectedCodes = Array.isArray(codes)
      ? codes.filter((c): c is string => typeof c === 'string')
      : [];

    const student = getAllStudents().find(
      (s) => s.hallTicket.toUpperCase() === hallTicket,
    );
    if (!student) {
      res.status(404).json({error: 'Student record not found'});
      return;
    }

    const matchedSubjects = SUBJECT_CATALOG.filter((s) => selectedCodes.includes(s.code));
    if (matchedSubjects.length === 0) {
      res.status(400).json({error: 'Select at least one subject for re-evaluation'});
      return;
    }

    const paperSubtotal = matchedSubjects.reduce(
      (acc, s) => acc + (s.type === 'Lab' ? REVALUATION_FEE_PER_LAB : REVALUATION_FEE_PER_THEORY),
      0,
    );
    const processingFee = REVALUATION_PROCESSING_FEE;
    const totalFee = paperSubtotal + processingFee;

    const application = saveRevaluationApplication({
      hallTicket: student.hallTicket,
      studentName: student.name,
      subjectCodes: matchedSubjects.map((s) => s.code),
      paperSubtotal,
      processingFee,
      totalFee,
      currency: 'INR',
    });

    res.status(201).json({application});
  });

  const EXCLUDED_DIRS = new Set(['node_modules', 'dist', '.git', 'workspace', '.aistudio', 'data']);
  const EXCLUDED_FILES = new Set(['bun.lock', 'markmirror-project.zip']);

  async function buildProjectZipBuffer(): Promise<Buffer> {
    const zip = new JSZip();
    const rootFolder = zip.folder('markmirror');

    function walkDir(dirPath: string) {
      const entries = fs.readdirSync(dirPath, {withFileTypes: true});
      for (const entry of entries) {
        if (entry.isDirectory()) {
          if (EXCLUDED_DIRS.has(entry.name)) continue;
          walkDir(path.join(dirPath, entry.name));
        } else if (entry.isFile()) {
          if (EXCLUDED_FILES.has(entry.name) || entry.name.endsWith('.zip')) continue;
          const fullPath = path.join(dirPath, entry.name);
          const relPath = path.relative(__dirname, fullPath).split(path.sep).join('/');
          if (relPath.startsWith('public/assets/aistudio')) continue;
          rootFolder?.file(relPath, fs.readFileSync(fullPath));
        }
      }
    }

    walkDir(__dirname);
    return zip.generateAsync({type: 'nodebuffer', compression: 'DEFLATE'});
  }

  // Direct project zip download (always works even if public/ archive was cleared)
  app.get('/markmirror-project.zip', async (_req, res) => {
    try {
      const zipPath = path.resolve(__dirname, 'public', 'markmirror-project.zip');
      let zipBuffer: Buffer;
      if (fs.existsSync(zipPath)) {
        zipBuffer = fs.readFileSync(zipPath);
      } else {
        zipBuffer = await buildProjectZipBuffer();
        fs.mkdirSync(path.dirname(zipPath), {recursive: true});
        fs.writeFileSync(zipPath, zipBuffer);
      }
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', 'attachment; filename="markmirror-project.zip"');
      res.send(zipBuffer);
    } catch {
      res.status(500).json({error: 'Unable to generate project archive'});
    }
  });

  // Clean HTML download page with direct zip link
  app.get('/download.html', (_req, res) => {
    res.setHeader('Content-Type', 'text/html; charset=utf-8');
    res.send(`<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Download MarkMirror Project (.zip)</title>
    <style>
      body { font-family: system-ui, -apple-system, sans-serif; background: #f8fafc; color: #0f172a; display: grid; place-items: center; min-height: 100vh; margin: 0; padding: 24px; }
      .card { background: #fff; border: 1px solid #e2e8f0; border-radius: 16px; padding: 32px; max-width: 520px; width: 100%; }
      h1 { margin: 0 0 8px; font-size: 24px; }
      p { color: #475569; line-height: 1.5; margin: 0 0 20px; }
      .actions { display: flex; flex-wrap: wrap; gap: 12px; }
      a.btn { display: inline-block; padding: 12px 20px; border-radius: 10px; font-weight: 600; font-size: 14px; text-decoration: none; }
      a.primary { background: #4338ca; color: #fff; }
      a.secondary { background: #f1f5f9; color: #0f172a; }
    </style>
  </head>
  <body>
    <main class="card">
      <h1>MarkMirror Source Archive</h1>
      <p>Download the complete MarkMirror project (.zip including index.html, Express backend, React frontend, and tests) or open the live web portal.</p>
      <div class="actions">
        <a class="btn primary" href="/markmirror-project.zip" download="markmirror-project.zip">Download markmirror-project.zip</a>
        <a class="btn secondary" href="/">Open Live Portal</a>
      </div>
    </main>
  </body>
</html>`);
  });

  if (!isProduction) {
    const {createServer: createViteServer} = await import('vite');
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    if (fs.existsSync(distPath)) {
      app.use(express.static(distPath));
      app.get('*', (_req, res) => {
        res.sendFile(path.join(distPath, 'index.html'));
      });
    }
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`MarkMirror server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start MarkMirror server:', err);
  process.exit(1);
});
