import {Printer, Sparkles, Search} from 'lucide-react';
import type {ActiveTab} from '../types/portal.ts';

interface TopBarProps {
  activeTab: ActiveTab;
  onSelectTab: (tab: ActiveTab) => void;
  hasActiveStudent: boolean;
  onPrintMarksheet: () => void;
  onQuickDemoLookup: () => void;
}

const NAV_ITEMS: Array<{id: ActiveTab; label: string; accentClass: string}> = [
  {id: 'lookup', label: 'Result Lookup', accentClass: 'bg-gradient-to-r from-indigo-600 to-violet-600'},
  {id: 'analytics', label: 'Batch Analytics', accentClass: 'bg-gradient-to-r from-teal-600 to-emerald-500'},
  {id: 'toppers', label: 'Toppers', accentClass: 'bg-gradient-to-r from-amber-500 to-rose-500'},
  {id: 'grading', label: 'Grading Scale', accentClass: 'bg-gradient-to-r from-violet-600 to-fuchsia-600'},
];

export function TopBar({
  activeTab,
  onSelectTab,
  hasActiveStudent,
  onPrintMarksheet,
  onQuickDemoLookup,
}: TopBarProps) {
  return (
    <header className="no-print sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-indigo-100">
      <div className="h-1 w-full bg-gradient-to-r from-indigo-600 via-violet-500 via-50% to-teal-500" aria-hidden="true" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-element Brand Wordmark */}
        <button
          type="button"
          onClick={() => onSelectTab('lookup')}
          className="text-xl font-serif font-bold tracking-tight bg-gradient-to-r from-indigo-700 via-violet-700 to-teal-600 bg-clip-text text-transparent whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 rounded-sm"
        >
          MarkMirror
        </button>

        {/* Zone 2: Clean single-line navigation links */}
        <nav
          aria-label="Primary portal navigation"
          className="hidden md:flex items-center gap-7 text-sm font-medium"
        >
          {NAV_ITEMS.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`relative py-5 whitespace-nowrap shrink-0 transition-colors duration-150 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 ${
                  isActive
                    ? 'text-indigo-950 font-semibold'
                    : 'text-slate-600 hover:text-indigo-700'
                }`}
              >
                {item.label}
                {isActive && (
                  <span
                    aria-hidden="true"
                    className={`absolute inset-x-0 bottom-0 h-0.5 ${item.accentClass}`}
                  />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Single Primary Action */}
        <div className="flex items-center shrink-0">
          {activeTab === 'lookup' && hasActiveStudent ? (
            <button
              type="button"
              onClick={onPrintMarksheet}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-indigo-700 to-violet-700 hover:from-indigo-800 hover:to-violet-800 rounded-lg shadow-sm transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
            >
              <Printer className="w-4 h-4" aria-hidden="true" />
              Print Marksheet
            </button>
          ) : (
            <button
              type="button"
              onClick={onQuickDemoLookup}
              className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-700 hover:to-indigo-700 rounded-lg shadow-sm transition-all duration-150 whitespace-nowrap shrink-0 cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-indigo-600 focus-visible:ring-offset-2"
            >
              {activeTab === 'lookup' ? (
                <Sparkles className="w-4 h-4" aria-hidden="true" />
              ) : (
                <Search className="w-4 h-4" aria-hidden="true" />
              )}
              Lookup 22CSE104
            </button>
          )}
        </div>
      </div>

      {/* Mobile Compact Nav Row */}
      <nav
        aria-label="Mobile portal navigation"
        className="md:hidden border-t border-indigo-100 px-4 flex items-center gap-5 overflow-x-auto text-xs font-medium"
      >
        {NAV_ITEMS.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => onSelectTab(item.id)}
              className={`py-2.5 whitespace-nowrap shrink-0 border-b-2 transition-colors ${
                isActive
                  ? 'border-indigo-700 text-indigo-900 font-semibold'
                  : 'border-transparent text-slate-600'
              }`}
            >
              {item.label}
            </button>
          );
        })}
      </nav>
    </header>
  );
}
