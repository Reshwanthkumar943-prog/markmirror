import {Award, Crown, ExternalLink, Trophy} from 'lucide-react';
import type {BatchId, BranchCode} from '../shared/grading.ts';
import type {BatchAnalyticsResponse} from '../types/portal.ts';

interface TopperLeaderboardProps {
  analytics: BatchAnalyticsResponse | null;
  isLoading: boolean;
  batch: BatchId;
  branch: BranchCode | 'ALL';
  onBatchChange: (batch: BatchId) => void;
  onBranchChange: (branch: BranchCode | 'ALL') => void;
  onInspectStudent: (hallTicket: string) => void;
}

const BATCH_OPTIONS: BatchId[] = ['2022-2026', '2021-2025', '2020-2024'];
const BRANCH_OPTIONS: Array<{value: BranchCode | 'ALL'; label: string}> = [
  {value: 'ALL', label: 'All Branches'},
  {value: 'CSE', label: 'CSE'},
  {value: 'ECE', label: 'ECE'},
  {value: 'IT', label: 'IT'},
];

export function TopperLeaderboard({
  analytics,
  isLoading,
  batch,
  branch,
  onBatchChange,
  onBranchChange,
  onInspectStudent,
}: TopperLeaderboardProps) {
  const toppers = analytics?.toppers ?? [];
  const podium = toppers.slice(0, 3);
  const runnersUp = toppers.slice(3, 5);

  return (
    <div>
      {/* Vibrant Honors Banner */}
      <section className="relative overflow-hidden bg-gradient-to-r from-amber-600 via-rose-600 to-violet-800 text-white border-b border-rose-800">
        <div className="absolute inset-0 bg-radar-grid opacity-40 pointer-events-none" aria-hidden="true" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 flex flex-col lg:flex-row lg:items-end justify-between gap-6">
          <div>
            <p className="text-xs font-semibold text-amber-200 mb-1.5">
              Academic Merit Roll · Top 10 Rank Holders
            </p>
            <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
              Department Topper Leaderboard
            </h1>
            <p className="mt-1.5 text-sm text-amber-50/90 max-w-2xl">
              Celebrating top Semester V SGPA, cumulative CGPA, and aggregate credit achievers across engineering branches.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-1 p-1 bg-black/20 backdrop-blur-md border border-white/20 rounded-lg">
              {BATCH_OPTIONS.map((b) => (
                <button
                  key={b}
                  type="button"
                  onClick={() => onBatchChange(b)}
                  className={`px-3 py-1.5 text-xs font-mono font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    batch === b
                      ? 'bg-amber-300 text-slate-950 font-bold'
                      : 'text-white/90 hover:text-white'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-1 p-1 bg-black/20 backdrop-blur-md border border-white/20 rounded-lg">
              {BRANCH_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => onBranchChange(opt.value)}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors whitespace-nowrap cursor-pointer ${
                    branch === opt.value
                      ? 'bg-white text-rose-900 font-bold'
                      : 'text-white/90 hover:text-white'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {isLoading || !analytics ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-52 bg-white border border-slate-200 rounded-2xl animate-pulse" />
            ))}
          </div>
        ) : (
          <>
            {/* Creative Celebratory Podium (Top 3) + Ranks 4 & 5 */}
            <section aria-label="Top 5 Department Achievers" className="space-y-5">
              <h2 className="text-sm font-bold text-slate-700">
                Top 5 Honors Podium — {branch === 'ALL' ? 'All Engineering Branches' : `${branch} Department`} ({batch})
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-stretch">
                {podium.map((student) => {
                  const isFirst = student.rank === 1;
                  const isSecond = student.rank === 2;

                  const cardTheme = isFirst
                    ? 'bg-gradient-to-br from-amber-50 via-yellow-50 to-orange-50 border-amber-300'
                    : isSecond
                      ? 'bg-gradient-to-br from-indigo-50 via-slate-50 to-violet-50 border-indigo-200'
                      : 'bg-gradient-to-br from-teal-50 via-emerald-50/70 to-cyan-50 border-teal-200';

                  const iconTile = isFirst
                    ? 'bg-amber-400 text-slate-950'
                    : isSecond
                      ? 'bg-indigo-600 text-white'
                      : 'bg-teal-600 text-white';

                  const accentText = isFirst
                    ? 'text-amber-900'
                    : isSecond
                      ? 'text-indigo-800'
                      : 'text-teal-800';

                  return (
                    <button
                      key={student.hallTicket}
                      type="button"
                      onClick={() => onInspectStudent(student.hallTicket)}
                      className={`text-left border rounded-2xl p-6 transition-transform duration-150 hover:-translate-y-0.5 cursor-pointer flex flex-col justify-between shadow-sm ${cardTheme}`}
                    >
                      <div>
                        <div className="flex items-center justify-between gap-2 mb-4">
                          <div className="flex items-center gap-2.5">
                            <span
                              className={`w-9 h-9 rounded-xl flex items-center justify-center ${iconTile}`}
                            >
                              {isFirst ? (
                                <Crown className="w-5 h-5" aria-hidden="true" />
                              ) : isSecond ? (
                                <Trophy className="w-4 h-4" aria-hidden="true" />
                              ) : (
                                <Award className="w-4 h-4" aria-hidden="true" />
                              )}
                            </span>
                            <span className={`font-mono text-xs font-bold ${accentText}`}>
                              Rank #{String(student.rank).padStart(2, '0')} ·{' '}
                              {isFirst ? 'Gold' : isSecond ? 'Silver' : 'Bronze'}
                            </span>
                          </div>
                          <span className="text-xs font-mono font-semibold text-slate-600">
                            {student.branch}
                          </span>
                        </div>

                        <div className="text-xl font-serif font-bold text-slate-900">
                          {student.name}
                        </div>
                        <div className={`text-xs font-mono font-semibold mt-1 ${accentText}`}>
                          {student.hallTicket} · {student.totalMarks}/600 ({student.percentage.toFixed(1)}%)
                        </div>
                      </div>

                      <div className="mt-6 pt-4 border-t border-slate-900/10 flex items-baseline justify-between gap-4">
                        <div>
                          <div className="text-xs text-slate-600">Semester SGPA</div>
                          <div className={`text-3xl font-mono font-bold tabular-nums ${accentText}`}>
                            {student.sgpa.toFixed(2)}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-slate-600">Cumulative CGPA</div>
                          <div className="text-lg font-mono font-bold tabular-nums text-slate-900">
                            {student.cgpa.toFixed(2)}
                          </div>
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>

              {/* Ranks 4 & 5 */}
              {runnersUp.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {runnersUp.map((student) => (
                    <button
                      key={student.hallTicket}
                      type="button"
                      onClick={() => onInspectStudent(student.hallTicket)}
                      className="text-left bg-white border border-violet-200 hover:border-violet-400 rounded-xl p-5 flex items-center justify-between gap-4 transition-colors cursor-pointer shadow-sm"
                    >
                      <div className="flex items-center gap-4 min-w-0">
                        <span className="w-10 h-10 rounded-xl bg-violet-100 text-violet-800 font-mono text-sm font-bold flex items-center justify-center shrink-0">
                          #{String(student.rank).padStart(2, '0')}
                        </span>
                        <div className="min-w-0">
                          <div className="text-base font-bold text-slate-900 truncate">
                            {student.name}
                          </div>
                          <div className="text-xs font-mono text-violet-700 mt-0.5">
                            {student.hallTicket} · {student.branch} · {student.totalMarks}/600
                          </div>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="text-xl font-mono font-bold tabular-nums text-violet-800">
                          {student.sgpa.toFixed(2)} SGPA
                        </div>
                        <div className="text-xs font-mono tabular-nums text-slate-500">
                          {student.cgpa.toFixed(2)} CGPA
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </section>

            {/* Complete Top 10 Ranked Table */}
            <section className="bg-white border border-indigo-100 rounded-2xl overflow-hidden shadow-sm">
              <div className="px-6 py-4 border-b border-indigo-100 bg-gradient-to-r from-indigo-50/60 to-violet-50/40 flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-slate-900">
                    Top 10 Merit Standings
                  </h2>
                  <p className="text-xs text-slate-600 mt-0.5">
                    Select any row to open the full verified semester grade card
                  </p>
                </div>
                <span className="text-xs font-mono font-semibold text-indigo-700 tabular-nums">
                  {toppers.length} achievers listed
                </span>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                      <th scope="col" className="py-3 pl-6 pr-3 w-28">Rank</th>
                      <th scope="col" className="py-3 px-3">Hall Ticket</th>
                      <th scope="col" className="py-3 px-3">Candidate Name</th>
                      <th scope="col" className="py-3 px-3">Branch</th>
                      <th scope="col" className="py-3 px-3 text-right">Credits</th>
                      <th scope="col" className="py-3 px-3 text-right">Marks</th>
                      <th scope="col" className="py-3 px-3 text-right">SGPA</th>
                      <th scope="col" className="py-3 px-3 text-right">CGPA</th>
                      <th scope="col" className="py-3 pl-3 pr-6 text-right">Marksheet</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {toppers.map((row) => (
                      <tr
                        key={row.hallTicket}
                        className="hover:bg-indigo-50/35 transition-colors"
                      >
                        <td className="py-3.5 pl-6 pr-3 font-mono font-bold tabular-nums text-slate-900">
                          #{String(row.rank).padStart(2, '0')}
                          {row.rank === 1 ? ' · Gold' : row.rank === 2 ? ' · Silver' : row.rank === 3 ? ' · Bronze' : ''}
                        </td>
                        <td className="py-3.5 px-3 font-mono text-xs font-semibold text-indigo-700">
                          {row.hallTicket}
                        </td>
                        <td className="py-3.5 px-3 font-semibold text-slate-900">
                          {row.name}
                        </td>
                        <td className="py-3.5 px-3 font-mono text-xs text-slate-600">
                          {row.branch}
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                          {row.earnedCredits} / 20
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                          {row.totalMarks} ({row.percentage.toFixed(1)}%)
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-bold tabular-nums text-emerald-700">
                          {row.sgpa.toFixed(2)}
                        </td>
                        <td className="py-3.5 px-3 text-right font-mono font-semibold tabular-nums text-slate-900">
                          {row.cgpa.toFixed(2)}
                        </td>
                        <td className="py-3.5 pl-3 pr-6 text-right">
                          <button
                            type="button"
                            onClick={() => onInspectStudent(row.hallTicket)}
                            className="inline-flex items-center gap-1 text-xs font-semibold text-indigo-700 hover:text-indigo-900 hover:underline underline-offset-4 cursor-pointer"
                          >
                            Open
                            <ExternalLink className="w-3 h-3" aria-hidden="true" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </section>
          </>
        )}
      </div>
    </div>
  );
}
