import {useEffect, useRef} from 'react';
import {Chart, registerables} from 'chart.js';
import type {ChartConfiguration, ChartType} from 'chart.js';

Chart.register(...registerables);

interface ChartCanvasProps<T extends ChartType = ChartType> {
  config: ChartConfiguration<T>;
  ariaLabel: string;
  className?: string;
}

export function ChartCanvas<T extends ChartType>({
  config,
  ariaLabel,
  className = 'w-full h-full',
}: ChartCanvasProps<T>) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const chartInstanceRef = useRef<Chart<T> | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
      chartInstanceRef.current = null;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    chartInstanceRef.current = new Chart(ctx, config);

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
        chartInstanceRef.current = null;
      }
    };
  }, [config]);

  return (
    <div className={`relative ${className}`}>
      <canvas ref={canvasRef} aria-label={ariaLabel} role="img" />
    </div>
  );
}
