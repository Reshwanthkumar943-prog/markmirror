import {useEffect, useState} from 'react';
import {ArrowRight, Search, X} from 'lucide-react';
import type {StudentSummaryItem} from '../types/portal.ts';

interface LookupSectionProps {
  query: string;
  onQueryChange: (val: string) => void;
  onSearch: (hallTicket: string) => void;
  isLoading: boolean;
  errorMessage: string | null;
  suggestions: string[];
}

const SAMPLE_PROFILES: Array<{hallTicket: string; label: string; colorClass: string}> = [
  {hallTicket: '22CSE104', label: '8.85 Distinction', colorClass: 'text-amber-300 hover:text-amber-200'},
  {hallTicket: '22CSE101', label: '10.00 Rank 1', colorClass: 'text-emerald-300 hover:text-emerald-200'},
  {hallTicket: '22CSE118', label: 'Re-Eval Demo', colorClass: 'text-rose-300 hover:text-rose-200'},
  {hallTicket: '22ECE105', label: 'ECE Sem V', colorClass: 'text-cyan-300 hover:text-cyan-200'},
  {hallTicket: '22IT103', label: 'IT Sem V', colorClass: 'text-violet-200 hover:text-white'},
];

export function LookupSection({
  query,
  onQueryChange,
  onSearch,
  isLoading,
  errorMessage,
  suggestions,
}: LookupSectionProps) {
  const [matches, setMatches] = useState<StudentSummaryItem[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setMatches([]);
      return;
    }

    const controller = new AbortController();
    const timer = window.setTimeout(async () => {
      try {
        const res = await fetch(
          `/api/students?q=${encodeURIComponent(trimmed)}&batch=ALL&limit=6`,
          {signal: controller.signal},
        );
        if (res.ok) {
          const data = (await res.json()) as {students: StudentSummaryItem[]};
          setMatches(data.students);
        }
      } catch {
        // Ignore aborted requests
      }
    }, 150);

    return () => {
      window.clearTimeout(timer);
      controller.abort();
    };
  }, [query]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleaned = query.trim();
    if (!cleaned) return;
    setShowDropdown(false);
    onSearch(cleaned);
  };

  return (
    <section className="no-print relative overflow-hidden bg-gradient-to-br from-indigo-950 via-violet-900 to-teal-900 text-white border-b border-indigo-900">
      {/* Creative Geometric ResultRadar Concentric Arcs */}
      <div className="absolute inset-0 bg-radar-grid opacity-55 pointer-events-none" aria-hidden="true" />
      <svg
        className="absolute -right-24 -top-24 w-[480px] h-[480px] text-teal-400/15 pointer-events-none"
        viewBox="0 0 400 400"
        fill="none"
        aria-hidden="true"
      >
        <circle cx="200" cy="200" r="180" stroke="currentColor" strokeWidth="1.5" strokeDasharray="8 8" />
        <circle cx="200" cy="200" r="135" stroke="#a78bfa" strokeOpacity="0.35" strokeWidth="1.5" />
        <circle cx="200" cy="200" r="90" stroke="#fbbf24" strokeOpacity="0.3" strokeWidth="1.5" />
        <path d="M200 20V380M20 200H380" stroke="currentColor" strokeWidth="1" strokeOpacity="0.4" />
      </svg>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-9 lg:py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-end">
          <div className="lg:col-span-7">
            <p className="text-xs font-semibold text-amber-300 tracking-wide mb-2">
              ResultRadar Portal · Controller of Examinations · Academic Session 2026
            </p>
            <h1 className="text-3xl sm:text-4xl lg:text-[2.65rem] font-serif font-bold text-white tracking-tight text-balance leading-tight">
              Semester Examination Result Portal
            </h1>
            <p className="mt-3 text-sm sm:text-base text-indigo-100/90 max-w-2xl leading-relaxed">
              Lookup verified marksheets by hall ticket or candidate name, explore credit-weighted
              SGPA &amp; CGPA trajectories, and benchmark performance across engineering cohorts.
            </p>
          </div>

          <div className="lg:col-span-5">
            <form onSubmit={handleSubmit} className="relative bg-white/10 backdrop-blur-md border border-white/20 rounded-xl p-4 sm:p-5">
              <label
                htmlFor="hall-ticket-input"
                className="block text-xs font-semibold text-indigo-100 mb-2"
              >
                Hall Ticket Number or Candidate Name
              </label>
              <div className="flex items-stretch gap-2">
                <div className="relative flex-1">
                  <Search
                    className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none"
                    aria-hidden="true"
                  />
                  <input
                    id="hall-ticket-input"
                    type="text"
                    value={query}
                    onFocus={() => setShowDropdown(true)}
                    onBlur={() => window.setTimeout(() => setShowDropdown(false), 180)}
                    onChange={(e) => {
                      onQueryChange(e.target.value);
                      setShowDropdown(true);
                    }}
                    placeholder="e.g. 22CSE104 or Rohan"
                    autoComplete="off"
                    className="w-full h-11 pl-10 pr-9 bg-white border border-white/30 rounded-lg text-sm font-mono font-medium text-slate-900 placeholder:font-sans placeholder:text-slate-400 focus:border-amber-400 focus:outline-none focus:ring-2 focus:ring-amber-400/40"
                  />
                  {query && (
                    <button
                      type="button"
                      aria-label="Clear search"
                      onClick={() => onQueryChange('')}
                      className="absolute right-2.5 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700 cursor-pointer"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}

                  {showDropdown && matches.length > 0 && (
                    <ul
                      role="listbox"
                      aria-label="Matching student records"
                      className="absolute left-0 right-0 top-full mt-1.5 bg-white border border-indigo-100 rounded-lg shadow-xl z-20 divide-y divide-slate-100 max-h-64 overflow-y-auto"
                    >
                      {matches.map((m) => (
                        <li key={m.hallTicket}>
                          <button
                            type="button"
                            onMouseDown={(e) => {
                              e.preventDefault();
                              onQueryChange(m.hallTicket);
                              setShowDropdown(false);
                              onSearch(m.hallTicket);
                            }}
                            className="w-full px-3.5 py-2.5 text-left hover:bg-indigo-50/70 flex items-center justify-between gap-3 cursor-pointer"
                          >
                            <div className="min-w-0">
                              <span className="font-mono text-xs font-semibold text-indigo-700">
                                {m.hallTicket}
                              </span>
                              <span className="mx-2 text-slate-300" aria-hidden="true">
                                ·
                              </span>
                              <span className="text-sm font-medium text-slate-900 truncate">
                                {m.name}
                              </span>
                            </div>
                            <span className="text-xs font-mono tabular-nums text-teal-700 font-semibold shrink-0">
                              {m.branch} · {m.sgpa.toFixed(2)}
                            </span>
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={isLoading || !query.trim()}
                  className="inline-flex items-center justify-center gap-2 px-5 h-11 bg-amber-400 hover:bg-amber-300 disabled:bg-white/25 text-slate-950 disabled:text-white/50 text-sm font-bold rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 cursor-pointer disabled:cursor-not-allowed"
                >
                  {isLoading ? 'Fetching...' : 'Fetch Result'}
                  {!isLoading && <ArrowRight className="w-4 h-4" aria-hidden="true" />}
                </button>
              </div>

              {/* Quick-access Hall Tickets */}
              <div className="mt-3.5 flex flex-wrap items-center gap-x-3.5 gap-y-1.5 text-xs text-indigo-200">
                <span className="font-medium text-indigo-100">Quick picks:</span>
                {SAMPLE_PROFILES.map((item) => (
                  <button
                    key={item.hallTicket}
                    type="button"
                    onClick={() => {
                      onQueryChange(item.hallTicket);
                      onSearch(item.hallTicket);
                    }}
                    title={item.label}
                    className={`font-mono font-semibold underline underline-offset-4 cursor-pointer whitespace-nowrap ${item.colorClass}`}
                  >
                    {item.hallTicket}
                  </button>
                ))}
              </div>
            </form>
          </div>
        </div>

        {errorMessage && (
          <div
            role="alert"
            className="mt-6 p-4 bg-rose-950/80 border border-rose-400/50 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3"
          >
            <div className="text-sm text-rose-100">
              <span className="font-semibold text-white">Record Not Found:</span> {errorMessage}
            </div>
            {suggestions.length > 0 && (
              <div className="flex flex-wrap items-center gap-3 text-xs">
                <span className="text-rose-200 font-medium">Try valid hall tickets:</span>
                {suggestions.map((code) => (
                  <button
                    key={code}
                    type="button"
                    onClick={() => {
                      onQueryChange(code);
                      onSearch(code);
                    }}
                    className="font-mono font-semibold text-amber-300 underline underline-offset-4 hover:text-amber-200 cursor-pointer"
                  >
                    {code}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}
