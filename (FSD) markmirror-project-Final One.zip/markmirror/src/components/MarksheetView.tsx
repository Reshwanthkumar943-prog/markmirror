import {useEffect, useMemo, useState} from 'react';
import {
  CheckCircle2,
  Download,
  FileText,
  Printer,
  RotateCcw,
  XCircle,
} from 'lucide-react';
import type {ChartConfiguration} from 'chart.js';
import {
  REVALUATION_FEE_PER_LAB,
  REVALUATION_FEE_PER_THEORY,
  REVALUATION_PROCESSING_FEE,
} from '../shared/grading.ts';
import type {LetterGrade} from '../shared/grading.ts';
import type {ResultLookupResponse} from '../types/portal.ts';
import {ChartCanvas} from './ChartCanvas.tsx';

interface MarksheetViewProps {
  data: ResultLookupResponse;
  onPrint: () => void;
  onOpenAnalytics: () => void;
}

const GRADE_TILE_STYLES: Record<LetterGrade, string> = {
  O: 'bg-emerald-600 text-white',
  'A+': 'bg-indigo-600 text-white',
  A: 'bg-violet-600 text-white',
  'B+': 'bg-teal-600 text-white',
  B: 'bg-amber-500 text-slate-950',
  C: 'bg-orange-500 text-white',
  F: 'bg-rose-600 text-white',
};

const BAR_COLOR_BY_GRADE: Record<LetterGrade, string> = {
  O: 'bg-emerald-500',
  'A+': 'bg-indigo-500',
  A: 'bg-violet-500',
  'B+': 'bg-teal-500',
  B: 'bg-amber-500',
  C: 'bg-orange-500',
  F: 'bg-rose-500',
};

interface SavedChallan {
  challanId: string;
  subjectCodes: string[];
  totalFee: number;
  submittedAt: string;
}

export function MarksheetView({data, onPrint, onOpenAnalytics}: MarksheetViewProps) {
  const {student, standing, subjectAverages} = data;
  const [selectedRevalCodes, setSelectedRevalCodes] = useState<string[]>([]);
  const [savedChallans, setSavedChallans] = useState<SavedChallan[]>([]);
  const [revalSubmitting, setRevalSubmitting] = useState(false);
  const [revalError, setRevalError] = useState<string | null>(null);

  useEffect(() => {
    setSelectedRevalCodes([]);
    setRevalError(null);
    let cancelled = false;
    fetch(`/api/revaluation/${encodeURIComponent(student.hallTicket)}`)
      .then((res) => (res.ok ? res.json() : {applications: []}))
      .then((body: {applications?: SavedChallan[]}) => {
        if (!cancelled) {
          setSavedChallans(Array.isArray(body.applications) ? body.applications : []);
        }
      })
      .catch(() => {
        if (!cancelled) setSavedChallans([]);
      });
    return () => {
      cancelled = true;
    };
  }, [student.hallTicket]);

  const avgMap = useMemo(() => {
    const map = new Map<string, {avgMarks: number; passRate: number}>();
    for (const item of subjectAverages) {
      map.set(item.code, {avgMarks: item.avgMarks, passRate: item.passRate});
    }
    return map;
  }, [subjectAverages]);

  // Historical Semester Trend Line Chart with vibrant area fill
  const trendConfig = useMemo<ChartConfiguration<'line'>>(() => {
    return {
      type: 'line',
      data: {
        labels: student.semesterHistory.map((s) => s.semester.replace('Semester ', 'Sem ')),
        datasets: [
          {
            label: `${student.hallTicket} SGPA`,
            data: student.semesterHistory.map((s) => s.sgpa),
            borderColor: '#4f46e5',
            backgroundColor: 'rgba(79, 70, 229, 0.14)',
            borderWidth: 3,
            pointBackgroundColor: ['#7c3aed', '#6366f1', '#4f46e5', '#0d9488', '#059669'],
            pointBorderColor: '#ffffff',
            pointBorderWidth: 2,
            pointRadius: 5.5,
            tension: 0.3,
            fill: true,
          },
          {
            label: 'Cohort Mean SGPA',
            data: student.semesterHistory.map((s) => s.batchAverage),
            borderColor: '#f59e0b',
            borderDash: [5, 5],
            borderWidth: 2,
            pointRadius: 4,
            pointBackgroundColor: '#f59e0b',
            tension: 0.3,
            fill: false,
          },
        ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              boxWidth: 12,
              usePointStyle: true,
              font: {family: "'Plus Jakarta Sans', sans-serif", size: 12},
            },
          },
          tooltip: {
            backgroundColor: '#1e1b4b',
            padding: 10,
            titleFont: {family: "'Plus Jakarta Sans', sans-serif", size: 12},
            bodyFont: {family: "'IBM Plex Mono', monospace", size: 12},
          },
        },
        scales: {
          y: {
            min: 5,
            max: 10,
            ticks: {
              stepSize: 1,
              font: {family: "'IBM Plex Mono', monospace", size: 11},
            },
            grid: {color: '#f1f5f9'},
          },
          x: {
            ticks: {
              font: {family: "'Plus Jakarta Sans', sans-serif", size: 12},
            },
            grid: {display: false},
          },
        },
      },
    };
  }, [student]);

  const toggleRevalSubject = (code: string) => {
    setRevalError(null);
    setSelectedRevalCodes((prev) =>
      prev.includes(code) ? prev.filter((c) => c !== code) : [...prev, code],
    );
  };

  const handleSubmitRevaluation = async () => {
    if (selectedRevalCodes.length === 0) return;
    setRevalSubmitting(true);
    setRevalError(null);
    try {
      const res = await fetch('/api/revaluation/submit', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          hallTicket: student.hallTicket,
          subjectCodes: selectedRevalCodes,
        }),
      });
      if (!res.ok) {
        const err = (await res.json().catch(() => ({}))) as {error?: string};
        setRevalError(err.error || 'Could not save re-evaluation application.');
        return;
      }
      const payload = (await res.json()) as {application: SavedChallan};
      setSavedChallans((prev) => [payload.application, ...prev]);
      setSelectedRevalCodes([]);
    } catch {
      setRevalError('Network error submitting re-evaluation request.');
    } finally {
      setRevalSubmitting(false);
    }
  };

  const revalCalculation = useMemo(() => {
    const selected = student.subjects.filter((s) => selectedRevalCodes.includes(s.code));
    const paperSubtotal = selected.reduce(
      (acc, s) => acc + (s.type === 'Lab' ? REVALUATION_FEE_PER_LAB : REVALUATION_FEE_PER_THEORY),
      0,
    );
    const processingFee = selected.length > 0 ? REVALUATION_PROCESSING_FEE : 0;
    return {
      selected,
      paperSubtotal,
      processingFee,
      totalFee: paperSubtotal + processingFee,
    };
  }, [student.subjects, selectedRevalCodes]);

  const handleDownloadJson = () => {
    const blob = new Blob([JSON.stringify(student, null, 2)], {type: 'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${student.hallTicket}_marksheet.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  // SVG Radial SGPA Ring Math
  const ringRadius = 38;
  const ringCircumference = 2 * Math.PI * ringRadius;
  const sgpaProgress = Math.max(0, Math.min(1, student.sgpa / 10));
  const ringOffset = ringCircumference * (1 - sgpaProgress);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
      {/* Action Toolbar (Hidden in print) */}
      <div className="no-print flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="text-sm text-slate-600">
          Verified grade card for{' '}
          <span className="font-mono font-bold text-indigo-700">{student.hallTicket}</span>
          <span className="mx-2 text-slate-300" aria-hidden="true">·</span>
          <span className="font-medium text-slate-800">
            Branch Rank #{standing.branchRank} of {standing.branchTotal}
          </span>
          <span className="mx-2 text-slate-300" aria-hidden="true">·</span>
          <span className="font-mono font-semibold tabular-nums text-teal-700">
            {standing.branchPercentile}th percentile
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="button"
            onClick={onOpenAnalytics}
            className="px-3.5 py-2 text-xs font-semibold text-indigo-700 bg-indigo-50 border border-indigo-200 hover:bg-indigo-100 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            Compare with Cohort Analytics
          </button>
          <button
            type="button"
            onClick={handleDownloadJson}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-teal-800 bg-teal-50 border border-teal-200 hover:bg-teal-100 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" aria-hidden="true" />
            Export JSON
          </button>
          <button
            type="button"
            onClick={onPrint}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-gradient-to-r from-indigo-700 to-violet-700 hover:from-indigo-800 hover:to-violet-800 rounded-lg transition-colors whitespace-nowrap cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5" aria-hidden="true" />
            Print / Save A4 PDF
          </button>
        </div>
      </div>

      {/* Official University Grade Card (A4 Printable Surface) */}
      <article className="print-marksheet bg-white border border-indigo-200/80 rounded-2xl overflow-hidden shadow-sm">
        {/* Chromatic Top Strip */}
        <div
          className="no-print h-1.5 w-full bg-gradient-to-r from-indigo-600 via-violet-500 via-50% to-emerald-500"
          aria-hidden="true"
        />

        {/* Institutional Header */}
        <div className="print-reset-surface px-6 sm:px-8 py-6 border-b border-indigo-100 bg-gradient-to-r from-indigo-50/70 via-violet-50/40 to-teal-50/60">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              {/* Institutional Academic Crest SVG */}
              <svg
                viewBox="0 0 48 48"
                className="w-13 h-13 shrink-0"
                fill="none"
                aria-hidden="true"
              >
                <defs>
                  <linearGradient id="crestGrad" x1="8" y1="4" x2="40" y2="44" gradientUnits="userSpaceOnUse">
                    <stop offset="0%" stopColor="#4338ca" />
                    <stop offset="100%" stopColor="#0d9488" />
                  </linearGradient>
                </defs>
                <path
                  d="M24 4L40 10V22C40 32.5 33.1 41.2 24 44C14.9 41.2 8 32.5 8 22V10L24 4Z"
                  stroke="url(#crestGrad)"
                  strokeWidth="2.2"
                  fill="#ffffff"
                />
                <path
                  d="M15 20L24 15L33 20L24 25L15 20Z"
                  stroke="#4338ca"
                  strokeWidth="1.75"
                  fill="#e0e7ff"
                />
                <path
                  d="M18 23V29C18 31 20.7 33 24 33C27.3 33 30 31 30 29V23"
                  stroke="#0d9488"
                  strokeWidth="1.75"
                />
              </svg>
              <div>
                <p className="text-xs font-semibold tracking-wider text-indigo-700 uppercase">
                  National Institute of Engineering &amp; Technology
                </p>
                <h2 className="text-xl sm:text-2xl font-serif font-bold text-slate-900">
                  Memorandum of Semester Grades
                </h2>
                <p className="text-xs text-slate-600 mt-0.5">
                  Office of the Controller of Examinations · Regulation {student.regulation}
                </p>
              </div>
            </div>

            <div className="sm:text-right">
              <div className="text-xs text-slate-500">Examination Session</div>
              <div className="text-sm font-bold text-indigo-950">{student.examSession}</div>
              <div className="text-xs font-mono text-teal-700 font-medium mt-0.5">
                {student.semester} · Batch {student.batch}
              </div>
            </div>
          </div>
        </div>

        {/* Candidate Identity Grid */}
        <div className="px-6 sm:px-8 py-5 border-b border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-y-4 gap-x-6 text-sm">
          <div>
            <div className="text-xs text-slate-500">Hall Ticket Number</div>
            <div className="font-mono font-bold text-indigo-700 mt-0.5 tabular-nums">
              {student.hallTicket}
            </div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Candidate Name</div>
            <div className="font-bold text-slate-900 mt-0.5">{student.name}</div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Father&apos;s Name</div>
            <div className="font-medium text-slate-800 mt-0.5">{student.fatherName}</div>
          </div>
          <div>
            <div className="text-xs text-slate-500">Programme &amp; Branch</div>
            <div className="font-medium text-slate-800 mt-0.5">
              B.Tech ({student.branch}) — {student.branchName}
            </div>
          </div>
        </div>

        {/* Subject Marks & Credit Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th scope="col" className="py-3 pl-6 sm:pl-8 pr-3 whitespace-nowrap">Code</th>
                <th scope="col" className="py-3 px-3">Subject Title</th>
                <th scope="col" className="py-3 px-3 text-right whitespace-nowrap">Credits (C)</th>
                <th scope="col" className="py-3 px-3 text-right whitespace-nowrap">Internal (40)</th>
                <th scope="col" className="py-3 px-3 text-right whitespace-nowrap">External (60)</th>
                <th scope="col" className="py-3 px-3 text-right whitespace-nowrap">Total (100)</th>
                <th scope="col" className="no-print py-3 px-3 text-right whitespace-nowrap">Branch Avg</th>
                <th scope="col" className="py-3 px-3 text-center whitespace-nowrap">Grade</th>
                <th scope="col" className="py-3 px-3 text-right whitespace-nowrap">GP</th>
                <th scope="col" className="py-3 px-3 text-right whitespace-nowrap">C × GP</th>
                <th scope="col" className="py-3 pl-3 pr-6 sm:pr-8 text-right whitespace-nowrap">Result</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 text-sm">
              {student.subjects.map((subj) => {
                const avg = avgMap.get(subj.code)?.avgMarks;
                return (
                  <tr
                    key={subj.code}
                    className={!subj.passed ? 'bg-rose-50/50' : 'hover:bg-indigo-50/30 transition-colors'}
                  >
                    <td className="py-3.5 pl-6 sm:pl-8 pr-3 font-mono text-xs font-semibold text-indigo-700 whitespace-nowrap">
                      {subj.code}
                    </td>
                    <td className="py-3.5 px-3 font-medium text-slate-900 min-w-[200px]">
                      <div>
                        {subj.name}
                        <span className="ml-2 text-xs text-slate-400 font-normal">({subj.type})</span>
                      </div>
                      {/* Colorful visual score meter */}
                      <div className="no-print mt-1.5 w-full max-w-[210px] h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className={`h-full rounded-full ${BAR_COLOR_BY_GRADE[subj.grade]}`}
                          style={{width: `${subj.totalMarks}%`}}
                        />
                      </div>
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                      {subj.credits}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                      {subj.internalMarks}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                      {subj.externalMarks}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono font-bold tabular-nums text-slate-900">
                      {subj.totalMarks}
                    </td>
                    <td className="no-print py-3.5 px-3 text-right font-mono text-xs tabular-nums text-slate-500">
                      {avg !== undefined ? avg.toFixed(1) : '—'}
                    </td>
                    <td className="py-3.5 px-3 text-center">
                      <span
                        className={`inline-flex items-center justify-center w-8 h-7 rounded-md font-mono text-xs font-bold ${GRADE_TILE_STYLES[subj.grade]}`}
                      >
                        {subj.grade}
                      </span>
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono tabular-nums text-slate-700">
                      {subj.gradePoints}
                    </td>
                    <td className="py-3.5 px-3 text-right font-mono font-semibold tabular-nums text-indigo-950">
                      {subj.creditPoints}
                    </td>
                    <td className="py-3.5 pl-3 pr-6 sm:pr-8 text-right whitespace-nowrap">
                      {subj.passed ? (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700">
                          <CheckCircle2 className="w-3.5 h-3.5" aria-hidden="true" />
                          PASS
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 text-xs font-bold text-rose-700">
                          <XCircle className="w-3.5 h-3.5" aria-hidden="true" />
                          FAIL
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="border-t-2 border-indigo-200 bg-indigo-50/40 print-reset-surface text-sm font-semibold text-slate-900">
                <td colSpan={2} className="py-3.5 pl-6 sm:pl-8 pr-3">
                  Semester Totals
                </td>
                <td className="py-3.5 px-3 text-right font-mono tabular-nums">
                  {student.totalCredits}
                </td>
                <td colSpan={2} className="py-3.5 px-3 text-right text-xs font-normal text-slate-600">
                  Earned Credits: <span className="font-mono font-bold text-teal-700">{student.earnedCredits}</span>
                </td>
                <td className="py-3.5 px-3 text-right font-mono tabular-nums">
                  {student.totalMarks} / {student.maxMarks}
                </td>
                <td className="no-print py-3.5 px-3 text-right font-mono text-xs tabular-nums text-indigo-700 font-bold">
                  {student.percentage}%
                </td>
                <td colSpan={2} className="py-3.5 px-3 text-right text-xs font-normal text-slate-600">
                  Σ(C × GP)
                </td>
                <td className="py-3.5 px-3 text-right font-mono font-bold tabular-nums text-indigo-700">
                  {student.totalWeightedPoints}
                </td>
                <td className="py-3.5 pl-3 pr-6 sm:pr-8 text-right font-mono text-xs tabular-nums">
                  {student.hasBacklog ? `${student.backlogCount} Backlog` : 'All Clear'}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* SGPA Radial Gauge & Summary Strip */}
        <div className="px-6 sm:px-8 py-6 border-t border-slate-200 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 bg-white print-break-avoid items-center">
          <div className="flex items-center gap-4">
            {/* Creative Radial SGPA Ring */}
            <svg viewBox="0 0 96 96" className="no-print w-20 h-20 shrink-0 -rotate-90" aria-hidden="true">
              <defs>
                <linearGradient id="sgpaRingGrad" x1="0" y1="0" x2="96" y2="96" gradientUnits="userSpaceOnUse">
                  <stop offset="0%" stopColor="#4f46e5" />
                  <stop offset="55%" stopColor="#0d9488" />
                  <stop offset="100%" stopColor="#10b981" />
                </linearGradient>
              </defs>
              <circle
                cx="48"
                cy="48"
                r={ringRadius}
                stroke="#e2e8f0"
                strokeWidth="8"
                fill="none"
              />
              <circle
                cx="48"
                cy="48"
                r={ringRadius}
                stroke={student.hasBacklog ? '#e11d48' : 'url(#sgpaRingGrad)'}
                strokeWidth="8"
                strokeLinecap="round"
                strokeDasharray={ringCircumference}
                strokeDashoffset={ringOffset}
                fill="none"
              />
            </svg>
            <div>
              <div className="text-xs font-medium text-slate-500">Semester GPA (SGPA)</div>
              <div className="mt-0.5 flex items-baseline gap-1.5">
                <span className="text-3xl font-mono font-bold tabular-nums text-indigo-700">
                  {student.sgpa.toFixed(2)}
                </span>
                <span className="text-xs font-mono text-slate-500">/ 10.00</span>
              </div>
              <div className="mt-1 text-xs font-mono text-slate-500 tabular-nums">
                {student.totalWeightedPoints} ÷ {student.totalCredits} credits
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-violet-50/70 border border-violet-100 print-reset-surface">
            <div className="text-xs font-medium text-violet-900/70">Cumulative GPA (CGPA)</div>
            <div className="mt-1 flex items-baseline gap-2">
              <span className="text-3xl font-mono font-bold tabular-nums text-violet-900">
                {student.cgpa.toFixed(2)}
              </span>
              <span className="text-xs font-mono text-violet-700">/ 10.00</span>
            </div>
            <div className="mt-1 text-xs text-violet-800/80">
              Across Semesters I – V
            </div>
          </div>

          <div className="p-4 rounded-xl bg-teal-50/70 border border-teal-100 print-reset-surface">
            <div className="text-xs font-medium text-teal-900/70">Aggregate Percentage</div>
            <div className="mt-1 text-3xl font-mono font-bold tabular-nums text-teal-900">
              {student.percentage.toFixed(1)}%
            </div>
            <div className="mt-1 text-xs font-mono text-teal-800/80 tabular-nums">
              {student.totalMarks} out of {student.maxMarks} marks
            </div>
          </div>

          <div
            className={`p-4 rounded-xl border print-reset-surface ${
              student.hasBacklog
                ? 'bg-rose-50/70 border-rose-200'
                : student.sgpa >= 8.0
                  ? 'bg-emerald-50/80 border-emerald-200'
                  : 'bg-amber-50/70 border-amber-200'
            }`}
          >
            <div className="text-xs font-medium text-slate-600">Academic Standing</div>
            <div
              className={`mt-1 text-lg font-bold leading-snug ${
                student.hasBacklog
                  ? 'text-rose-800'
                  : student.sgpa >= 8.0
                    ? 'text-emerald-800'
                    : 'text-amber-900'
              }`}
            >
              {student.classification}
            </div>
            <div className="mt-1 text-xs text-slate-600">
              {student.hasBacklog
                ? 'Eligible for supplementary / re-evaluation'
                : 'Satisfies all R22 credit requirements'}
            </div>
          </div>
        </div>

        {/* Official Print-Only Footer & Signature Block */}
        <div className="print-only px-8 py-6 border-t border-slate-200">
          <div className="flex justify-between items-end text-xs text-slate-600">
            <div>
              <p className="font-semibold text-slate-800">
                Formula: SGPA = Σ(Credits × Grade Points) / Σ(Credits)
              </p>
              <p className="mt-1">
                Grading Scale: O=10 (90–100), A+=9 (80–89), A=8 (70–79), B+=7 (60–69), B=6 (50–59), C=5 (40–49), F=0 (&lt;40)
              </p>
              <p className="mt-2 text-slate-500">
                Generated via MarkMirror Examination Portal · Electronically verified record
              </p>
            </div>
            <div className="text-right">
              <div className="w-44 border-b border-slate-400 mb-1.5 ml-auto" />
              <p className="font-semibold text-slate-900">Controller of Examinations</p>
              <p className="text-slate-500">NIET Examination Cell</p>
            </div>
          </div>
        </div>
      </article>

      {/* Secondary Analytical Modules Below Marksheet (Hidden in Print) */}
      <div className="no-print grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Stretch Feature 1: Historical Semester SGPA Trajectory */}
        <section className="lg:col-span-7 bg-white border border-indigo-100 rounded-2xl p-6 shadow-sm">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-5">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Historical Semester SGPA Trajectory
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Completed semester progression compared against cohort mean SGPA
              </p>
            </div>
            <div className="text-xs font-mono tabular-nums text-slate-600">
              Latest Δ:{' '}
              {(() => {
                const hist = student.semesterHistory;
                const prev = hist[hist.length - 2]?.sgpa ?? student.sgpa;
                const diff = Number((student.sgpa - prev).toFixed(2));
                return (
                  <span className={diff >= 0 ? 'text-emerald-700 font-bold' : 'text-rose-700 font-bold'}>
                    {diff >= 0 ? `+${diff.toFixed(2)}` : diff.toFixed(2)}
                  </span>
                );
              })()}
            </div>
          </div>
          <div className="h-64">
            <ChartCanvas
              config={trendConfig}
              ariaLabel={`SGPA progression across semesters for ${student.name}`}
            />
          </div>
        </section>

        {/* Stretch Feature 2: Re-Evaluation Fee Estimator */}
        <section className="lg:col-span-5 bg-white border border-amber-200/80 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
          <div>
            <div className="flex items-start justify-between gap-3 mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Re-Evaluation Fee Estimator
                </h3>
                <p className="text-xs text-slate-500 mt-0.5">
                  Theory: ₹{REVALUATION_FEE_PER_THEORY}/paper · Lab: ₹{REVALUATION_FEE_PER_LAB}/paper · Processing: ₹{REVALUATION_PROCESSING_FEE}
                </p>
              </div>
              {selectedRevalCodes.length > 0 && (
                <button
                  type="button"
                  onClick={() => {
                    setSelectedRevalCodes([]);
                    setRevalError(null);
                  }}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-amber-800 hover:text-amber-950 cursor-pointer"
                >
                  <RotateCcw className="w-3 h-3" aria-hidden="true" />
                  Reset
                </button>
              )}
            </div>

            <div className="divide-y divide-slate-100 border-y border-slate-200 max-h-56 overflow-y-auto">
              {student.subjects.map((subj) => {
                const checked = selectedRevalCodes.includes(subj.code);
                const fee =
                  subj.type === 'Lab' ? REVALUATION_FEE_PER_LAB : REVALUATION_FEE_PER_THEORY;
                return (
                  <label
                    key={subj.code}
                    className={`flex items-center justify-between gap-3 py-2.5 px-2 cursor-pointer transition-colors ${
                      checked ? 'bg-amber-50/70' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => toggleRevalSubject(subj.code)}
                        className="w-4 h-4 rounded border-slate-300 text-indigo-700 focus:ring-indigo-700 cursor-pointer"
                      />
                      <div className="min-w-0">
                        <div className="text-sm font-medium text-slate-900 truncate">
                          {subj.shortName}
                        </div>
                        <div className="text-xs font-mono text-slate-500">
                          {subj.code} · Marks: {subj.totalMarks}/100 ({subj.grade})
                        </div>
                      </div>
                    </div>
                    <span className="text-xs font-mono font-bold tabular-nums text-indigo-900 shrink-0">
                      ₹{fee}
                    </span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="mt-5 pt-4 border-t border-slate-200 space-y-3">
            <div className="flex items-center justify-between text-xs text-slate-600">
              <span>Papers selected ({revalCalculation.selected.length})</span>
              <span className="font-mono tabular-nums">₹{revalCalculation.paperSubtotal}</span>
            </div>
            <div className="flex items-center justify-between text-xs text-slate-600">
              <span>Portal processing fee</span>
              <span className="font-mono tabular-nums">₹{revalCalculation.processingFee}</span>
            </div>
            <div className="flex items-center justify-between text-sm font-bold text-slate-900 pt-1">
              <span>Estimated Total Payable</span>
              <span className="text-lg font-mono tabular-nums text-indigo-700">
                ₹{revalCalculation.totalFee}
              </span>
            </div>

            {revalError && (
              <div className="p-2.5 bg-rose-50 border border-rose-200 rounded-lg text-xs text-rose-800">
                {revalError}
              </div>
            )}

            <button
              type="button"
              disabled={revalCalculation.selected.length === 0 || revalSubmitting}
              onClick={handleSubmitRevaluation}
              className="w-full inline-flex items-center justify-center gap-2 px-4 py-2.5 text-xs font-semibold text-white bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 disabled:from-slate-200 disabled:to-slate-200 disabled:text-slate-400 rounded-lg transition-colors cursor-pointer disabled:cursor-not-allowed"
            >
              <FileText className="w-3.5 h-3.5" aria-hidden="true" />
              {revalSubmitting ? 'Saving Challan...' : 'Submit & Save Re-Evaluation Challan'}
            </button>

            {savedChallans.length > 0 && (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-xs text-emerald-950 space-y-1">
                <div className="font-semibold">
                  Saved Challan: <span className="font-mono">{savedChallans[0].challanId}</span>
                </div>
                <div>
                  Papers: <span className="font-mono">{savedChallans[0].subjectCodes.join(', ')}</span> · Total{' '}
                  <span className="font-mono font-bold">₹{savedChallans[0].totalFee}</span>
                </div>
              </div>
            )}
          </div>
        </section>
      </div>
    </div>
  );
}
