import {useMemo, useState} from 'react';
import {RotateCcw} from 'lucide-react';
import {
  GRADE_POINTS_MAP,
  GRADE_SCALE,
  SUBJECT_CATALOG,
  classifyAcademicStanding,
} from '../shared/grading.ts';
import type {LetterGrade} from '../shared/grading.ts';

const INITIAL_SIM_GRADES: Record<string, LetterGrade> = {
  MA301: 'A+',
  CS302: 'O',
  CS303: 'A',
  CS304: 'A+',
  CS305: 'A',
  CS306L: 'A+',
};

const GRADE_SWATCH: Record<LetterGrade, string> = {
  O: 'bg-emerald-600 text-white',
  'A+': 'bg-indigo-600 text-white',
  A: 'bg-violet-600 text-white',
  'B+': 'bg-teal-600 text-white',
  B: 'bg-amber-500 text-slate-950',
  C: 'bg-orange-500 text-white',
  F: 'bg-rose-600 text-white',
};

export function GradingScaleView() {
  const [simGrades, setSimGrades] = useState<Record<string, LetterGrade>>(INITIAL_SIM_GRADES);

  const simulation = useMemo(() => {
    let totalCredits = 0;
    let totalWeightedPoints = 0;
    let hasBacklog = false;

    const rows = SUBJECT_CATALOG.map((subj) => {
      const grade = simGrades[subj.code] ?? 'A';
      const gp = GRADE_POINTS_MAP[grade];
      const creditPoints = subj.credits * gp;
      totalCredits += subj.credits;
      totalWeightedPoints += creditPoints;
      if (grade === 'F') hasBacklog = true;

      return {
        ...subj,
        grade,
        gp,
        creditPoints,
      };
    });

    const sgpa = totalCredits > 0 ? Number((totalWeightedPoints / totalCredits).toFixed(2)) : 0;
    const classification = classifyAcademicStanding(sgpa, hasBacklog);

    return {
      rows,
      totalCredits,
      totalWeightedPoints,
      sgpa,
      hasBacklog,
      classification,
    };
  }, [simGrades]);

  const sgpaColorClass = simulation.hasBacklog
    ? 'text-rose-700'
    : simulation.sgpa >= 8.0
      ? 'text-emerald-700'
      : simulation.sgpa >= 6.5
        ? 'text-indigo-700'
        : 'text-amber-700';

  return (
    <div>
      {/* Vibrant Violet-to-Indigo Banner */}
      <section className="relative overflow-hidden bg-gradient-to-r from-violet-900 via-indigo-900 to-teal-900 text-white border-b border-indigo-900">
        <div className="absolute inset-0 bg-radar-grid opacity-45 pointer-events-none" aria-hidden="true" />
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <p className="text-xs font-semibold text-amber-300 mb-1.5">
            R22 Academic Regulations · Credit-Weighted Computation
          </p>
          <h1 className="text-2xl sm:text-3xl font-serif font-bold text-white tracking-tight">
            Official Grading Scale &amp; SGPA Simulator
          </h1>
          <p className="mt-1.5 text-sm text-indigo-100/90 max-w-3xl">
            Experiment with subject letter grades in real time to see how credit weights drive Semester Grade Point Average (SGPA) and academic honors classification.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Official Scale Table & Formula */}
          <div className="lg:col-span-5 space-y-6">
            <section className="bg-white border border-indigo-100 rounded-2xl overflow-hidden shadow-sm">
              <div className="px-6 py-4 border-b border-indigo-100 bg-gradient-to-r from-indigo-50/70 to-teal-50/50">
                <h2 className="text-base font-bold text-slate-900">
                  Letter Grade Conversion Table
                </h2>
              </div>
              <table className="w-full text-left border-collapse text-sm">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                    <th scope="col" className="py-3 pl-6 pr-3">Grade</th>
                    <th scope="col" className="py-3 px-3 text-right">Points</th>
                    <th scope="col" className="py-3 px-3 text-right">Marks Range</th>
                    <th scope="col" className="py-3 pl-3 pr-6">Performance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {GRADE_SCALE.map((entry) => (
                    <tr key={entry.grade} className="hover:bg-slate-50/70">
                      <td className="py-3 pl-6 pr-3">
                        <span
                          className={`inline-flex items-center justify-center w-8 h-7 rounded-md font-mono text-xs font-bold ${GRADE_SWATCH[entry.grade]}`}
                        >
                          {entry.grade}
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-mono font-bold tabular-nums text-indigo-700">
                        {entry.points}
                      </td>
                      <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-600">
                        {entry.minMarks} – {entry.maxMarks}
                      </td>
                      <td className="py-3 pl-3 pr-6 font-medium text-slate-700">{entry.label}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </section>

            <section className="bg-gradient-to-br from-indigo-50/80 to-violet-50/60 border border-indigo-200 rounded-2xl p-6 space-y-3">
              <h2 className="text-base font-bold text-indigo-950">
                Credit-Weighted Formula &amp; Pass Criteria
              </h2>
              <div className="p-3.5 bg-white border border-indigo-200 rounded-lg font-mono text-xs font-semibold text-indigo-900">
                SGPA = Σ (Subject Credits × Grade Points) ÷ Σ (Subject Credits)
              </div>
              <ul className="space-y-1.5 text-xs text-indigo-950/80 leading-relaxed">
                <li>Minimum Internal Assessment requirement: 14 / 40 marks (35%).</li>
                <li>Minimum End-Semester External requirement: 24 / 60 marks (40%).</li>
                <li>Aggregate subject pass threshold: 40 / 100 marks (Grade C or higher).</li>
                <li>First Class with Distinction requires SGPA ≥ 8.00 and zero active backlogs.</li>
              </ul>
            </section>
          </div>

          {/* Interactive What-If SGPA Calculator */}
          <section className="lg:col-span-7 bg-white border border-violet-200/80 rounded-2xl p-6 shadow-sm flex flex-col justify-between">
            <div>
              <div className="flex items-start justify-between gap-4 mb-5">
                <div>
                  <h2 className="text-base font-bold text-slate-900">
                    Interactive What-If SGPA Calculator
                  </h2>
                  <p className="text-xs text-slate-500 mt-0.5">
                    Initialized with 22CSE104 grades (177 ÷ 20 = 8.85). Adjust any subject grade to test SGPA impact.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setSimGrades(INITIAL_SIM_GRADES)}
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-indigo-700 hover:text-indigo-950 cursor-pointer shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" aria-hidden="true" />
                  Reset to 8.85
                </button>
              </div>

              <div className="overflow-x-auto border border-slate-200 rounded-xl">
                <table className="w-full text-left border-collapse text-sm">
                  <thead>
                    <tr className="bg-slate-50 border-b border-slate-200 text-xs font-semibold text-slate-600">
                      <th scope="col" className="py-3 pl-4 pr-3">Subject</th>
                      <th scope="col" className="py-3 px-3 text-right">Credits (C)</th>
                      <th scope="col" className="py-3 px-3">Expected Grade</th>
                      <th scope="col" className="py-3 px-3 text-right">GP</th>
                      <th scope="col" className="py-3 pl-3 pr-4 text-right">C × GP</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {simulation.rows.map((row) => (
                      <tr key={row.code} className="hover:bg-indigo-50/30">
                        <td className="py-3 pl-4 pr-3">
                          <div className="font-medium text-slate-900">{row.name}</div>
                          <div className="text-xs font-mono text-indigo-600">{row.code}</div>
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                          {row.credits}
                        </td>
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2">
                            <span
                              className={`inline-flex items-center justify-center w-7 h-7 rounded-md font-mono text-xs font-bold shrink-0 ${GRADE_SWATCH[row.grade]}`}
                            >
                              {row.grade}
                            </span>
                            <select
                              aria-label={`Select grade for ${row.name}`}
                              value={row.grade}
                              onChange={(e) =>
                                setSimGrades((prev) => ({
                                  ...prev,
                                  [row.code]: e.target.value as LetterGrade,
                                }))
                              }
                              className="px-2.5 py-1.5 bg-slate-50 border border-slate-300 rounded-md font-mono text-xs font-semibold text-slate-900 focus:border-indigo-700 focus:outline-none cursor-pointer"
                            >
                              {GRADE_SCALE.map((g) => (
                                <option key={g.grade} value={g.grade}>
                                  {g.grade} ({g.points} GP)
                                </option>
                              ))}
                            </select>
                          </div>
                        </td>
                        <td className="py-3 px-3 text-right font-mono tabular-nums text-slate-700">
                          {row.gp}
                        </td>
                        <td className="py-3 pl-3 pr-4 text-right font-mono font-bold tabular-nums text-indigo-950">
                          {row.creditPoints}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="mt-6 pt-5 border-t border-slate-200 space-y-4">
              {/* Live Gradient Progress Bar */}
              <div>
                <div className="flex justify-between text-xs font-medium text-slate-500 mb-1.5">
                  <span>SGPA Meter</span>
                  <span className="font-mono tabular-nums">{simulation.sgpa.toFixed(2)} / 10.00</span>
                </div>
                <div className="h-2.5 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all duration-200 ${
                      simulation.hasBacklog
                        ? 'bg-rose-600'
                        : 'bg-gradient-to-r from-indigo-600 via-teal-500 to-emerald-500'
                    }`}
                    style={{width: `${(simulation.sgpa / 10) * 100}%`}}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 items-center">
                <div>
                  <div className="text-xs text-slate-500">Weighted Credit Sum</div>
                  <div className="text-lg font-mono font-semibold tabular-nums text-slate-900">
                    {simulation.totalWeightedPoints} / {simulation.totalCredits} credits
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Projected Standing</div>
                  <div className={`text-sm font-bold ${sgpaColorClass}`}>
                    {simulation.classification}
                  </div>
                </div>
                <div className="sm:text-right">
                  <div className="text-xs text-slate-500">Computed SGPA</div>
                  <div className={`text-3xl font-mono font-bold tabular-nums ${sgpaColorClass}`}>
                    {simulation.sgpa.toFixed(2)}
                  </div>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
