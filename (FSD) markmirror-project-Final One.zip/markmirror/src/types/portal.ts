import type {BatchId, BranchCode, LetterGrade, StudentRecord} from '../shared/grading.ts';

export type ActiveTab = 'lookup' | 'analytics' | 'toppers' | 'grading';

export interface SubjectAverageInfo {
  code: string;
  avgMarks: number;
  passRate: number;
}

export interface ResultLookupResponse {
  student: StudentRecord;
  standing: {
    branchRank: number;
    branchTotal: number;
    branchPercentile: number;
  };
  subjectAverages: SubjectAverageInfo[];
}

export interface StudentSummaryItem {
  hallTicket: string;
  name: string;
  branch: BranchCode;
  batch: BatchId;
  sgpa: number;
  cgpa: number;
  hasBacklog: boolean;
  classification: string;
}

export interface SubjectAnalyticsItem {
  code: string;
  name: string;
  shortName: string;
  credits: number;
  appeared: number;
  passed: number;
  failed: number;
  passRate: number;
  failRate: number;
  avgMarks: number;
  highestMarks: number;
  difficultyScore: number;
  difficultyTier: 'High' | 'Moderate' | 'Low';
}

export interface CgpaBinItem {
  label: string;
  count: number;
  percentage: number;
}

export interface GradeDistributionItem {
  grade: LetterGrade;
  count: number;
  percentage: number;
}

export interface TopperItem {
  rank: number;
  hallTicket: string;
  name: string;
  branch: BranchCode;
  sgpa: number;
  cgpa: number;
  earnedCredits: number;
  totalMarks: number;
  percentage: number;
  classification: string;
}

export interface BatchComparisonItem {
  batch: BatchId;
  totalStudents: number;
  overallPassRate: number;
  meanCgpa: number;
  meanSgpa: number;
  distinctionRate: number;
  osPassRate: number;
}

export interface BatchAnalyticsResponse {
  batch: BatchId;
  branch: BranchCode | 'ALL';
  summary: {
    totalStudents: number;
    passedStudents: number;
    overallPassRate: number;
    meanSgpa: number;
    meanCgpa: number;
    distinctionCount: number;
    distinctionRate: number;
    lowestPassSubject: {
      name: string;
      code: string;
      passRate: number;
    };
  };
  subjectAnalytics: SubjectAnalyticsItem[];
  cgpaDistribution: CgpaBinItem[];
  gradeDistribution: GradeDistributionItem[];
  toppers: TopperItem[];
  batchComparison: BatchComparisonItem[];
}
