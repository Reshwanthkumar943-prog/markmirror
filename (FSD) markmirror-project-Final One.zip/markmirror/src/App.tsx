import {useCallback, useEffect, useState} from 'react';
import {motion} from 'motion/react';
import type {BatchId, BranchCode} from './shared/grading.ts';
import type {
  ActiveTab,
  BatchAnalyticsResponse,
  ResultLookupResponse,
} from './types/portal.ts';
import {TopBar} from './components/TopBar.tsx';
import {LookupSection} from './components/LookupSection.tsx';
import {MarksheetView} from './components/MarksheetView.tsx';
import {BatchAnalyticsView} from './components/BatchAnalyticsView.tsx';
import {TopperLeaderboard} from './components/TopperLeaderboard.tsx';
import {GradingScaleView} from './components/GradingScaleView.tsx';

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('lookup');
  const [query, setQuery] = useState('22CSE104');

  // Result lookup state
  const [resultData, setResultData] = useState<ResultLookupResponse | null>(null);
  const [resultLoading, setResultLoading] = useState(false);
  const [resultError, setResultError] = useState<string | null>(null);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  // Batch analytics state
  const [batch, setBatch] = useState<BatchId>('2022-2026');
  const [branch, setBranch] = useState<BranchCode | 'ALL'>('ALL');
  const [analytics, setAnalytics] = useState<BatchAnalyticsResponse | null>(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);

  const fetchHallTicketResult = useCallback(async (rawInput: string) => {
    const trimmed = rawInput.trim();
    if (!trimmed) return;

    setResultLoading(true);
    setResultError(null);
    setSuggestions([]);

    try {
      let targetTicket = trimmed.toUpperCase();
      if (!/^\d{2}[A-Z]{2,4}\d{3}$/.test(targetTicket)) {
        const searchRes = await fetch(
          `/api/students?q=${encodeURIComponent(trimmed)}&batch=ALL&limit=1`,
        );
        if (searchRes.ok) {
          const searchData = (await searchRes.json()) as {
            students: Array<{hallTicket: string}>;
          };
          if (searchData.students.length > 0) {
            targetTicket = searchData.students[0].hallTicket;
            setQuery(targetTicket);
          }
        }
      }

      const res = await fetch(`/api/results/${encodeURIComponent(targetTicket)}`);
      if (!res.ok) {
        const errBody = (await res.json().catch(() => ({}))) as {
          error?: string;
          suggestions?: string[];
        };
        setResultData(null);
        setResultError(
          errBody.error
            ? `No examination record found for "${trimmed}".`
            : 'Unable to retrieve examination record.',
        );
        setSuggestions(errBody.suggestions ?? ['22CSE104', '22CSE101', '22CSE118']);
        return;
      }

      const payload = (await res.json()) as ResultLookupResponse;
      setResultData(payload);
      setQuery(payload.student.hallTicket);
    } catch {
      setResultError('Network error while connecting to the Examination Portal API.');
    } finally {
      setResultLoading(false);
    }
  }, []);

  const fetchAnalytics = useCallback(async (selectedBatch: BatchId, selectedBranch: BranchCode | 'ALL') => {
    setAnalyticsLoading(true);
    try {
      const res = await fetch(
        `/api/analytics?batch=${encodeURIComponent(selectedBatch)}&branch=${encodeURIComponent(selectedBranch)}`,
      );
      if (res.ok) {
        const payload = (await res.json()) as BatchAnalyticsResponse;
        setAnalytics(payload);
      }
    } finally {
      setAnalyticsLoading(false);
    }
  }, []);

  useEffect(() => {
    void fetchHallTicketResult('22CSE104');
  }, [fetchHallTicketResult]);

  useEffect(() => {
    void fetchAnalytics(batch, branch);
  }, [batch, branch, fetchAnalytics]);

  const handleInspectStudent = (hallTicket: string) => {
    setQuery(hallTicket);
    setActiveTab('lookup');
    void fetchHallTicketResult(hallTicket);
    window.scrollTo({top: 0, behavior: 'smooth'});
  };

  const handleQuickDemoLookup = () => {
    setQuery('22CSE104');
    setActiveTab('lookup');
    void fetchHallTicketResult('22CSE104');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900">
      <TopBar
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        hasActiveStudent={Boolean(resultData)}
        onPrintMarksheet={handlePrint}
        onQuickDemoLookup={handleQuickDemoLookup}
      />

      <main className="flex-1">
        <motion.div
          key={activeTab}
          initial={{opacity: 0, y: 6}}
          animate={{opacity: 1, y: 0}}
          transition={{duration: 0.18, ease: [0.16, 1, 0.3, 1]}}
        >
          {activeTab === 'lookup' && (
            <>
              <LookupSection
                query={query}
                onQueryChange={setQuery}
                onSearch={fetchHallTicketResult}
                isLoading={resultLoading}
                errorMessage={resultError}
                suggestions={suggestions}
              />

              {resultLoading && !resultData && (
                <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
                  <div className="h-96 bg-white border border-indigo-100 rounded-2xl animate-pulse" />
                </div>
              )}

              {resultData && (
                <MarksheetView
                  data={resultData}
                  onPrint={handlePrint}
                  onOpenAnalytics={() => setActiveTab('analytics')}
                />
              )}
            </>
          )}

          {activeTab === 'analytics' && (
            <BatchAnalyticsView
              analytics={analytics}
              isLoading={analyticsLoading}
              batch={batch}
              branch={branch}
              onBatchChange={setBatch}
              onBranchChange={setBranch}
              onInspectStudent={handleInspectStudent}
              onOpenToppers={() => setActiveTab('toppers')}
              onRefreshAnalytics={() => void fetchAnalytics(batch, branch)}
            />
          )}

          {activeTab === 'toppers' && (
            <TopperLeaderboard
              analytics={analytics}
              isLoading={analyticsLoading}
              batch={batch}
              branch={branch}
              onBatchChange={setBatch}
              onBranchChange={setBranch}
              onInspectStudent={handleInspectStudent}
            />
          )}

          {activeTab === 'grading' && <GradingScaleView />}
        </motion.div>
      </main>

      <footer className="no-print border-t border-indigo-100 bg-white mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <span>
            MarkMirror · National Institute of Engineering &amp; Technology Examination Portal
          </span>
          <div className="flex items-center gap-4">
            <span>R22 Credit-Weighted Grading · Cohorts 2020–2026</span>
            <span aria-hidden="true" className="text-slate-300">·</span>
            <a
              href="/markmirror-project.zip"
              download="markmirror-project.zip"
              className="font-semibold text-indigo-700 hover:text-indigo-900 hover:underline underline-offset-4"
            >
              Download Source (.zip)
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
