export type LetterGrade = 'O' | 'A+' | 'A' | 'B+' | 'B' | 'C' | 'F';

export type BranchCode = 'CSE' | 'ECE' | 'IT';

export type BatchId = '2022-2026' | '2021-2025' | '2020-2024';

export interface GradeScaleEntry {
  grade: LetterGrade;
  points: number;
  minMarks: number;
  maxMarks: number;
  label: string;
}

export interface SubjectDefinition {
  code: string;
  name: string;
  shortName: string;
  credits: number;
  type: 'Theory' | 'Lab';
}

export interface SubjectResult {
  code: string;
  name: string;
  shortName: string;
  credits: number;
  type: 'Theory' | 'Lab';
  internalMarks: number; // out of 40
  externalMarks: number; // out of 60
  totalMarks: number; // out of 100
  grade: LetterGrade;
  gradePoints: number;
  creditPoints: number;
  passed: boolean;
}

export interface SemesterSnapshot {
  semester: string;
  sgpa: number;
  credits: number;
  batchAverage: number;
}

export interface StudentRecord {
  hallTicket: string;
  name: string;
  fatherName: string;
  branch: BranchCode;
  branchName: string;
  batch: BatchId;
  semester: string;
  examSession: string;
  regulation: string;
  subjects: SubjectResult[];
  sgpa: number;
  cgpa: number;
  totalCredits: number;
  earnedCredits: number;
  totalWeightedPoints: number;
  totalMarks: number;
  maxMarks: number;
  percentage: number;
  hasBacklog: boolean;
  backlogCount: number;
  classification: string;
  semesterHistory: SemesterSnapshot[];
}

export const GRADE_SCALE: readonly GradeScaleEntry[] = [
  {grade: 'O', points: 10, minMarks: 90, maxMarks: 100, label: 'Outstanding'},
  {grade: 'A+', points: 9, minMarks: 80, maxMarks: 89, label: 'Excellent'},
  {grade: 'A', points: 8, minMarks: 70, maxMarks: 79, label: 'Very Good'},
  {grade: 'B+', points: 7, minMarks: 60, maxMarks: 69, label: 'Good'},
  {grade: 'B', points: 6, minMarks: 50, maxMarks: 59, label: 'Above Average'},
  {grade: 'C', points: 5, minMarks: 40, maxMarks: 49, label: 'Average / Pass'},
  {grade: 'F', points: 0, minMarks: 0, maxMarks: 39, label: 'Fail / Backlog'},
] as const;

export const GRADE_POINTS_MAP: Record<LetterGrade, number> = {
  O: 10,
  'A+': 9,
  A: 8,
  'B+': 7,
  B: 6,
  C: 5,
  F: 0,
};

export const SUBJECT_CATALOG: readonly SubjectDefinition[] = [
  {code: 'MA301', name: 'Mathematics III', shortName: 'Mathematics', credits: 4, type: 'Theory'},
  {code: 'CS302', name: 'Database Management Systems', shortName: 'DBMS', credits: 4, type: 'Theory'},
  {code: 'CS303', name: 'Operating Systems', shortName: 'Operating Systems', credits: 4, type: 'Theory'},
  {code: 'CS304', name: 'Computer Networks', shortName: 'Computer Networks', credits: 3, type: 'Theory'},
  {code: 'CS305', name: 'Software Engineering', shortName: 'Software Engg.', credits: 3, type: 'Theory'},
  {code: 'CS306L', name: 'Artificial Intelligence Lab', shortName: 'AI Lab', credits: 2, type: 'Lab'},
] as const;

export const BRANCH_NAMES: Record<BranchCode, string> = {
  CSE: 'Computer Science & Engineering',
  ECE: 'Electronics & Communication Engineering',
  IT: 'Information Technology',
};

export const REVALUATION_FEE_PER_THEORY = 600;
export const REVALUATION_FEE_PER_LAB = 400;
export const REVALUATION_PROCESSING_FEE = 100;

export function determineLetterGrade(internalMarks: number, externalMarks: number): LetterGrade {
  const total = internalMarks + externalMarks;
  // Official university rule: minimum 14/40 internal, 24/60 external, and 40/100 total
  if (internalMarks < 14 || externalMarks < 24 || total < 40) {
    return 'F';
  }
  if (total >= 90) return 'O';
  if (total >= 80) return 'A+';
  if (total >= 70) return 'A';
  if (total >= 60) return 'B+';
  if (total >= 50) return 'B';
  return 'C';
}

export function classifyAcademicStanding(sgpa: number, hasBacklog: boolean): string {
  if (hasBacklog) return 'Promoted with Backlog';
  if (sgpa >= 8.0) return 'First Class with Distinction';
  if (sgpa >= 6.5) return 'First Class';
  if (sgpa >= 5.5) return 'Second Class';
  return 'Pass Class';
}

export function computeSGPA(subjects: readonly SubjectResult[]): {
  sgpa: number;
  totalCredits: number;
  earnedCredits: number;
  totalWeightedPoints: number;
  totalMarks: number;
  maxMarks: number;
  percentage: number;
  hasBacklog: boolean;
  backlogCount: number;
  classification: string;
} {
  let totalCredits = 0;
  let earnedCredits = 0;
  let totalWeightedPoints = 0;
  let totalMarks = 0;
  let backlogCount = 0;

  for (const subj of subjects) {
    totalCredits += subj.credits;
    totalMarks += subj.totalMarks;
    const gp = GRADE_POINTS_MAP[subj.grade];
    totalWeightedPoints += subj.credits * gp;
    if (subj.passed) {
      earnedCredits += subj.credits;
    } else {
      backlogCount += 1;
    }
  }

  const sgpa = totalCredits > 0 ? Number((totalWeightedPoints / totalCredits).toFixed(2)) : 0;
  const maxMarks = subjects.length * 100;
  const percentage = maxMarks > 0 ? Number(((totalMarks / maxMarks) * 100).toFixed(1)) : 0;
  const hasBacklog = backlogCount > 0;
  const classification = classifyAcademicStanding(sgpa, hasBacklog);

  return {
    sgpa,
    totalCredits,
    earnedCredits,
    totalWeightedPoints,
    totalMarks,
    maxMarks,
    percentage,
    hasBacklog,
    backlogCount,
    classification,
  };
}

export function computeCGPA(
  priorSemesters: readonly SemesterSnapshot[],
  currentSgpa: number,
  currentCredits: number,
): number {
  let weightedSum = currentSgpa * currentCredits;
  let totalCredits = currentCredits;

  for (const sem of priorSemesters) {
    weightedSum += sem.sgpa * sem.credits;
    totalCredits += sem.credits;
  }

  return totalCredits > 0 ? Number((weightedSum / totalCredits).toFixed(2)) : 0;
}

export function computeDifficultyIndex(passRate: number, avgMarks: number): {
  score: number;
  tier: 'High' | 'Moderate' | 'Low';
} {
  // Higher failure rate + lower mean marks => higher difficulty score (0 - 100)
  const failComponent = (100 - passRate) * 1.45;
  const markPenalty = Math.max(0, 82 - avgMarks) * 0.95;
  const score = Math.min(98, Math.max(8, Math.round(failComponent + markPenalty)));
  if (score >= 45) return {score, tier: 'High'};
  if (score >= 22) return {score, tier: 'Moderate'};
  return {score, tier: 'Low'};
}
