import fs from 'fs';
import path from 'path';
import {fileURLToPath} from 'url';
import {ALL_STUDENTS, computeBatchAnalytics} from './dataset.ts';
import type {BatchAnalyticsResponse} from './dataset.ts';
import {
  BRANCH_NAMES,
  GRADE_POINTS_MAP,
  SUBJECT_CATALOG,
  classifyAcademicStanding,
  computeCGPA,
  computeSGPA,
  determineLetterGrade,
} from '../src/shared/grading.ts';
import type {
  BatchId,
  BranchCode,
  StudentRecord,
  SubjectResult,
} from '../src/shared/grading.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '..', 'data');
const STUDENTS_FILE = path.join(DATA_DIR, 'students.json');
const REVALUATIONS_FILE = path.join(DATA_DIR, 'revaluations.json');

export interface RevaluationApplication {
  challanId: string;
  hallTicket: string;
  studentName: string;
  subjectCodes: string[];
  paperSubtotal: number;
  processingFee: number;
  totalFee: number;
  currency: 'INR';
  submittedAt: string;
}

export interface ImportStudentInput {
  hallTicket: string;
  name: string;
  fatherName?: string;
  branch: BranchCode;
  batch?: BatchId;
  marks: Array<{
    code: string;
    internal: number;
    external: number;
  }>;
}

let studentsStore: StudentRecord[] = [];
let revaluationsStore: RevaluationApplication[] = [];
const analyticsCache = new Map<string, BatchAnalyticsResponse>();

function ensureDataDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, {recursive: true});
  }
}

function saveStudentsToDisk() {
  ensureDataDir();
  fs.writeFileSync(STUDENTS_FILE, JSON.stringify(studentsStore, null, 2), 'utf8');
}

function saveRevaluationsToDisk() {
  ensureDataDir();
  fs.writeFileSync(REVALUATIONS_FILE, JSON.stringify(revaluationsStore, null, 2), 'utf8');
}

export function rebuildAnalyticsCache() {
  analyticsCache.clear();
  const batches: BatchId[] = ['2022-2026', '2021-2025', '2020-2024'];
  const branches: Array<BranchCode | 'ALL'> = ['ALL', 'CSE', 'ECE', 'IT'];

  for (const batch of batches) {
    for (const branch of branches) {
      analyticsCache.set(`${batch}:${branch}`, computeBatchAnalytics(batch, branch, studentsStore));
    }
  }
}

export function initStore() {
  ensureDataDir();

  if (fs.existsSync(STUDENTS_FILE)) {
    try {
      const raw = fs.readFileSync(STUDENTS_FILE, 'utf8');
      const parsed = JSON.parse(raw) as StudentRecord[];
      if (Array.isArray(parsed) && parsed.length > 0) {
        studentsStore = parsed;
      } else {
        studentsStore = [...ALL_STUDENTS];
        saveStudentsToDisk();
      }
    } catch {
      studentsStore = [...ALL_STUDENTS];
      saveStudentsToDisk();
    }
  } else {
    studentsStore = [...ALL_STUDENTS];
    saveStudentsToDisk();
  }

  if (fs.existsSync(REVALUATIONS_FILE)) {
    try {
      const raw = fs.readFileSync(REVALUATIONS_FILE, 'utf8');
      const parsed = JSON.parse(raw) as RevaluationApplication[];
      revaluationsStore = Array.isArray(parsed) ? parsed : [];
    } catch {
      revaluationsStore = [];
    }
  } else {
    revaluationsStore = [];
    saveRevaluationsToDisk();
  }

  rebuildAnalyticsCache();
}

export function getAllStudents(): StudentRecord[] {
  return studentsStore;
}

export function getCachedAnalytics(batch: BatchId, branch: BranchCode | 'ALL'): BatchAnalyticsResponse {
  const key = `${batch}:${branch}`;
  const cached = analyticsCache.get(key);
  if (cached) return cached;
  const computed = computeBatchAnalytics(batch, branch, studentsStore);
  analyticsCache.set(key, computed);
  return computed;
}

export function upsertStudents(inputs: ImportStudentInput[]): {
  importedCount: number;
  updatedCount: number;
  records: StudentRecord[];
} {
  let importedCount = 0;
  let updatedCount = 0;
  const processed: StudentRecord[] = [];

  for (const entry of inputs) {
    const hallTicket = entry.hallTicket.trim().toUpperCase();
    const branch: BranchCode =
      entry.branch === 'ECE' || entry.branch === 'IT' ? entry.branch : 'CSE';
    const batch: BatchId =
      entry.batch === '2021-2025' || entry.batch === '2020-2024' ? entry.batch : '2022-2026';

    const subjects: SubjectResult[] = SUBJECT_CATALOG.map((def) => {
      const found = entry.marks.find(
        (m) => m.code.trim().toUpperCase() === def.code.toUpperCase(),
      );
      const internal = Math.max(0, Math.min(40, Math.round(found?.internal ?? 24)));
      const external = Math.max(0, Math.min(60, Math.round(found?.external ?? 36)));
      const grade = determineLetterGrade(internal, external);
      const gradePoints = GRADE_POINTS_MAP[grade];
      return {
        code: def.code,
        name: def.name,
        shortName: def.shortName,
        credits: def.credits,
        type: def.type,
        internalMarks: internal,
        externalMarks: external,
        totalMarks: internal + external,
        grade,
        gradePoints,
        creditPoints: def.credits * gradePoints,
        passed: grade !== 'F',
      };
    });

    const sgpaMetrics = computeSGPA(subjects);
    const priorSemesters = [
      {semester: 'Semester I', sgpa: Number(Math.max(5.5, sgpaMetrics.sgpa - 0.25).toFixed(2)), credits: 20, batchAverage: 7.35},
      {semester: 'Semester II', sgpa: Number(Math.max(5.5, sgpaMetrics.sgpa - 0.15).toFixed(2)), credits: 20, batchAverage: 7.48},
      {semester: 'Semester III', sgpa: Number(Math.max(5.5, sgpaMetrics.sgpa - 0.1).toFixed(2)), credits: 21, batchAverage: 7.62},
      {semester: 'Semester IV', sgpa: Number(Math.max(5.5, sgpaMetrics.sgpa - 0.05).toFixed(2)), credits: 21, batchAverage: 7.54},
    ];
    const cgpa = computeCGPA(priorSemesters, sgpaMetrics.sgpa, sgpaMetrics.totalCredits);

    const record: StudentRecord = {
      hallTicket,
      name: entry.name.trim(),
      fatherName: (entry.fatherName || 'Guardian').trim(),
      branch,
      branchName: BRANCH_NAMES[branch],
      batch,
      semester: 'Semester V',
      examSession: batch === '2022-2026' ? 'November 2026' : batch === '2021-2025' ? 'November 2025' : 'November 2024',
      regulation: 'R22 Autonomous',
      subjects,
      sgpa: sgpaMetrics.sgpa,
      cgpa,
      totalCredits: sgpaMetrics.totalCredits,
      earnedCredits: sgpaMetrics.earnedCredits,
      totalWeightedPoints: sgpaMetrics.totalWeightedPoints,
      totalMarks: sgpaMetrics.totalMarks,
      maxMarks: sgpaMetrics.maxMarks,
      percentage: sgpaMetrics.percentage,
      hasBacklog: sgpaMetrics.hasBacklog,
      backlogCount: sgpaMetrics.backlogCount,
      classification: classifyAcademicStanding(sgpaMetrics.sgpa, sgpaMetrics.hasBacklog),
      semesterHistory: [
        ...priorSemesters,
        {
          semester: 'Semester V',
          sgpa: sgpaMetrics.sgpa,
          credits: sgpaMetrics.totalCredits,
          batchAverage: 7.65,
        },
      ],
    };

    const existingIdx = studentsStore.findIndex(
      (s) => s.hallTicket.toUpperCase() === hallTicket,
    );
    if (existingIdx >= 0) {
      studentsStore[existingIdx] = record;
      updatedCount += 1;
    } else {
      studentsStore.push(record);
      importedCount += 1;
    }
    processed.push(record);
  }

  saveStudentsToDisk();
  rebuildAnalyticsCache();

  return {importedCount, updatedCount, records: processed};
}

export function getRevaluationsForStudent(hallTicket: string): RevaluationApplication[] {
  const normalized = hallTicket.trim().toUpperCase();
  return revaluationsStore.filter((r) => r.hallTicket.toUpperCase() === normalized);
}

export function saveRevaluationApplication(
  app: Omit<RevaluationApplication, 'challanId' | 'submittedAt'>,
): RevaluationApplication {
  const created: RevaluationApplication = {
    ...app,
    challanId: `MM-REV-${new Date().getFullYear()}-${String(revaluationsStore.length + 101)}`,
    submittedAt: new Date().toISOString(),
  };
  revaluationsStore.unshift(created);
  saveRevaluationsToDisk();
  return created;
}

export function exportBatchCsv(batch: BatchId, branch: BranchCode | 'ALL'): string {
  const rows = studentsStore.filter(
    (s) => s.batch === batch && (branch === 'ALL' || s.branch === branch),
  );
  const headers = [
    'HallTicket',
    'Name',
    'Branch',
    'Batch',
    'MA301_Total',
    'CS302_Total',
    'CS303_OS_Total',
    'CS304_Total',
    'CS305_Total',
    'CS306L_Total',
    'TotalMarks',
    'Percentage',
    'SGPA',
    'CGPA',
    'Backlogs',
    'Classification',
  ];

  const lines = [headers.join(',')];
  for (const s of rows) {
    const subjTotals = s.subjects.map((sub) => sub.totalMarks);
    const cols = [
      s.hallTicket,
      `"${s.name.replace(/"/g, '""')}"`,
      s.branch,
      s.batch,
      ...subjTotals,
      s.totalMarks,
      s.percentage,
      s.sgpa.toFixed(2),
      s.cgpa.toFixed(2),
      s.backlogCount,
      `"${s.classification}"`,
    ];
    lines.push(cols.join(','));
  }

  return lines.join('\n');
}
